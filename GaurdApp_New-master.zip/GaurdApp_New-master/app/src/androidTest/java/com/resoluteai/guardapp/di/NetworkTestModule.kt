package com.resoluteai.guardapp.di

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import com.resoluteai.guardapp.data.remote.AlertApi
import com.resoluteai.guardapp.data.remote.AttendanceApi
import com.resoluteai.guardapp.data.remote.BreakApi
import com.resoluteai.guardapp.data.remote.EmployeeApi
import com.resoluteai.guardapp.data.remote.EventApi
import com.resoluteai.guardapp.data.remote.GeneratedAlertsApi
import com.resoluteai.guardapp.data.remote.OTPApi
import com.resoluteai.guardapp.service.RingtoneHelper
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.TokenManager
import dagger.Module
import dagger.Provides
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import dagger.hilt.testing.TestInstallIn
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@TestInstallIn(components = [SingletonComponent::class], replaces = [NetworkModule::class])
@Module
class NetworkTestModule {

    @Singleton
    @Provides
    fun provideRetrofitBuilder(): Retrofit.Builder{

        return  Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create())
    }

    @Provides
    @Singleton
    fun provideSharedPref(app: Application): SharedPreferences {
        return app.getSharedPreferences(
            Constant.MY_TOKEN_ID,
            Context.MODE_PRIVATE
        )
    }

    @Singleton
    @Provides
    fun provideOkHttpClient(sharedPreferences: SharedPreferences): OkHttpClient {

        return  OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .addInterceptor {
                val token = sharedPreferences.getString(Constant.MY_TOKEN_KEY, "")
                val modifiedRequest = it.request().newBuilder()
                    .addHeader("Authorization", "Bearer $token")
                    .build()
                it.proceed(modifiedRequest)
            }
            .addInterceptor(
                HttpLoggingInterceptor().apply {
                    level = HttpLoggingInterceptor.Level.BODY
                }
            )
            .build()
    }

    @Provides
    @Singleton
    fun provideBreakApi(retrofitBuilder: Retrofit.Builder, client: OkHttpClient): BreakApi {
        return retrofitBuilder
            .client(client)
            .baseUrl(Constant.Breaks_Service_P)
            .build()
            .create(BreakApi::class.java)
    }

    @Provides
    @Singleton
    fun provideAlertApi(retrofitBuilder: Retrofit.Builder, client: OkHttpClient): AlertApi {
        return retrofitBuilder
            .client(client)
            .baseUrl(Constant.Alert_Service_P)
            .build()
            .create(AlertApi::class.java)
    }

    @Provides
    @Singleton
    fun provideEventApi(retrofitBuilder: Retrofit.Builder, client: OkHttpClient): EventApi {
        return retrofitBuilder
            .client(client)
            .baseUrl(Constant.Event_Service_P)
            .build()
            .create(EventApi::class.java)
    }



    @Provides
    @Singleton
    fun provideAttendanceApi(retrofitBuilder: Retrofit.Builder, client: OkHttpClient): AttendanceApi {
        return retrofitBuilder
            .client(client)
            .baseUrl(Constant.Attendance_Service_P)
            .build()
            .create(AttendanceApi::class.java)
    }

    @Provides
    @Singleton
    fun provideEmployeeApi(retrofitBuilder: Retrofit.Builder, client: OkHttpClient): EmployeeApi {
        return retrofitBuilder
            .client(client)
            .baseUrl(Constant.Employee_Service_P)
            .build()
            .create(EmployeeApi::class.java)
    }

    @Provides
    @Singleton
    fun provideOTPApi(retrofitBuilder: Retrofit.Builder, client: OkHttpClient): OTPApi {
        return retrofitBuilder
            .client(client)
            .baseUrl(Constant.OTP_Service_P)
            .build()
            .create(OTPApi::class.java)
    }

    @Provides
    @Singleton
    fun provideGeneratedAlertsApi(retrofitBuilder: Retrofit.Builder, client: OkHttpClient): GeneratedAlertsApi {
        return retrofitBuilder
            .client(client)
            .baseUrl(Constant.GeneratedAlert_Service_P)
            .build()
            .create(GeneratedAlertsApi::class.java)
    }

    @Singleton
    @Provides
    fun provideTokenManager(@ApplicationContext context: Context): TokenManager {
        return TokenManager(context)
    }

    @Singleton
    @Provides
    fun provideNotificationHelper(@ApplicationContext context: Context): RingtoneHelper {
        return RingtoneHelper(context)
    }

}