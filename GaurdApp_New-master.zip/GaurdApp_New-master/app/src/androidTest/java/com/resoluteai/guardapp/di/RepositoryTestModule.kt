package com.resoluteai.guardapp.di

import com.resoluteai.guardapp.data.repository_impl.AlertRepositoryImpl
import com.resoluteai.guardapp.data.repository_impl.AttendanceRepositoryImpl
import com.resoluteai.guardapp.data.repository_impl.AuthRepositoryImpl
import com.resoluteai.guardapp.data.repository_impl.BreakRepositoryImpl
import com.resoluteai.guardapp.data.repository_impl.EmployeeRepositoryImpl
import com.resoluteai.guardapp.data.repository_impl.EventRepositoryImpl
import com.resoluteai.guardapp.data.repository_impl.GeneratedAlertsRepositoryImpl
import com.resoluteai.guardapp.data.repository_impl.OTPRepositoryImpl
import com.resoluteai.guardapp.domain.repository.AlertRepository
import com.resoluteai.guardapp.domain.repository.AttendanceRepository
import com.resoluteai.guardapp.domain.repository.AuthRepository
import com.resoluteai.guardapp.domain.repository.BreakRepository
import com.resoluteai.guardapp.domain.repository.EmployeeRepository
import com.resoluteai.guardapp.domain.repository.EventRepository
import com.resoluteai.guardapp.domain.repository.GeneratedAlertsRepository
import com.resoluteai.guardapp.domain.repository.OTPRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.components.SingletonComponent
import dagger.hilt.testing.TestInstallIn

@TestInstallIn(components = [SingletonComponent::class], replaces = [RepositoryModule::class])
@Module
abstract class RepositoryTestModule {

    @Binds
    abstract fun provideAuthRepository(authRepositoryImpl: AuthRepositoryImpl): AuthRepository
    @Binds
    abstract fun provideEmployeeRepository(employeeRepositoryImpl: EmployeeRepositoryImpl): EmployeeRepository
    @Binds
    abstract fun provideEventRepository(eventRepositoryImpl: EventRepositoryImpl): EventRepository
    @Binds
    abstract fun provideAttendanceRepository(attendanceRepositoryImpl: AttendanceRepositoryImpl): AttendanceRepository
    @Binds
    abstract fun provideOTPRepository(otpRepositoryImpl: OTPRepositoryImpl): OTPRepository
    @Binds
    abstract fun provideBreakRepository(breakRepositoryImpl: BreakRepositoryImpl): BreakRepository
    @Binds
    abstract fun provideAlertRepository(alertRepositoryImpl: AlertRepositoryImpl): AlertRepository
    @Binds
    abstract fun provideGeneratedAlertsRepository(generatedAlertsRepositoryImpl: GeneratedAlertsRepositoryImpl): GeneratedAlertsRepository
}