package com.resoluteai.guardapp.domain.repository

import com.resoluteai.guardapp.data.remote.api_request.SendGeofenceOTPRequest
import com.resoluteai.guardapp.data.remote.api_request.attendance.CheckPostStatusRequest
import com.resoluteai.guardapp.data.remote.api_request.attendance.HandshakeQRRequest
import com.resoluteai.guardapp.data.remote.api_request.attendance.UpdateAttendanceRequest
import com.resoluteai.guardapp.data.remote.api_request.break_request.BreakRequest
import com.resoluteai.guardapp.data.remote.api_response.BasicApiResponse
import com.resoluteai.guardapp.data.remote.api_response.CheckOutLocationResponse
import com.resoluteai.guardapp.data.remote.api_response.CheckPostStatusResponse
import com.resoluteai.guardapp.data.remote.api_response.MarkEmployeePresentResponse
import com.resoluteai.guardapp.data.remote.api_response.attendance.Attendance
import com.resoluteai.guardapp.data.remote.api_response.otp.SendOnLocationOTPResponse
import com.resoluteai.guardapp.utils.NetworkResult
import retrofit2.Response
import retrofit2.http.Body

interface AttendanceRepository {
    suspend fun acceptAssignment(@Body request: SendGeofenceOTPRequest):NetworkResult<String?>
    suspend fun getAttendance(employeeId: String, eventId: String): NetworkResult<Attendance>
    suspend fun markEmployeePresentAtPost(employeeId: String, eventId: String): NetworkResult<MarkEmployeePresentResponse>
    suspend fun checkPostStatus(requestBody: CheckPostStatusRequest): NetworkResult<CheckPostStatusResponse>
    suspend fun checkoutLocation(employeeId: String, eventId: String): NetworkResult<CheckOutLocationResponse>
    suspend fun verifyHandshakeQR(employeeId: String, eventId: String, requestBody: HandshakeQRRequest): NetworkResult<Boolean>
    suspend fun updateAttendance(requestBody: UpdateAttendanceRequest): NetworkResult<Attendance>
    suspend fun temporaryTransferPost(employeeId: String, eventId: String, requestBody: BreakRequest): NetworkResult<Boolean>
    suspend fun reclaimPost(employeeId: String, eventId: String, requestBody: BreakRequest): NetworkResult<Boolean>
}