package com.resoluteai.guardapp.domain.use_case.otp

import com.resoluteai.guardapp.data.remote.api_request.VerifyOtp
import com.resoluteai.guardapp.domain.repository.OTPRepository
import com.resoluteai.guardapp.utils.NetworkResult
import javax.inject.Inject

class VerifyOnLocationOTPUseCase @Inject constructor(
    private val otpRepository: OTPRepository
) {

    suspend operator fun invoke(requestBody: VerifyOtp): NetworkResult<String> =
        otpRepository.verifyOtpFromGeofence(requestBody)
}
