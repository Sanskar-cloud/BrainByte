package com.resoluteai.guardapp.domain.model.socket

data class AddSnapshotListenerRequest(
    val query: SnapshotListenerQuery,
    val listener_id: String,
    val employee_id: String
)
