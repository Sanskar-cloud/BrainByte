package com.resoluteai.guardapp.data.repository_impl

import android.util.Log
import com.google.gson.GsonBuilder
import com.resoluteai.guardapp.data.remote.GeneratedAlertsApi
import com.resoluteai.guardapp.data.remote.api_request.alert.CreateGeneratedAlertRequest
import com.resoluteai.guardapp.domain.model.alert.GeneratedAlert
import com.resoluteai.guardapp.domain.repository.GeneratedAlertsRepository
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.Constant.GENERATED_ALERTS_REPO_TAG
import com.resoluteai.guardapp.utils.NetworkResult
import javax.inject.Inject

class GeneratedAlertsRepositoryImpl @Inject constructor(
    private val generatedAlertsApi: GeneratedAlertsApi
): GeneratedAlertsRepository {


    override suspend fun getGeneratedAlertsByEmpId(employeeId: String): NetworkResult<List<com.resoluteai.guardapp.domain.model.alert.GeneratedAlert>> {
        return try {

            val result = generatedAlertsApi.getAllGeneratedAlertsByEmpId(employeeId)

            if (result.isSuccessful) {
                if (result.body()!!.status == true) {
                    NetworkResult.Success(result.body()!!.data!!)
                } else {
                    NetworkResult.Failed(result.body()!!.message)
                }

            } else {
                if (result.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        result.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            com.resoluteai.guardapp.data.remote.api_response.Detail::class.java,
                            com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, com.resoluteai.guardapp.data.remote.api_response.Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, com.resoluteai.guardapp.data.remote.api_response.Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
            NetworkResult.Failed("${e.message}")
        }
    }

    override suspend fun createGeneratedAlerts(requestBody: CreateGeneratedAlertRequest): NetworkResult<com.resoluteai.guardapp.domain.model.alert.GeneratedAlert> {
        val result = generatedAlertsApi.createGeneratedAlert(
            requestBody
        )

        Log.d(GENERATED_ALERTS_REPO_TAG, "${result.body()}")

        return try {

            if (result.isSuccessful) {
                if (result.body()!!.status == true) {
                    NetworkResult.Success(result.body()!!.data!!)
                } else {
                    NetworkResult.Failed(result.body()!!.message)
                }

            } else {
                if (result.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        result.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            com.resoluteai.guardapp.data.remote.api_response.Detail::class.java,
                            com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, com.resoluteai.guardapp.data.remote.api_response.Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, com.resoluteai.guardapp.data.remote.api_response.Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
            NetworkResult.Failed("${e.message}")
        }
    }


}