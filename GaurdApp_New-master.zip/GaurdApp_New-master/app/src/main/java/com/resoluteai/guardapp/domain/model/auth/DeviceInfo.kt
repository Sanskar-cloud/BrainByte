package com.resoluteai.guardapp.domain.model.auth

data class DeviceInfo(
    val name: String,
    val uid: String
)
