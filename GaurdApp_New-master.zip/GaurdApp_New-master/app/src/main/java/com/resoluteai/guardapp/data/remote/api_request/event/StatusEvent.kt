package com.resoluteai.guardapp.data.remote.api_request.event

data class StatusEvent(
    val status: Int
)
