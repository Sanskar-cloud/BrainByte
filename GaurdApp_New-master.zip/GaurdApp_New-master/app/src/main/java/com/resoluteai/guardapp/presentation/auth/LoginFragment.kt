package com.resoluteai.guardapp.presentation.auth

import android.Manifest
import android.app.Activity.RESULT_OK
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.google.android.gms.auth.api.phone.SmsRetriever
import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.broadcast.SmsReceiver
import com.resoluteai.guardapp.databinding.FragmentInitialOTPLoginBinding
import com.resoluteai.guardapp.presentation.EmployeeViewModel
import com.resoluteai.guardapp.presentation.activity.OnLocationOTPActivity
import com.resoluteai.guardapp.presentation.dialog.LoadingDialog
import com.resoluteai.guardapp.presentation.dialog.NotifyLoginDialog
import com.resoluteai.guardapp.presentation.dialog.SendLoginOTPDialog
import com.resoluteai.guardapp.presentation.activity.DashboardActivity
import com.resoluteai.guardapp.presentation.activity.Oprhandshake
import com.resoluteai.guardapp.presentation.dialog.LocationRequestDialog
import com.resoluteai.guardapp.utils.Constant.AssignmentOTPClass
import com.resoluteai.guardapp.utils.Constant.LoginFragmentClass
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.TokenManager
import com.resoluteai.guardapp.utils.createPolygonCoords
import com.resoluteai.guardapp.utils.getDeviceId
import com.resoluteai.guardapp.utils.getMac
import com.resoluteai.guardapp.utils.saveEmployeeInformation
import com.resoluteai.guardapp.utils.showToast
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern
import javax.inject.Inject

@AndroidEntryPoint
class LoginFragment : Fragment() {

    private var _binding: FragmentInitialOTPLoginBinding? = null
    private val binding get() = _binding!!

    private val loginViewModel by viewModels<LoginViewModel>()
    private val employeeViewModel by viewModels<EmployeeViewModel>()

    private val REQ_USER_CONSENT = 200
    private var smsReceiver : SmsReceiver? = null


    private lateinit var loadingDialog: LoadingDialog
    private lateinit var sendLoginOTPDialog: SendLoginOTPDialog
    private lateinit var generateOTPTimer: CountDownTimer
    @Inject
    lateinit var tokenManager: TokenManager

    var isTimerisRunning = false
    private var phoneNumber: String = ""
    private var otp: String = ""



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {



        

        _binding = FragmentInitialOTPLoginBinding.inflate(inflater, container, false)
        startSmartUserConsent()

        val notifyLoginDialog = NotifyLoginDialog()

        val locationReqDialog = LocationRequestDialog()

        if (!isLocationPermissionGranted()) {
            requireActivity().supportFragmentManager.apply {
                locationReqDialog.show(this, LocationRequestDialog.TAG)
            }
        }


        requireActivity().supportFragmentManager.apply {
            notifyLoginDialog.show(this, NotifyLoginDialog.TAG)
        }




        if (tokenManager.getToken().isNotEmpty()) {

            when(tokenManager.getRole()) {

                "SG" -> {

                    when(tokenManager.getStatusCode()) {

                        1 -> { Log.d(LoginFragmentClass, "status code ${tokenManager.getStatusCode()}")
                            findNavController().navigate(R.id.otpFragment)
                        }

                        2 -> {
                            Log.d(LoginFragmentClass, "status code ${tokenManager.getStatusCode()}")
                            startActivity(Intent(requireActivity(), OnLocationOTPActivity::class.java))
                            requireActivity().finishAffinity()
                        }
                        3 -> {
                            Log.d(LoginFragmentClass, "status code ${tokenManager.getStatusCode()}")
                            startActivity(Intent(requireActivity(), DashboardActivity::class.java))
                            requireActivity().finishAffinity()
                        }
                        4 -> {
                            Log.d(LoginFragmentClass, "status code ${tokenManager.getStatusCode()}")
                            startActivity(Intent(requireActivity(), DashboardActivity::class.java))
                            requireActivity().finishAffinity()
                        }
                    }

                }

                "OPR" -> {
                    when (tokenManager.getStatusCode()) {

                        1 -> {

                            //handled in on view created employee status
                        }

                        2 -> {
                            Log.d(LoginFragmentClass, "status code ${tokenManager.getStatusCode()}")
                            startActivity(
                                Intent(
                                    requireActivity(),
                                    OnLocationOTPActivity::class.java
                                )
                            )
                            requireActivity().finishAffinity()
                        }

                        3 -> {
                            Log.d(LoginFragmentClass, "status code ${tokenManager.getStatusCode()}")
                            startActivity(Intent(requireActivity(), Oprhandshake::class.java))
                            requireActivity().finishAffinity()
                        }

                        4 -> {
                            Log.d(LoginFragmentClass, "status code ${tokenManager.getStatusCode()}")
                            startActivity(Intent(requireActivity(), Oprhandshake::class.java))
                            requireActivity().finishAffinity()
                        }
                    }
                }

                "TRG" -> {

                    when(tokenManager.getStatusCode()) {

                        1 -> {
                            Log.d(LoginFragmentClass, "status code ${tokenManager.getStatusCode()}")
                            findNavController().navigate(R.id.otpFragment)
                        }

                        2 -> {
                            Log.d(LoginFragmentClass, "status code ${tokenManager.getStatusCode()}")
                            startActivity(Intent(requireActivity(), OnLocationOTPActivity::class.java))
                            requireActivity().finishAffinity()
                        }
                        3 -> {
                            Log.d(LoginFragmentClass, "status code ${tokenManager.getStatusCode()}")
                            startActivity(Intent(requireActivity(), DashboardActivity::class.java))
                            requireActivity().finishAffinity()
                        }
                        4 -> {
                            Log.d(LoginFragmentClass, "status code ${tokenManager.getStatusCode()}")
                            startActivity(Intent(requireActivity(), DashboardActivity::class.java))
                            requireActivity().finishAffinity()
                        }
                    }

                }

                else -> {

                }
            }

        } else {
            Log.d(LoginFragmentClass, "Token is Null")
        }

        loadingDialog = LoadingDialog()
        sendLoginOTPDialog = SendLoginOTPDialog()


        binding.infoIcon.setOnClickListener {
            requireActivity().supportFragmentManager.apply {
                notifyLoginDialog.show(this, NotifyLoginDialog.TAG)
            }
        }




        //generate otp
        binding.generateOtpBtn.setOnClickListener {
            phoneNumber = binding.mobileNumberEt.text.toString().trim()
//            binding.mobileNumberEt.isEnabled=false


            if (phoneNumber.isNotEmpty()) {
                val p = Pattern.compile("^\\d{10}$")
                if(p.matcher(phoneNumber).matches()){
                    binding.generateOtpBtn.isEnabled = false

                    generateOTPTimer = object : CountDownTimer(30000, 1000) {
                        override fun onTick(millisUntilFinished: Long) {
                            isTimerisRunning = true

                            val minutes = TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished)
                            val seconds = TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) - TimeUnit.MINUTES.toSeconds(minutes)

                            if (seconds < 10) {
                                binding.generateOtpBtn.text = "0${minutes}:0$seconds"
                            } else {
                                binding.generateOtpBtn.text = "0${minutes}:$seconds"
                            }

                        }

                        override fun onFinish() {
                            isTimerisRunning = false
                            Log.d(LoginFragmentClass, "Generate OTP Timer is Ended")
                            binding.generateOtpBtn.text = "Generate OTP"
                            binding.generateOtpBtn.isEnabled = true
                        }


                    }
                    sendLoginOTPDialog.show(childFragmentManager, SendLoginOTPDialog.TAG)
                    generateOTPTimer.start()
                    isTimerisRunning = true

                    loginViewModel.requestLoginOTP(phoneNumber, getDeviceId(requireActivity()))

                } else{
                    requireActivity().showToast("Enter valid mobile number \n कृपया वैध मोबाइल नंबर दर्ज करें।")
                }
            } else {
                requireActivity().showToast("Enter the mobile number first \n पहले मोबाइल नंबर दर्ज करें।")
            }

        }

        binding.loginBtn.setOnClickListener {
            otp = binding.otpEt.text.toString().trim()

            if (otp.isNotBlank()) {
                binding.loginBtn.isEnabled = false
                loginViewModel.verifyLoginOTP(
                    otp, phoneNumber, getDeviceId(requireActivity())
                )

                loadingDialog.show(childFragmentManager, LoadingDialog.TAG)
            } else {
                requireActivity().showToast("Enter the Login OTP First \n पहले लॉगिन OTP दर्ज करें।")
            }

        }


        return binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loginViewModel.updateAttendance.observe(viewLifecycleOwner) {
            when(it) {
                is NetworkResult.Loading -> {

                }

                is NetworkResult.Success -> {
                    Log.d(LoginFragmentClass, "update attendance called")
                    if (it.data?.status == 2) {
                        Log.d(LoginFragmentClass, "update attendance status: ${it.data.status}")
                        tokenManager.saveStatusCode(2)
                        Log.d(LoginFragmentClass, "update attendance status: ${tokenManager.getStatusCode()}")
                        loadingDialog.dismiss()
                        Log.d(LoginFragmentClass, "current status after also block")
                        //Start a new Activity
                        if (tokenManager.getRole() == "LA") {
                            Toast.makeText(requireContext(), "Login OTP Successful: LA", Toast.LENGTH_SHORT).show()
                            val intentStartDashboard = Intent(requireActivity(), DashboardActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivity(intentStartDashboard)
                            activity?.finish()
                        } else if (tokenManager.getRole() == "OPR") {
                            Log.d(LoginFragmentClass, "status code ${tokenManager.getRole()}")
                            Toast.makeText(
                                requireContext(),
                                "Login OTP Successful\nलॉगिन OTP सफल हुआ",
                                Toast.LENGTH_SHORT
                            ).show()
//                            if (tokenManager.getRole() == "TRG") {
//                                val intentStartDashboard = Intent(
//                                    requireActivity(),
//                                    OnLocationOTPActivity::class.java
//                                ).apply {
//                                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
//                                }
//                                startActivity(intentStartDashboard)
//                                activity?.finish()
//                            }


                            if (tokenManager.getStatusCode() == 2) {
                                val intentStartDashboard = Intent(
                                    requireActivity(),
                                    OnLocationOTPActivity::class.java
                                ).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                startActivity(intentStartDashboard)
                                activity?.finish()
                            } else if (tokenManager.getStatusCode() >= 3) {
//                                val intentStartDashboard =
//                                    Intent(requireActivity(), DashboardActivity::class.java).apply {
//                                        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
//                                    }
                                startActivity(Intent(requireActivity(), Oprhandshake::class.java))
                                requireActivity().finishAffinity()
//                                startActivity(intentStartDashboard)
                                activity?.finish()
                            }

                        }
                        else{


                            if (tokenManager.getRole() == "TRG") {
                                val intentStartDashboard = Intent(requireActivity(),
                                    OnLocationOTPActivity::class.java).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                startActivity(intentStartDashboard)
                                activity?.finish()
                            }


                            if (tokenManager.getStatusCode() == 2) {
                                val intentStartDashboard = Intent(requireActivity(),
                                    OnLocationOTPActivity::class.java).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                startActivity(intentStartDashboard)
                                activity?.finish()
                            } else if (tokenManager.getStatusCode() >= 3) {
                                if(tokenManager.getRole()=="OPR"){
                                    val intentStartDashboard = Intent(requireActivity(), Oprhandshake::class.java).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    startActivity(intentStartDashboard)
                                    activity?.finish()

                                }
                                val intentStartDashboard = Intent(requireActivity(), DashboardActivity::class.java).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                startActivity(intentStartDashboard)
                                activity?.finish()
                            }

                        }
                    }
                }

                is NetworkResult.Failed -> {

                }
            }
        }

        loginViewModel.sendLoginOTP.observe(viewLifecycleOwner) {
            when(it) {
                is NetworkResult.Loading -> {

                }
                is NetworkResult.Success -> {
                    requireActivity().showToast("Login OTP sent \n लॉगिन OTP भेजा गया")
                    binding.otpEt.isEnabled = true
                    binding.loginBtn.isEnabled = true
                    if (sendLoginOTPDialog.isVisible) {
                        sendLoginOTPDialog.dismiss()
                    }

                }
                is NetworkResult.Failed -> {
                    Log.d(LoginFragmentClass, "${it.message}")
                    Toast.makeText(context, "Error: ${it.message}", Toast.LENGTH_LONG).show()
                    if (isTimerisRunning) {
                        generateOTPTimer.cancel()

                    }
                    binding.generateOtpBtn.isEnabled = true
                    binding.generateOtpBtn.text = "Generate OTP"

                    if (sendLoginOTPDialog.isVisible) {
                        sendLoginOTPDialog.dismiss()
                    }
                }
            }
        }

        loginViewModel.verifyLoginOTP.observe(viewLifecycleOwner) { result ->

            when(result) {
                is NetworkResult.Loading -> {

                }
                is NetworkResult.Success -> {

                    result.data?.access_token?.let { tokenManager.saveToken(it) }
                    Log.d(LoginFragmentClass, "token ${tokenManager.getToken()}")
                    result.data?.data?.id?.let {
                        tokenManager.saveEmployeeId(it)
                    }
                    result.data?.data?.eventId?.let {
                        tokenManager.saveEventId(it)
                    }
                    tokenManager.saveSomeImportantDetail(
                        location = "",
                        client = result.data?.data?.clientId?: "",
                        phoneNumber = result.data?.data?.phoneNumber?: "",
                        empId = result.data?.data?.id?: "",
                        postId = "",
                        latitude = 0F,
                        longitude = 0F,
                        proximity = 0,
                        role = result.data?.data?.role?.acronym?: ""
                    )

                    val role = tokenManager.getRole()

                    if (role == "SG" || role == "TRG") {
                        if (result.data?.data?.isAssigned == true) {

                            Log.d(LoginFragmentClass, "Event is Assigned to Guard")
                            loadingDialog.dismiss()
                            tokenManager.saveStatusCode(1)
                            findNavController().navigate(R.id.action_loginFragment_to_otpFragment)

                        } else {

                            if (result.data?.data?.eventId.isNullOrEmpty()) {
                                Log.d(LoginFragmentClass, "Event is Not Assigned to Guard")
                                loadingDialog.dismiss()
                                findNavController().navigate(R.id.action_loginFragment_to_onlyProfileFragment)
                            } else {
                                result.data?.data?.eventId?.let {
                                    tokenManager.saveEventId(
                                        it
                                    )
                                }
                                Log.d(LoginFragmentClass, "Event Assignment Done")
                                //fetchEmployee if isAssigned FALSE
                                employeeViewModel.fetchEmployee(true)
                            }

                        }
                    }else if(tokenManager.getRole() == "OPR"){
                        if (role == "OPR") {
                            if (result.data?.data?.isAssigned == true) {
                                result.data?.data?.eventId?.let {
                                    tokenManager.saveEventId(
                                        it
                                    )
                                }
                                Log.d(LoginFragmentClass, "isAssigned is True")
                                loadingDialog.dismiss()
                                findNavController().navigate(R.id.action_loginFragment_to_otpFragment)
//                                        Toast.makeText(
//                                            requireContext(),
//                                            "Enter Assignment OTP",
//                                            Toast.LENGTH_SHORT
//                                        ).show()
                            } else {

                                if (result.data?.data?.eventId.isNullOrEmpty()) {
                                    Log.d(LoginFragmentClass, "event is not assigned")
//                                            Toast.makeText(
//                                                context,
//                                                "You are not assigned to any event",
//                                                Toast.LENGTH_LONG
//                                            )
                                    if (loadingDialog.dialog != null && loadingDialog.dialog?.isShowing == true) {
                                        loadingDialog.dismiss()
                                    }
                                    findNavController().navigate(R.id.action_loginFragment_to_onlyProfileFragment)
                                } else {
//                                            //added
//                                            loadingDialog.dismiss()
                                    //
                                    result.data?.data?.eventId?.let {
                                        tokenManager.saveEventId(
                                            it
                                        )
                                    }
                                    Log.d(LoginFragmentClass, "event is assigned")

                                    //fetchEmployee if isAssigned FALSE
//                                            employeeViewModel.fetchEmployee(true)
                                    employeeViewModel.fetchEmployee(true)

                                }

                            }
                        }
                    }
                    else {
                        binding.loginBtn.isEnabled = true
                        requireActivity().showToast("only guard is allowed to login \n केवल गार्ड को ही लॉगिन करने की अनुमति है।")
                    }
                }

                is NetworkResult.Failed -> {
                    binding.loginBtn.isEnabled = true
                    requireActivity().showToast("Incorrect OTP Entered \n ")
                    if (isTimerisRunning) {
                        generateOTPTimer.cancel()

                    }
                    binding.generateOtpBtn.isEnabled = true
                    binding.generateOtpBtn.text = "Generate OTP"
                    loadingDialog.dismiss()
                }
            }


        }

        employeeViewModel.getEmployee.observe(viewLifecycleOwner) { employee ->
            when(employee) {
                is NetworkResult.Loading -> {

                }

                is NetworkResult.Success -> {

                    Log.d(LoginFragmentClass, "employee Successful")

                    binding.loginBtn.isEnabled = true

                    employee.data?.let {
                        saveEmployeeInformation(it, tokenManager)
                    }
                    employee.data?.status?.let { tokenManager.saveStatusCode(it) }
                    loadingDialog.dismiss()
                    Log.d(LoginFragmentClass, "current status after also block")
                    //Start a new Activity
                    requireActivity().showToast("Login OTP Successful \n लॉगिन OTP सफल हुआ")

                    when(tokenManager.getStatusCode()) {

                        2 -> {
                            val intentStartDashboard = Intent(requireActivity(),
                                OnLocationOTPActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivity(intentStartDashboard)
                            activity?.finish()
                        }

                        3 -> {
                            if(tokenManager.getRole()=="OPR"){
                                val intentStartDashboard = Intent(requireActivity(), Oprhandshake::class.java).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                startActivity(intentStartDashboard)
                                activity?.finish()

                            }
                            val intentStartDashboard = Intent(requireActivity(), DashboardActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivity(intentStartDashboard)
                            activity?.finish()

                        }

                        4 -> {
                            if(tokenManager.getRole()=="OPR"){
                                val intentStartDashboard = Intent(requireActivity(), Oprhandshake::class.java).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                startActivity(intentStartDashboard)
                                activity?.finish()

                            }
                            val intentStartDashboard = Intent(requireActivity(), DashboardActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivity(intentStartDashboard)
                            activity?.finish()
                        }

                        1 -> {
                            Log.d(LoginFragmentClass, "status code ${tokenManager.getStatusCode()}")
                            findNavController().navigate(R.id.otpFragment)
                        }

                        else -> {}
                    }
                }

                is NetworkResult.Failed -> {
                    binding.loginBtn.isEnabled = true
                    requireActivity().showToast("${employee.message}")
                    loadingDialog.dismiss()
                }
            }
        }



    }

    override fun onDestroyView() {
        super.onDestroyView()
        if (isTimerisRunning) {
            generateOTPTimer.cancel()
        }


        _binding = null
    }



    private fun updateStatusIfShiftEnded() {

        Log.d(LoginFragmentClass, "update status called")
        val rightNow: Calendar = Calendar.getInstance()
        val currentHourIn24Format = rightNow.get(Calendar.HOUR_OF_DAY)
        val currentMin = rightNow.get(Calendar.MINUTE)

        val curr_time = (currentHourIn24Format * 3600) + (currentMin * 60)

        val shiftStartTime = tokenManager.getShiftStartTime().split(":")

        if (tokenManager.getShiftStartTime() == "" || tokenManager.getShiftEndTime() == "") {

        }




        try {

            val shiftStartHr = shiftStartTime[0].toInt() * 3600
            val shiftStartMn = shiftStartTime[1].toInt() * 60



            val start_time = shiftStartHr + shiftStartMn

            val shiftEndTime = tokenManager.getShiftEndTime().split(":")
            val shiftEndHr = shiftEndTime[0].toInt() * 3600
            val shiftEndMn = shiftEndTime[1].toInt() * 60

            Log.d(LoginFragmentClass, "start shift time $shiftStartHr : $shiftStartMn")
            Log.d(LoginFragmentClass, "end shift time $shiftEndTime")
            Log.d(LoginFragmentClass, "current time $currentHourIn24Format : $currentMin")

            val end_time = shiftEndHr + shiftEndMn

            Log.d("OnLocationOTP", "$start_time $curr_time $end_time")

            if (start_time > end_time) {

                if (curr_time >= start_time || curr_time <= end_time) {
                    loadingDialog.dismiss()
                    navigateToNextScreen()
                    Log.d(LoginFragmentClass, "guard is in the shift cond1")

                } else {
                    //requireActivity().showToast("your shift isn't started 1")
                    loginViewModel.updateAttendance(2)
                    Log.d(LoginFragmentClass, "condn 1: update attendance 2")
                }


            } else {

                if (curr_time in start_time..end_time) {

                    loadingDialog.dismiss()
                    navigateToNextScreen()
                    Log.d(LoginFragmentClass, "guard is in the shift cond2")


                } else {
                    //requireActivity().showToast("your shift isn't started 2")
                    loginViewModel.updateAttendance(2)
                    Log.d(LoginFragmentClass, "condn 2: update attendance 2")
                }

            }


        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    private fun navigateToNextScreen() {
        if (tokenManager.getStatusCode() == 2) {
            val intentStartDashboard = Intent(requireActivity(), OnLocationOTPActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intentStartDashboard)
            activity?.finish()
        } else if (tokenManager.getStatusCode() >= 3) {
            if(tokenManager.getRole()=="OPR"){
                val intentStartDashboard = Intent(requireActivity(), Oprhandshake::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intentStartDashboard)
                activity?.finish()

            }
            val intentStartDashboard = Intent(requireActivity(), DashboardActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intentStartDashboard)
            activity?.finish()
        }
    }

    private fun isLocationPermissionGranted(): Boolean {
        return ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_USER_CONSENT){
            if(resultCode == RESULT_OK && data != null){
                val message = data.getStringExtra(SmsRetriever.EXTRA_SMS_MESSAGE)
                getOtpFromMessage(message)
            }
        }
    }

    private fun getOtpFromMessage(message: String?) {
            val otpPattern = Pattern.compile("(|^)\\d{5}")
            val matcher = otpPattern.matcher(message)
            if(matcher.find()){

                binding.otpEt.setText(matcher.group(0))

            }
    }

    private fun startSmartUserConsent(){
        val client = SmsRetriever.getClient(requireContext())
        client.startSmsUserConsent(null)
    }

    private fun registerSmsReceiver(){
        smsReceiver = SmsReceiver()
        smsReceiver!!.smsReceiverListener = object : SmsReceiver.SmsReceiverListener{
            override fun onSuccess(intent: Intent?) {
                startActivityForResult(intent, REQ_USER_CONSENT)
            }

            override fun onFailure() {
                Toast.makeText(requireContext(), "Failed to read", Toast.LENGTH_SHORT).show()
            }

        }

        val intentFilter = IntentFilter(SmsRetriever.SMS_RETRIEVED_ACTION)
        requireActivity().registerReceiver(smsReceiver, intentFilter)
    }

    override fun onStart() {
        super.onStart()
        registerSmsReceiver()
    }

    override fun onStop() {
        super.onStop()
        requireActivity().unregisterReceiver(smsReceiver)
    }


}

