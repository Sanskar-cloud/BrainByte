package com.resoluteai.guardapp.presentation.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.WriterException
import com.google.zxing.common.BitMatrix
import com.journeyapps.barcodescanner.BarcodeEncoder
import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.utils.TokenManager
import dagger.hilt.android.AndroidEntryPoint
import java.util.Calendar
import javax.inject.Inject


@AndroidEntryPoint
class Oprhandshake : AppCompatActivity() {

    @Inject
    lateinit var  tokenManager: TokenManager


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_oprhandshake)

        val qrScannerProfile = findViewById<LinearLayout>(R.id.qr_scanner_profile)
        qrScannerProfile.setOnClickListener {

            val intent = Intent(this, QrScannerActivity2::class.java)
            startActivity(intent)
        }
        val logout= findViewById<Button>(R.id.button5)
        logout.setOnClickListener {


            tokenManager.clearData()
            val intent = Intent(this, AuthActivity::class.java)
            startActivity(intent)



        }




        val refreshQRLayout = findViewById<LinearLayout>(R.id.refreshQRLayout)
        refreshQRLayout.setOnClickListener {
            if (tokenManager.getEmployeeID().isNotEmpty() && tokenManager.getEventID().isNotEmpty()) {
                try {
                    val rightNow: Calendar = Calendar.getInstance()
                    val currentHourIn24Format = rightNow.get(Calendar.HOUR_OF_DAY).toString()
                    val currentMin = rightNow.get(Calendar.MINUTE).toString()
                    val multiFormatWriter = MultiFormatWriter()
                    val bitmatrix : BitMatrix = multiFormatWriter.encode(
                        "$currentHourIn24Format:$currentMin ${tokenManager.getEmployeeID()} ${tokenManager.getEventID()} handshake",
                        BarcodeFormat.QR_CODE,
                        300,
                        300
                    )
                    val barcodeEncoder = BarcodeEncoder()
                    val bitmap = barcodeEncoder.createBitmap(bitmatrix)
                    val qrcodeIvNew = findViewById<ImageView>(R.id.qrcode_iv_new)

                   qrcodeIvNew?.setImageBitmap(bitmap)
                    Toast.makeText(this, "QR Code Generated Successfully \n क्यूआर कोड सफलतापूर्वक जनरेट हुआ।", Toast.LENGTH_SHORT).show()

                } catch(e: WriterException){
                    e.printStackTrace()
                }
            }
        }



    }
}