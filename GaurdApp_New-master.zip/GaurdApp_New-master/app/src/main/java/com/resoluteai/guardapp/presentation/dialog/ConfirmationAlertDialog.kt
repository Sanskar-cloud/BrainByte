package com.resoluteai.guardapp.presentation.dialog

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.viewModels
import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.data.remote.api_request.alert.CreateGeneratedAlertRequest
import com.resoluteai.guardapp.domain.model.alert.GeneratedAlert
import com.resoluteai.guardapp.domain.model.socket.PostAlert
import com.resoluteai.guardapp.presentation.dashboard.HomeViewModel
import com.resoluteai.guardapp.domain.model.generated_alert.GeneratedAlertModel
import com.resoluteai.guardapp.socket.MySocketHandler
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.TokenManager
import com.resoluteai.guardapp.utils.showToast
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class ConfirmationAlertDialog(private val callback: Callback) : DialogFragment() {
    @Inject
    lateinit var tokenManager: TokenManager

    private val homeViewModel by viewModels<HomeViewModel>()


    interface Callback {
        fun alertGenerated(data: GeneratedAlertModel)
    }


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.dialog_send_alert, container, false)
        dialog?.window?.setBackgroundDrawableResource(R.drawable.card_rounded_desgin)

        val fColor = arguments?.getString("f_color")
        val bColor = arguments?.getString("b_color")
        val unicode = arguments?.getString("unicode")
        val alert = view.findViewById<TextView>(R.id.confirmation_icon)
        val color_b = Color.parseColor(bColor)
        val colorStateList_b = ColorStateList.valueOf(color_b)

        val color_f = Color.parseColor(fColor)
        val colorStateList_f = ColorStateList.valueOf(color_f)

        val font = Typeface.createFromAsset(requireContext().resources.assets, "font/fa_solid.ttf")
        alert.typeface = font
        val unicodeValue = unicode?.toInt(16)?.toChar()
        alert.text = unicodeValue.toString()
        alert.backgroundTintList = colorStateList_b
        alert.setTextColor(colorStateList_f)


        view.findViewById<Button>(R.id.startBtn).setOnClickListener {
            //do alert API

            arguments?.getString("alert_id")?.let { alertId ->
                arguments?.getString("alert_name")?.let { alertName ->

                    try {
                        val homeViewModel by viewModels<HomeViewModel>()
                        homeViewModel.createGeneratedAlert(
                            request = CreateGeneratedAlertRequest(
                                alert_id = alertId,
                                event_id = tokenManager.getEventID(),
                                guard_id = tokenManager.getEmployeeID(),
                                alert_name = alertName,
                                post_id = tokenManager.getSomePostId()
                            )
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                }?: kotlin.run {
                    Log.d("ConfirmationAlertDialog", "Alert Name parsing error")
                    requireActivity().showToast("Alert Name Parsing Error")
                }

            }?: kotlin.run {
                Log.d("Confirmation Dialog", "Alert id Parsing Error")
                requireActivity().showToast("Alert Id Parsing Error")
            }


        }
        view.findViewById<Button>(R.id.cancelBtn).setOnClickListener {
            dismiss()
        }
        isCancelable = true
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        homeViewModel.createGeneratedAlert.observe(viewLifecycleOwner) { result ->
            when (result) {

                is NetworkResult.Loading -> {

                }

                is NetworkResult.Success -> {

                    result.data?.let { data ->
                        callback.alertGenerated(
                            GeneratedAlertModel(
                                alert_name = data.alert_name,
                                alert_id = data.alert_id,
                                created_at = data.created_at,
                                post_id = data.post_id,
                                client_id = data.client_id,
                                event_id = data.event_id,
                                guard_id = data.guard_id,
                                id = data.id,
                                status = data.status
                            )
                        )

                    }

                    requireActivity().showToast("Alert Generated Successfully \n अलर्ट सफलतापूर्वक जनरेट किया गया।")
                    dismiss()

                }

                is NetworkResult.Failed -> {

                }
            }
        }
    }






    companion object {
        const val TAG = "ConfirmationAlertDialog"
    }
}