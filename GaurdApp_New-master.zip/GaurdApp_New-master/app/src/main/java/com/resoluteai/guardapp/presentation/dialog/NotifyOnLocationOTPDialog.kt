package com.resoluteai.guardapp.presentation.dialog

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.DialogFragment
import com.resoluteai.guardapp.R

class NotifyOnLocationOTPDialog: DialogFragment() {
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val notifyOnLocationOTPView = inflater.inflate(R.layout.dialog_notify_on_location, container, false)
        dialog?.window?.setBackgroundDrawableResource(R.drawable.card_rounded_desgin)

        val okBtn = notifyOnLocationOTPView.findViewById<Button>(R.id.ok_btn)

        okBtn.setOnClickListener {
            dismiss()
        }

        isCancelable = true

        return notifyOnLocationOTPView
    }
}