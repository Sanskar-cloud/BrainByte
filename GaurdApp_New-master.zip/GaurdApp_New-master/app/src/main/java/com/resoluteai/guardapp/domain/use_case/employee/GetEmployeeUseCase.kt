package com.resoluteai.guardapp.domain.use_case.employee

import com.resoluteai.guardapp.data.remote.api_response.employee.Employee
import com.resoluteai.guardapp.domain.repository.EmployeeRepository
import com.resoluteai.guardapp.utils.NetworkResult
import javax.inject.Inject

class GetEmployeeUseCase @Inject constructor(
    private val employeeRepository: EmployeeRepository
) {

    suspend operator fun invoke(employeeId: String, merge: Boolean): NetworkResult<Employee> =
        employeeRepository.getEmployeeById(employeeId, merge)
}