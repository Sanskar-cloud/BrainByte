package com.resoluteai.guardapp.presentation.livestream

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.resoluteai.guardapp.databinding.FragmentLiveStreamBinding
import com.resoluteai.guardapp.presentation.activity.CallActivity
import com.resoluteai.guardapp.presentation.dialog.BreakTimerDialog
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.Constant.IS_CALL_CAME_FROM_GUARD
import com.resoluteai.guardapp.utils.Constant.LiveStreamFragmentClass
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.TokenManager
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


@AndroidEntryPoint
class LiveStreamFragment : Fragment() {

    private var _binding: FragmentLiveStreamBinding? = null
    private val binding get() = _binding


    @Inject
    lateinit var tokenManager: TokenManager

    private val livestreamviewModel by viewModels<LivestreamViewModel>()


    private var operatorIds: MutableList<String> = mutableListOf()




    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        Log.d(LiveStreamFragmentClass, "on create view")

        _binding = FragmentLiveStreamBinding.inflate(inflater, container, false)



        binding?.startVideoCallBtn?.setOnClickListener {



            val args = Bundle()
            args.putBoolean("call_came_from_guard", true)

            val intent = Intent(requireActivity(), CallActivity::class.java).apply {
                arguments = args
            }
            IS_CALL_CAME_FROM_GUARD = true
            startActivity(intent)

        }


        return binding?.root
    }




    override fun onDestroyView() {
        super.onDestroyView()
        Log.d(LiveStreamFragmentClass, "ondestroy view called")
        _binding = null
    }

    interface CallFromGuardCallback{
        fun callCameFromGuard()
    }



}



