package com.resoluteai.guardapp.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log
import com.resoluteai.guardapp.broadcast.AlarmReceiver
import java.time.ZoneId

class AndroidAlarmScheduler(
    private val context: Context,
    private val isDutyEndAlarm: Boolean? = null,
    private val isBreakEndAlarm: Boolean? = null
): AlarmScheduler {

    private val alarmManager = context.getSystemService(AlarmManager::class.java)
    override fun schedule(item: AlarmItem) {
        Log.d("AlarmManager Called", "scheduled alarm successfully")

        Log.d("AndroidAlarmScheduler", "isBreakEndAlarm $isBreakEndAlarm")
        Log.d("AndroidAlarmScheduler", "isDutyEndAlarm $isBreakEndAlarm")
        Log.d("AndroidAlarmScheduler", "item name ${item.time.time}")
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("message", "your current shift time is ended")
            if (isDutyEndAlarm == true) {
                putExtra("is_duty_alarm", true)
                Log.d("AndroidAlarmScheduler", "isDutyEndAlarm schedule $isBreakEndAlarm")
            }
            if (isBreakEndAlarm == true) {
                putExtra("is_break_alarm", true)
                Log.d("AndroidAlarmScheduler", "isBreakEndAlarm schedule $isBreakEndAlarm")

            }


        }
        alarmManager.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            item.time.timeInMillis,
            PendingIntent.getBroadcast(
                context,
                item.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        )
    }

    override fun cancel(item: AlarmItem) {
        alarmManager.cancel(
            PendingIntent.getBroadcast(
                context,
                item.hashCode(),
                Intent(context, AlarmReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        )
    }
}