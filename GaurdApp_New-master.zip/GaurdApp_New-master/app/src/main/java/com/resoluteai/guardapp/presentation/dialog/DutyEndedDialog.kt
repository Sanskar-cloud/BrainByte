package com.resoluteai.guardapp.presentation.dialog

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.data.remote.api_request.attendance.UpdateAttendanceRequest
import com.resoluteai.guardapp.domain.use_case.attendance.UpdateAttendanceUseCase
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.TokenManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.util.Calendar
import javax.inject.Inject

@AndroidEntryPoint
class DutyEndedDialog: DialogFragment() {

    @Inject
    lateinit var tokenManager: TokenManager
    @Inject
    lateinit var updateAttendanceUC: UpdateAttendanceUseCase


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val dutyEndedView = inflater.inflate(R.layout.dialog_end_duty, container, false)
        dialog?.window?.setBackgroundDrawableResource(R.drawable.card_rounded_desgin)





//        dutyEndedView.findViewById<Button>(R.id.cancelBtn).setOnClickListener {
//            dismiss()
//        }



        isCancelable = true

        return dutyEndedView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //Update Status to 2
        updateAttendance(tokenManager.getEmployeeID(), tokenManager.getEventID())
    }

    companion object {
        const val TAG = "DutyEnded"
        const val LOG_TAG = "DutyEndedDialog"
    }


    private fun updateAttendance(empId: String, eventId: String) {
        viewLifecycleOwner.lifecycleScope.launch {
            val rightNow: Calendar = Calendar.getInstance()
            val currentHourIn24Format = rightNow.get(Calendar.HOUR_OF_DAY).toString()
            val currentMin = rightNow.get(Calendar.MINUTE).toString()
            val result = updateAttendanceUC(
                UpdateAttendanceRequest(
                    employee_id = empId,
                    event_id = eventId,
                    status = 2,
                    log = "Shift Duty Ended at $currentHourIn24Format:$currentMin"
                )
            )

            when(result) {

                is NetworkResult.Loading -> {

                }
                is NetworkResult.Success -> {

                    Log.d(LOG_TAG, "save status code ${result.data?.status}")


                }
                is NetworkResult.Failed -> {

                }
            }
        }

    }
}