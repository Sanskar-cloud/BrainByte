package com.resoluteai.guardapp.broadcast

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class BreakTimerReceiver(private val breakTimerCallBack: BreakTimerCallBack): BroadcastReceiver() {

    interface BreakTimerCallBack {
        fun onReceiveMillis(millis: Long)
    }
    override fun onReceive(context: Context?, intent: Intent?) {
        Log.d("BreakTimerreceiver", "broadcast called")
        val remainingMillis = intent?.getLongExtra("remainingMillis", 0L)
        if (remainingMillis != 0L && remainingMillis != null) {
            breakTimerCallBack.onReceiveMillis(remainingMillis)
        }
    }
}