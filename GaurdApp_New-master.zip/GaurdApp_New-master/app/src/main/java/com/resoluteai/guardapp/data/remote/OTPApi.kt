package com.resoluteai.guardapp.data.remote

import com.resoluteai.guardapp.data.remote.api_request.SendGeofenceOTPRequest
import com.resoluteai.guardapp.data.remote.api_request.VerifyOtp
import com.resoluteai.guardapp.data.remote.api_response.BasicApiResponse
import com.resoluteai.guardapp.data.remote.api_response.otp.SendOnLocationOTPResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.PUT

interface OTPApi {

    @PUT("/api/v1/verify-otp-attendance")
    suspend fun verifyAssignmentOTP(
        @Body request: VerifyOtp
    ): Response<BasicApiResponse<String>>

    @POST("/api/v1/send-otp")
    suspend fun sendOtpFromGeofence(@Body request: SendGeofenceOTPRequest): Response<BasicApiResponse<SendOnLocationOTPResponse>>

    @POST("/api/v1/verify-otp-location")
    suspend fun verifyOtpFromGeofence(@Body request: VerifyOtp): Response<BasicApiResponse<String>>



}