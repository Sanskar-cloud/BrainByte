package com.resoluteai.guardapp.data.repository_impl

import android.util.Log
import com.google.gson.GsonBuilder
import com.resoluteai.guardapp.data.remote.AttendanceApi
import com.resoluteai.guardapp.data.remote.api_request.SendGeofenceOTPRequest
import com.resoluteai.guardapp.data.remote.api_request.attendance.CheckPostStatusRequest
import com.resoluteai.guardapp.data.remote.api_request.attendance.HandshakeQRRequest
import com.resoluteai.guardapp.data.remote.api_request.attendance.UpdateAttendanceRequest
import com.resoluteai.guardapp.data.remote.api_request.break_request.BreakRequest
import com.resoluteai.guardapp.data.remote.api_response.BasicApiResponse
import com.resoluteai.guardapp.data.remote.api_response.CheckOutLocationResponse
import com.resoluteai.guardapp.data.remote.api_response.CheckPostStatusResponse
import com.resoluteai.guardapp.data.remote.api_response.Detail
import com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer
import com.resoluteai.guardapp.data.remote.api_response.MarkEmployeePresentResponse
import com.resoluteai.guardapp.data.remote.api_response.attendance.Attendance
import com.resoluteai.guardapp.data.remote.api_response.otp.SendOnLocationOTPResponse
import com.resoluteai.guardapp.domain.repository.AttendanceRepository
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.NetworkResult
import retrofit2.Response
import java.lang.Exception
import javax.inject.Inject

class AttendanceRepositoryImpl @Inject constructor(
    private val attendanceApi: AttendanceApi
): AttendanceRepository {

    override suspend fun acceptAssignment(requestBody: SendGeofenceOTPRequest): NetworkResult<String?> {
        return try {
            val result = attendanceApi.acceptAssignment(
                requestBody
            )

            if (result.isSuccessful) {

                if (result.body()!!.status == true) {
                    NetworkResult.Success(result.body()!!.data)
                } else {
                    NetworkResult.Failed(result.body()!!.message)
                }

            } else {
                if (result.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        result.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            Detail::class.java,
                            DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, com.resoluteai.guardapp.data.remote.api_response.Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }
            }
        } catch (e: Exception) {
            NetworkResult.Failed(e.message)
        }
    }
    override suspend fun getAttendance(
        employeeId: String,
        eventId: String
    ): NetworkResult<Attendance> {
        return try {

            val result = attendanceApi.getAttendanceByEmpEventId(employeeId, eventId)

            if (result.isSuccessful) {
                NetworkResult.Success(result.body()!!.data!!)
            } else {
                if (result.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        result.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            Detail::class.java,
                            com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, com.resoluteai.guardapp.data.remote.api_response.Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }
            }

        } catch (e: Exception) {
            NetworkResult.Failed(e.message)
        }
    }

    override suspend fun markEmployeePresentAtPost(
        employeeId: String,
        eventId: String
    ): NetworkResult<MarkEmployeePresentResponse> {
        return try {

            val result = attendanceApi.markEmployeePresentAtPost(employee_id = employeeId, event_id = eventId)

            if (result.isSuccessful) {
                NetworkResult.Success(result.body()!!)
            } else {
                if (result.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        result.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            Detail::class.java,
                            com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, com.resoluteai.guardapp.data.remote.api_response.Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }
            }

        } catch (e: Exception) {
            NetworkResult.Failed(e.message)
        }
    }

    override suspend fun checkPostStatus(requestBody: CheckPostStatusRequest): NetworkResult<com.resoluteai.guardapp.data.remote.api_response.CheckPostStatusResponse> {
        return try {

            val result = attendanceApi.checkPostStatus(requestBody)

            if (result.isSuccessful) {
                NetworkResult.Success(result.body()!!)
            } else {
                if (result.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        result.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            Detail::class.java,
                            com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, com.resoluteai.guardapp.data.remote.api_response.Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }
            }

        } catch (e: Exception) {
            NetworkResult.Failed(e.message)
        }
    }

    override suspend fun checkoutLocation(
        employeeId: String,
        eventId: String
    ): NetworkResult<CheckOutLocationResponse> {
        return try {

            val result = attendanceApi.checkOutLocationForLocationTrack(event_id = eventId, employee_id = employeeId)

            if (result.isSuccessful) {
                NetworkResult.Success(result.body()!!)
            } else {
                if (result.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        result.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            Detail::class.java,
                            com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, com.resoluteai.guardapp.data.remote.api_response.Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }
            }

        } catch (e: Exception) {
            NetworkResult.Failed(e.message)
        }
    }

    override suspend fun verifyHandshakeQR(
        employeeId: String,
        eventId: String,
        requestBody: HandshakeQRRequest
    ): NetworkResult<Boolean> {
        return try {

            val result = attendanceApi.verifyHandshakeQR(eventId, employeeId, requestBody)

            if (result.isSuccessful) {
                NetworkResult.Success(result.body()!!.data!!)
            } else {
                if (result.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        result.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            Detail::class.java,
                            com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, com.resoluteai.guardapp.data.remote.api_response.Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }
            }

        } catch (e: Exception) {
            NetworkResult.Failed(e.message)
        }
    }

    override suspend fun updateAttendance(requestBody: UpdateAttendanceRequest): NetworkResult<Attendance> {
        return try {

            val result = attendanceApi.updateAttendanceByEmployeeId(requestBody)

            if (result.isSuccessful) {
                NetworkResult.Success(result.body()!!.data!!)
            } else {
                if (result.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        result.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            Detail::class.java,
                            com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, com.resoluteai.guardapp.data.remote.api_response.Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }
            }

        } catch (e: Exception) {
            NetworkResult.Failed(e.message)
        }
    }

    override suspend fun temporaryTransferPost(
        employeeId: String,
        eventId: String,
        requestBody: BreakRequest
    ): NetworkResult<Boolean> {
        return try {

            val result = attendanceApi.temporaryTransferPost(eventId, employeeId, requestBody)

            if (result.isSuccessful) {
                NetworkResult.Success(result.body()!!.data!!)
            } else {
                if (result.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        result.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            Detail::class.java,
                            com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, com.resoluteai.guardapp.data.remote.api_response.Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }
            }

        } catch (e: Exception) {
            NetworkResult.Failed(e.message)
        }
    }

    override suspend fun reclaimPost(
        employeeId: String,
        eventId: String,
        requestBody: BreakRequest
    ): NetworkResult<Boolean> {
        return try {

            val result = attendanceApi.reclaimPost(eventId, employeeId, requestBody)

            if (result.isSuccessful) {
                NetworkResult.Success(result.body()!!.data!!)
            } else {
                if (result.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        result.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            Detail::class.java,
                            com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, com.resoluteai.guardapp.data.remote.api_response.Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }
            }

        } catch (e: Exception) {
            NetworkResult.Failed(e.message)
        }
    }
}