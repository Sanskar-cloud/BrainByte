package com.resoluteai.guardapp.domain.model.auth.updated

data class getOTPDataClass(
    val `data`: String,
    val message: String,
    val status: Boolean
)

