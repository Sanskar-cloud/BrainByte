package com.resoluteai.guardapp.presentation.on_location

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.resoluteai.guardapp.data.remote.api_request.SendGeofenceOTPRequest
import com.resoluteai.guardapp.domain.use_case.employee.UpdateStatusOnLocationUsecase
import com.resoluteai.guardapp.domain.use_case.otp.VerifyOnLocationOTPUseCase
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.SingleLiveData
import com.resoluteai.guardapp.utils.TokenManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class OnLocationOTPViewModel @Inject constructor(
    private val updateStatusOnLocationUsecase: UpdateStatusOnLocationUsecase,
    private val verifyOnLocationOTPUC: VerifyOnLocationOTPUseCase,
    private val tokenManager: TokenManager
): ViewModel() {

    private val _udateStatusOnLocation = SingleLiveData<NetworkResult<String?>>()
    val sendOnLocationOTP : LiveData<NetworkResult<String?>>
        get() = _udateStatusOnLocation

    fun checkInToLoaction() {
        viewModelScope.launch {
            val result = updateStatusOnLocationUsecase(
                SendGeofenceOTPRequest(
                    employee_id = tokenManager.getEmployeeID(),
                    event_id = tokenManager.getEventID()
                )
            )

            when(result) {

                is NetworkResult.Loading -> {
                    _udateStatusOnLocation.postValue(NetworkResult.Loading())
                }
                is NetworkResult.Success -> {
                    NetworkResult.Success(result?.data)
                        ?.let { _udateStatusOnLocation.postValue(it) }
                }
                is NetworkResult.Failed -> {
                    _udateStatusOnLocation.postValue(NetworkResult.Failed(result.message))
                }
            }
        }
    }
}