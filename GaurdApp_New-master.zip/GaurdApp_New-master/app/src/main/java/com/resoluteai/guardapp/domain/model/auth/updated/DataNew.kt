package com.resoluteai.guardapp.domain.model.auth.updated


import com.google.gson.annotations.SerializedName

data class DataNew(
    @SerializedName("address")
    val address: String,
    @SerializedName("category_id")
    val categoryId: String?,
    @SerializedName("client_id")
    val clientId: String,
    @SerializedName("country_code")
    val countryCode: String,
    @SerializedName("created_at")
    val createdAt: String,
    @SerializedName("created_by")
    val createdBy: Any?,
    @SerializedName("email")
    val email: String,
    @SerializedName("event_id")
    val eventId: String? = null,
    @SerializedName("exp")
    val exp: Int,
    @SerializedName("forgot_password")
    val forgotPassword: Boolean,
    @SerializedName("forgot_password_otp_id")
    val forgotPasswordOtpId: String?,
    @SerializedName("id")
    val id: String,
    @SerializedName("is_assigned")
    val isAssigned: Boolean,
    @SerializedName("is_deleted")
    val isDeleted: Boolean,
    @SerializedName("last_shift_date")
    val lastShiftDate: String?,
    @SerializedName("last_shift_end_time")
    val lastShiftEndTime: String?,
    @SerializedName("last_shift_location")
    val lastShiftLocation: String?,
    @SerializedName("last_shift_start_time")
    val lastShiftStartTime: String?,
    @SerializedName("name")
    val name: String,
    @SerializedName("phone_number")
    val phoneNumber: String,
    @SerializedName("pincode")
    val pincode: String,
    @SerializedName("post_id")
    val postId: String?,
    @SerializedName("profile_url")
    val profileUrl: String,
    @SerializedName("role")
    val role: com.resoluteai.guardapp.domain.model.auth.updated.Role,
    @SerializedName("role_id")
    val roleId: String,
    @SerializedName("scopes")
    val scopes: List<String>,
    @SerializedName("status")
    val status: Boolean,
    @SerializedName("uidai")
    val uidai: String,
    @SerializedName("updated_at")
    val updatedAt: String,
    @SerializedName("updated_by")
    val updatedBy: String,
    @SerializedName("work_location_id")
    val workLocationId: String?,
    @SerializedName("assignment_otp_id")
    val assignmentOtpId: String
)