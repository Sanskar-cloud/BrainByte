package com.resoluteai.guardapp.presentation.auth

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.resoluteai.guardapp.data.remote.api_request.SendGeofenceOTPRequest
import com.resoluteai.guardapp.data.remote.api_request.VerifyOtp
import com.resoluteai.guardapp.data.remote.api_request.attendance.UpdateAttendanceRequest
import com.resoluteai.guardapp.data.remote.api_response.attendance.Attendance
import com.resoluteai.guardapp.domain.model.auth.updated.NewAuthResponse
import com.resoluteai.guardapp.domain.use_case.attendance.AcceptAssignmentUseCase
import com.resoluteai.guardapp.domain.use_case.attendance.UpdateAttendanceUseCase
import com.resoluteai.guardapp.domain.use_case.auth.SendLoginOTPUseCase
import com.resoluteai.guardapp.domain.use_case.auth.VerifyAssignmentOTP
import com.resoluteai.guardapp.domain.use_case.auth.VerifyLoginOTPUseCase
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.SingleLiveData
import com.resoluteai.guardapp.utils.TokenManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val updateAttendanceUC: UpdateAttendanceUseCase,
    private val accesptAssignmentUseCase: AcceptAssignmentUseCase,
    private val tokenManager: TokenManager,
    private val verifyAssignmentOTP: VerifyAssignmentOTP,
    private val sendLoginOTPUC: SendLoginOTPUseCase,
    private val verifyLoginOTPUC: VerifyLoginOTPUseCase
): ViewModel() {


    private val _updateAttendance = SingleLiveData<NetworkResult<Attendance>>()
    val updateAttendance : LiveData<NetworkResult<Attendance>>
        get() = _updateAttendance

    private val _verifyAssignmentOTP = SingleLiveData<NetworkResult<String>>()
    val verifyAssignmentOTPLiveData: LiveData<NetworkResult<String>> get() = _verifyAssignmentOTP

    private  val _sendLoginOTP = SingleLiveData<NetworkResult<String>>()
    val sendLoginOTP : LiveData<NetworkResult<String>>
        get() = _sendLoginOTP

    private  val _verifyLoginOTP = SingleLiveData<NetworkResult<NewAuthResponse>>()
    val verifyLoginOTP : LiveData<NetworkResult<NewAuthResponse>>
        get() = _verifyLoginOTP

    private val _acceptAssigment = SingleLiveData<NetworkResult<String?>>()
    val acceptAssigment : LiveData<NetworkResult<String?>>
        get() = _acceptAssigment

    fun updateAttendance(status: Int) {
        viewModelScope.launch {
            val result = updateAttendanceUC(
                UpdateAttendanceRequest(
                    employee_id = tokenManager.getEmployeeID(),
                    event_id = tokenManager.getEventID(),
                    status = status
                )
            )

            when(result) {

                is NetworkResult.Loading -> {

                    _updateAttendance.postValue(NetworkResult.Loading())
                }
                is NetworkResult.Success -> {

                    _updateAttendance.postValue(NetworkResult.Success(result.data!!))
                }
                is NetworkResult.Failed -> {

                    _updateAttendance.postValue(NetworkResult.Failed(result.message))
                }
            }
        }
    }

    fun verifyAssignmentOTP(otp: String) {
        viewModelScope.launch {
            val response = verifyAssignmentOTP(
                VerifyOtp(
                    client_id = tokenManager.getSomeImportantClientID(),
                    employee_id = tokenManager.getEmployeeID(),
                    otp = otp
                )
            )

            when(response) {

                is NetworkResult.Loading -> {

                    _verifyAssignmentOTP.postValue(NetworkResult.Loading())
                }
                is NetworkResult.Success -> {

                    _verifyAssignmentOTP.postValue(NetworkResult.Success(response.data!!))
                }
                is NetworkResult.Failed -> {

                    _verifyAssignmentOTP.postValue(NetworkResult.Failed(response.message))
                }
            }
        }
    }



    fun verifyLoginOTP(
        otp: String,
        phoneNumber: String,
        macAddress: String
    ) {
        viewModelScope.launch {
            val response = verifyLoginOTPUC(
                otp, phoneNumber, macAddress
            )

            when(response) {

                is NetworkResult.Loading -> {

                    _verifyLoginOTP.postValue(NetworkResult.Loading())
                }
                is NetworkResult.Success -> {

                    _verifyLoginOTP.postValue(NetworkResult.Success(response.data!!))
                }
                is NetworkResult.Failed -> {

                    _verifyLoginOTP.postValue(NetworkResult.Failed(response.message))
                }
            }
        }
    }

    fun acceptAssigment(){
        viewModelScope.launch {
            val response = accesptAssignmentUseCase(
                    SendGeofenceOTPRequest(
                        employee_id = tokenManager.getEmployeeID(),
                        event_id = tokenManager.getEventID()
                    )
            )
            when(response) {
                is NetworkResult.Loading -> {

                    _acceptAssigment.postValue(NetworkResult.Loading())
                }
                is NetworkResult.Success -> {

                    _acceptAssigment.postValue(NetworkResult.Success(response.data))
                }
                is NetworkResult.Failed -> {
                    _acceptAssigment.postValue(NetworkResult.Failed(response.message))
                }
            }
        }
    }

    fun  requestLoginOTP(phoneNumber: String, macAddress: String){
        viewModelScope.launch {
            val response = sendLoginOTPUC(
                phoneNumber,
                macAddress
            )

            when(response) {

                is NetworkResult.Loading -> {

                    _sendLoginOTP.postValue(NetworkResult.Loading())
                }
                is NetworkResult.Success -> {

                    _sendLoginOTP.postValue(NetworkResult.Success(response.data!!))
                }
                is NetworkResult.Failed -> {

                    _sendLoginOTP.postValue(NetworkResult.Failed(response.message))
                }
            }
        }
    }
}