package com.resoluteai.guardapp.domain.model.socket

data class LocationForSocket(
    val employeeId: String,
    val eventId: String,
    val lat: String,
    val lng: String
)
