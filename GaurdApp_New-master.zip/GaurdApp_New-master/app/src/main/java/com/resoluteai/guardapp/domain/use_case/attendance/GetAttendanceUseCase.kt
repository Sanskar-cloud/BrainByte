package com.resoluteai.guardapp.domain.use_case.attendance

import com.resoluteai.guardapp.data.remote.api_response.attendance.Attendance
import com.resoluteai.guardapp.domain.repository.AttendanceRepository
import com.resoluteai.guardapp.utils.NetworkResult
import javax.inject.Inject

class GetAttendanceUseCase @Inject constructor(
    private val attendanceRepository: AttendanceRepository
) {

    suspend operator fun invoke(employeeId: String, eventId: String): NetworkResult<Attendance> =
        attendanceRepository.getAttendance(employeeId, eventId)
}