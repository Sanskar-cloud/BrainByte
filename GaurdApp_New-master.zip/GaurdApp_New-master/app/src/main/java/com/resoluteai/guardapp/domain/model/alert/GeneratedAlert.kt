package com.resoluteai.guardapp.domain.model.alert

import com.resoluteai.guardapp.domain.model.generated_alert.GeneratedAlertModel

data class GeneratedAlert(
    val created_at: String,
    val is_false: Boolean,
    val la_id: String?,
    val id: String,
    val summary: String?,
    val operator_id: String?,
    val guard_id: String,
    val client_id: String,
    val event_id: String,
    val updated_at: String?,
    val alert_id: String,
    val alert_name: String,
    val post_id: String,
    val status: Int
) {

    fun toViewGeneratedAlert(): GeneratedAlertModel = GeneratedAlertModel(
        alert_name = alert_name,
        alert_id = alert_id,
        created_at = created_at,
        post_id = post_id,
        client_id = client_id,
        event_id = event_id,
        guard_id = guard_id,
        id = id,
        status = status
    )
}

