package com.resoluteai.guardapp.data.remote.api_response.attendance

data class DayLog(
    val is_present: Boolean,
    val start_duty: String,
    val punch_in_time: String,
    val punch_out_time: String,
    val relieved: String,
    val log: List<String>?,
    val comment: List<String>?
)