package com.resoluteai.guardapp.domain.repository

import com.resoluteai.guardapp.data.remote.api_response.alert.Alert
import com.resoluteai.guardapp.utils.NetworkResult

interface AlertRepository {

    suspend fun getAllAlerts(): NetworkResult<List<Alert>>
}