package com.resoluteai.guardapp.data.remote.api_request.event

data class UpdateEventRequest(
    val post: List<String>
)
