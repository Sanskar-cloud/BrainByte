package com.resoluteai.guardapp.domain.model.socket

import com.resoluteai.guardapp.data.remote.api_response.event.Shift

data class ShiftEndedConfirmation(
    val employee_id: String,
    val event_id: String,
    val post_id: String,
    val guard_name: String,
    val shift: Shift,
    val status: Int
)
