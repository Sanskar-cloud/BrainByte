package com.resoluteai.guardapp.presentation.auth

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.databinding.FragmentOnlyProfileBinding
import com.resoluteai.guardapp.presentation.EmployeeViewModel
import com.resoluteai.guardapp.presentation.dialog.NotifyOnlyProfileDialog
import com.resoluteai.guardapp.presentation.activity.AuthActivity
import com.resoluteai.guardapp.utils.Constant.ISGuardEnteredOnLocationShown
import com.resoluteai.guardapp.utils.Constant.IsGuardEnteredAssignmentShown
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.TokenManager
import com.resoluteai.guardapp.utils.logout
import com.resoluteai.guardapp.utils.showToast
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class OnlyProfileFragment : Fragment() {

    private  var _binding :FragmentOnlyProfileBinding ? = null
    private  val binding get() = _binding!!

    @Inject
    lateinit var tokenManager: TokenManager

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentOnlyProfileBinding.inflate(inflater,container,false)
        inflater.inflate(R.layout.dialog_logout, container, false)

        binding.gaurdName.text = tokenManager.getProfileName()
        binding.gaurdId.text = "UIDAI     : ${tokenManager.getUidai()}"
        binding.emailID.text = "Email      : ${tokenManager.getEmail()}"
        binding.mobileNumber.text = "Mobile No.: ${tokenManager.getMobileNumber()}"
        binding.gaurdEvent.text = "Event     : ${tokenManager.getEventName()}"
        binding.gaurdPost.text = "Post Name : ${tokenManager.getPostName()}"
        binding.gaurdShiftTime.text = "Shift Time: ${tokenManager.getShiftStartTime()} to ${tokenManager.getShiftEndTime()}"

        binding.apply {
            button3.setOnClickListener{
                tokenManager.clearData()
                showCustomLogoutConfirmationDialog()



            }


        }



       return  binding.root
    }

    private fun showCustomLogoutConfirmationDialog() {
        val builder = AlertDialog.Builder(requireContext())
        val inflater = LayoutInflater.from(requireContext())
        val view = inflater.inflate(R.layout.dialog_logout, null)

        builder.setView(view)

        val dialog = builder.create()
        val yesButton = view.findViewById<LinearLayout>(R.id.alertConfirmed)
        val No = view.findViewById<LinearLayout>(R.id.cancel)

        yesButton.setOnClickListener {
            // Handle logout action here
            // For example, you can start the login activity or clear user session
            // startActivity(Intent(this, LoginActivity::class.java))
            // finish()
            ISGuardEnteredOnLocationShown = false
            IsGuardEnteredAssignmentShown = false
            val intentStartDashboard = Intent(requireActivity(),
                AuthActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intentStartDashboard)
            activity?.finish()

            dialog.dismiss()
        }

        No.setOnClickListener {
            // Dismiss the dialog if the user clicks "No"
            dialog.dismiss()
        }

        dialog.show()
    }



}