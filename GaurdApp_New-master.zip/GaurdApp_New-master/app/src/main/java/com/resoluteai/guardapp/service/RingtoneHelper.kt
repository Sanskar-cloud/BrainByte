package com.resoluteai.guardapp.service

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.util.Log
import com.resoluteai.guardapp.utils.Constant.MediaPlayerHelper

class RingtoneHelper(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    private val stopHandler = Handler()
    private val stopRunnable = Runnable { stopPlayback() }



    fun playNotificationSound(ringtoneUri: Uri) : MediaPlayer? {
        if (mediaPlayer == null) {
            mediaPlayer = MediaPlayer.create(context, ringtoneUri)
        }
        mediaPlayer?.apply {
            isLooping = true
            start()
        }
        Log.d(MediaPlayerHelper, "Play Media Player called")

        // Stop playback after 30 s (300,000 milliseconds)
        stopHandler.postDelayed(stopRunnable, 30000)

        return mediaPlayer
    }

    fun stopPlayback() {
        Log.d(MediaPlayerHelper, "Stop Player called")
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.stop()
                    Log.d(MediaPlayerHelper, "Media Player is Stopped")
                }
                it.reset()
                Log.d(MediaPlayerHelper, "Reset Media player")
                it.release()
                Log.d(MediaPlayerHelper, "Release player")
                mediaPlayer = null
            }
        } catch (e: Exception){
            e.printStackTrace()
        }

    }

}