package com.resoluteai.guardapp.domain.use_case.breaks

import com.resoluteai.guardapp.domain.repository.BreakRepository
import javax.inject.Inject

class GetAllBreaksUseCase @Inject constructor(
    private val breakRepository: BreakRepository
    ) {
    suspend operator fun invoke() = breakRepository.getAllBreaks()
}