package com.resoluteai.guardapp.domain.use_case.auth

import com.resoluteai.guardapp.data.remote.api_request.VerifyOtp
import com.resoluteai.guardapp.domain.repository.AuthRepository
import com.resoluteai.guardapp.utils.NetworkResult
import javax.inject.Inject

class VerifyAssignmentOTP @Inject constructor(
    private val authRepository: AuthRepository
) {

    suspend operator fun invoke(result: VerifyOtp): NetworkResult<String> {
        return authRepository.verifyAssignmentOTP(result)
    }
}