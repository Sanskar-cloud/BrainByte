package com.resoluteai.guardapp.domain.model

class AlertIcons {
    var icon:Int?=0
    var title:String?=null

    constructor(icon: Int?, title: String?) {
        this.icon = icon
        this.title = title
    }
}