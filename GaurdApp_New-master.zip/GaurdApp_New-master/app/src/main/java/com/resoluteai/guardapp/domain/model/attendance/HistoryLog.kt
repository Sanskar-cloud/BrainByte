package com.resoluteai.guardapp.domain.model.attendance

data class HistoryLog(
    val dutyDate: String?,
    val is_present: Boolean?,
    val start_duty: String?,
    val punch_in_time: String?,
    val punch_out_time: String?,
    val relieved: String?,
)