package com.resoluteai.guardapp.presentation.dashboard

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.data.remote.api_response.alert.Alert


class AlertAdapter(
    private val context: Context,
    private val onClick: (String, String, String, String, String) -> Unit,
    private val alerts: List<Alert>
) : RecyclerView.Adapter<AlertAdapter.ViewHolder>() {

    private val fadeOut: Animation by lazy { AnimationUtils.loadAnimation(context, R.anim.fade_out) }

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder)
     */
    inner class ViewHolder(view: View, onClick: (String, String, String, String, String) -> Unit) : RecyclerView.ViewHolder(view) {



        val alertIcon : TextView
        val alertName : TextView
        val alertLayout: RelativeLayout

        init {

            alertIcon = view.findViewById(R.id.icon)
            alertName = view.findViewById(R.id.title)
            alertLayout = view.findViewById(R.id.layout)

        }

    }

    // Create new views (invoked by the layout manager)
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        // Create a new view, which defines the UI of the list item
        val view = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.sample_home_alter_icons, viewGroup, false)

        return ViewHolder(view, onClick)
    }

    // Replace the contents of a view (invoked by the layout manager)
    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {

        // Get element from your dataset at this position and replace the
        // contents of the view with that element

        val alert = alerts[position]
        viewHolder.setIsRecyclable(false)

        viewHolder.alertLayout.setOnClickListener {
            val alert = alerts[position]
            //error line 72
            onClick(alert.id, alert.name, alert.icon_background_color, alert.icon_foreground_color, alert.icon_unicode)
            viewHolder.alertLayout.startAnimation(fadeOut)
            //Toast.makeText(context, "alert ${alert.name}", Toast.LENGTH_SHORT).show()
        }

        viewHolder.apply {
            // Apply the FontAwesome font to the TextView's text
            val color_b = Color.parseColor(alert.icon_background_color)
            val colorStateList_b = ColorStateList.valueOf(color_b)

            val color_f = Color.parseColor(alert.icon_foreground_color)
            val colorStateList_f = ColorStateList.valueOf(color_f)

            val font = Typeface.createFromAsset(context.resources.assets, "font/fa_solid.ttf")
            alertIcon.typeface = font
            val icon_unicode = alert.icon_unicode
            val unicodeValue = icon_unicode.toInt(16).toChar()
            alertIcon.text = unicodeValue.toString()
            alertIcon.backgroundTintList = colorStateList_b
            alertIcon.setTextColor(colorStateList_f)
            alertName.text = alert.name

        }
    }

    // Return the size of your dataset (invoked by the layout manager)
    override fun getItemCount() = alerts.size

}