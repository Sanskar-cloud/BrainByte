package com.resoluteai.guardapp.data.remote.api_request.attendance

data class UpdateAttendanceRequest(
    val employee_id: String,
    val event_id: String,
    val break_id: String? = null,
    val status: Int? = null,
    val log: String? = null
)
