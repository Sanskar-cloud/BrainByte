package com.resoluteai.guardapp.data.remote

import com.resoluteai.guardapp.data.remote.api_response.BasicApiResponse
import com.resoluteai.guardapp.data.remote.api_response.employee.Employee
import com.resoluteai.guardapp.domain.model.auth.updated.NewAuthResponse
import com.resoluteai.guardapp.domain.model.auth.updated.UserInfoClass
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface EmployeeApi {

    @POST("/api/v1/send-login-otp")
    suspend fun requestLoginOTP(
        @Body request: UserInfoClass
    ): Response<BasicApiResponse<String>>

    @POST("/api/v1/verify-login-otp")
    suspend fun verifyLoginOTP(
        @Body request: UserInfoClass
    ): Response<NewAuthResponse>


    @GET("/api/v1/get-employee-by-id")
    suspend fun getEmployeeById(
        @Query("id") employeeId :String,
        @Query("merge") merge:Boolean
    ): Response<BasicApiResponse<Employee>>

    @GET("/api/v1/get-employee-by-id")
    suspend fun getEmployeeByIdTest(
        @Query("id") employeeId :String,
        @Query("merge") merge:Boolean
    ): Response<List<Employee>>


}