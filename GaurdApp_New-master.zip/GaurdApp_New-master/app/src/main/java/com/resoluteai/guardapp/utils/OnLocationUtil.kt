package com.resoluteai.guardapp.utils

import android.content.Context
import android.provider.Settings
import android.util.Log
import com.resoluteai.guardapp.data.remote.api_response.employee.Employee
import java.util.Calendar


fun isLocationEnabledSystemWide(context: Context): Boolean {
    return try {
        val locationMode = Settings.Secure.getInt(
            context.contentResolver,
            Settings.Secure.LOCATION_MODE
        )
        locationMode != Settings.Secure.LOCATION_MODE_OFF
    } catch (e: Settings.SettingNotFoundException) {
        false
    }
}

fun checkShiftIsValid(start_time: Int, end_time: Int, curr_time: Int): Boolean {
    return if (start_time > end_time) {
        curr_time >= start_time || curr_time <= end_time
    } else {
        curr_time in start_time..end_time
    }
}


fun checkShiftTime(shiftStartTime: List<String>, shiftEndTime: List<String>, bufferInMin: Int): Boolean {

    try {

        val rightNow: Calendar = Calendar.getInstance()
        val currentHourIn24Format = rightNow.get(Calendar.HOUR_OF_DAY)
        val currentMin = rightNow.get(Calendar.MINUTE)

        val curr_time = (currentHourIn24Format * 3600) + (currentMin * 60)

        val bufferTime = bufferInMin*60
        val shiftStartHr = shiftStartTime[0].toInt() * 3600
        val shiftStartMn = shiftStartTime[1].toInt() * 60
        val shiftEndHr = shiftEndTime[0].toInt() * 3600
        val shiftEndMn = shiftEndTime[1].toInt() * 60

        val start_time = shiftStartHr + shiftStartMn - bufferTime
        val end_time = shiftEndHr + shiftEndMn + bufferTime

        Log.d("OnLocationOTP", "$start_time $curr_time $end_time")

        return checkShiftIsValid(start_time, end_time, curr_time)

    } catch (e: Exception) {
        throw e
    }
}

fun saveEmployeeInformation(employee: Employee, tokenManager: TokenManager) {

    //User Info
    employee.name.let {
        tokenManager.saveProfileName(it)
    }
    employee.email.let {
        tokenManager.saveEmail(it)
    }
    employee.phoneNumber.let {
        tokenManager.savePhoneNumber(it)
    }
    employee.uidai.let {
        tokenManager.saveUidai(it)
    }
    employee.status.let {
        tokenManager.saveStatusCode(it)
    }
    employee.clientId.let {
        tokenManager.saveClientId(it)
    }


    //Work Location
    employee.workLocationId?.let { locationId ->
        tokenManager.setLocationId(locationId)
    }
    employee.workLocation?.let {
        val cor = createPolygonCoords(it)
        tokenManager.saveGeoFunLiveLocation(cor)
        Log.d(Constant.AssignmentOTPClass,cor.toString())
    }

    //Post
    employee.postId?.let {
        tokenManager.savePostId(it)
    }
    employee.post?.name?.let {
        tokenManager.savePostName(it)
    }
    employee.post?.proximity?.let {
        tokenManager.saveProximity(it)
    }
    employee.post?.coordinates?.lat?.toFloat()?.let {
        tokenManager.setPostLatitude(it)
    }
    employee.post?.coordinates?.lng?.toFloat()?.let {
        tokenManager.setPostLongitude(it)
    }

    //Event
    employee.eventId?.let {
        tokenManager.saveEventId(it)
    }
    employee.event?.name?.let {
        tokenManager.saveEventName(it)
    }
    employee.event?.startDate?.let {
        tokenManager.saveStartDate(it)
    }
    employee.event?.endDate?.let {
        tokenManager.saveEndDate(it)
    }
    employee.event?.escalationTimeout?.let {
        tokenManager.saveEscalationTimeout(it)
    }

    //Shift
    employee.shift.let { shiftNo ->
        if (shiftNo != null) {
            tokenManager.saveShiftNo(shiftNo)
        }
        if (shiftNo != null) {
            employee.event?.shifts?.get(shiftNo)?.startTime?.let { startTime ->
                tokenManager.saveShiftStartTime(startTime)
            }
        }
        if (shiftNo != null) {
            employee.event?.shifts?.get(shiftNo)?.endTime?.let { endTime ->
                tokenManager.saveShiftEndTime(endTime)
            }
        }
    }

    if (tokenManager.getRole() == "SG") {
        employee.post?.proximity?.let {
            tokenManager.saveProximity(proximity = it)
        }
        employee.post?.coordinates?.lat?.toFloat()?.let {
            Log.d(Constant.HomeFragmentClass, "Post Lat on Employee fetch: $it")
            tokenManager.setPostLatitude(it)
            Log.d(
                Constant.HomeFragmentClass,
                "Post Lat saved: ${tokenManager.getPostLatitude()}"
            )
        }
        employee.post?.coordinates?.lng?.toFloat()?.let {
            Log.d(Constant.HomeFragmentClass, "Post Lng on Employee fetch: $it")
            tokenManager.setPostLongitude(it)
            Log.d(
                Constant.HomeFragmentClass,
                "Post Lng saved: ${tokenManager.getPostLongitude()}"
            )
        }
        employee.post?.name?.let { name ->
            Log.d(Constant.HomeFragmentClass, "Post name got: $name")
            tokenManager.savePostName(name)
        }

    }

}