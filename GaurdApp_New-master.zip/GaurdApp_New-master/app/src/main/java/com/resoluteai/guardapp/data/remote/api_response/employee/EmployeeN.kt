package com.resoluteai.guardapp.data.remote.api_response.employee

import com.resoluteai.guardapp.domain.model.auth.DeviceInfo

data class EmployeeN(
    val created_at: String,
    val forgot_password: Boolean,
    val assignment_otp_id: String?,
    val is_assigned: Boolean,
    val client_id: String,
    val status: Boolean,
    val updated_at: String,
    val pincode: String,
    val password: String,
    val event_id: String?,
    val profile_url: String,
    val updated_by: String?,
    val post_id: String?,
    val role_id: String?,
    val is_deleted: Boolean,
    val category_id: String?,
    val created_by: String?,
    val forgot_password_otp_id: String?,
    val work_location_id: String?,
    val country_code: Int,
    val email: String,
    val id: String,
    val name: String,
    val phone_number: String,
    val uidai: String,
    val device: DeviceInfo,
    val address: String
)
