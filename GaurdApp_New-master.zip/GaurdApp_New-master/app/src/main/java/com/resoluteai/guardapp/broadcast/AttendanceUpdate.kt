package com.resoluteai.guardapp.broadcast

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.google.gson.Gson
import com.resoluteai.guardapp.data.remote.api_response.attendance.Attendance

class AttendanceUpdate(private val attendanceUpdateCallback: AttendanceUpdateCallback): BroadcastReceiver() {

    interface AttendanceUpdateCallback {
        fun updateAttendance(attendance: Array<Attendance>)
    }

    override fun onReceive(context: Context?, intent: Intent?) {
        val attendanceData = intent?.getStringExtra("attendance-data")
        if (!attendanceData.isNullOrEmpty()) {
            Log.d("Broadcast attendance data", "$attendanceData")
            val attendance = Gson().fromJson(attendanceData, Array<Attendance>::class.java)
            try {
                attendanceUpdateCallback.updateAttendance(attendance)
            } catch (e: Exception) {
                e.printStackTrace()
            }

        }
    }
}