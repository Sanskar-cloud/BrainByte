package com.resoluteai.guardapp.data.repository_impl

import android.util.Log
import com.google.gson.GsonBuilder
import com.resoluteai.guardapp.data.remote.EventApi
import com.resoluteai.guardapp.data.remote.api_response.event.Event
import com.resoluteai.guardapp.domain.repository.EventRepository
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.NetworkResult
import javax.inject.Inject

class EventRepositoryImpl @Inject constructor(
    private val eventApi: EventApi
): EventRepository {

    override suspend fun getEventById(eventId: String): NetworkResult<Event> {
        return try {
            val result = eventApi.getEventById(eventId)
            Log.d("kuchbhi", "$result")
            if (result.isSuccessful) {
                Log.d("successKuchToh", "$result")
                if (result.body()!!.status == true) {
                    NetworkResult.Success(result.body()!!.data!!)
                } else {
                    NetworkResult.Failed(result.body()!!.message)
                }

            } else {
                if (result.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        result.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            com.resoluteai.guardapp.data.remote.api_response.Detail::class.java,
                            com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, com.resoluteai.guardapp.data.remote.api_response.Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, com.resoluteai.guardapp.data.remote.api_response.Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }
            }
        } catch (e: Exception) {
            NetworkResult.Failed(e.message)
        }
    }

    override suspend fun triggerEscalation(eventId: String): NetworkResult<Boolean> {
        return try {

            val result = eventApi.triggerEscalation(eventId)

            if (result.isSuccessful) {
                if (result.body()!!.status == true) {
                    NetworkResult.Success(result.body()!!.data!!)
                } else {
                    NetworkResult.Failed(result.body()!!.message)
                }

            } else {
                if (result.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        result.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            com.resoluteai.guardapp.data.remote.api_response.Detail::class.java,
                            com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, com.resoluteai.guardapp.data.remote.api_response.Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, com.resoluteai.guardapp.data.remote.api_response.Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }
            }

        } catch (e: Exception) {
            NetworkResult.Failed(e.message)
        }
    }
}