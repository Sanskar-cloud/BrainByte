package com.resoluteai.guardapp.presentation.dialog

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.DialogFragment
import com.resoluteai.guardapp.R

class NotifyAssignmentDialog: DialogFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val notifyAssignmentOTPView = inflater.inflate(R.layout.dialog_notify_assignment, container, false)
        dialog?.window?.setBackgroundDrawableResource(R.drawable.card_rounded_desgin)

        val okBtn = notifyAssignmentOTPView.findViewById<Button>(R.id.ok_btn)

        okBtn.setOnClickListener {
            dismiss()
        }

        isCancelable = false

        return notifyAssignmentOTPView
    }

    companion object {
        const val TAG = "NotifyAssignment"
    }
}