package com.resoluteai.guardapp.domain.repository

import com.resoluteai.guardapp.data.remote.api_response.event.Event
import com.resoluteai.guardapp.utils.NetworkResult

interface EventRepository {

    suspend fun getEventById(eventId: String): NetworkResult<Event>

    suspend fun triggerEscalation(eventId: String): NetworkResult<Boolean>
}