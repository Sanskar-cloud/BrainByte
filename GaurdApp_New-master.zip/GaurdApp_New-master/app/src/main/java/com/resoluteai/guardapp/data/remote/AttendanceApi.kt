package com.resoluteai.guardapp.data.remote

import com.resoluteai.guardapp.data.remote.api_request.SendGeofenceOTPRequest
import com.resoluteai.guardapp.data.remote.api_request.attendance.CheckPostStatusRequest
import com.resoluteai.guardapp.data.remote.api_request.attendance.HandshakeQRRequest
import com.resoluteai.guardapp.data.remote.api_request.attendance.UpdateAttendanceRequest
import com.resoluteai.guardapp.data.remote.api_request.break_request.BreakRequest
import com.resoluteai.guardapp.data.remote.api_response.BasicApiResponse
import com.resoluteai.guardapp.data.remote.api_response.CheckOutLocationResponse
import com.resoluteai.guardapp.data.remote.api_response.CheckPostStatusResponse
import com.resoluteai.guardapp.data.remote.api_response.MarkEmployeePresentResponse
import com.resoluteai.guardapp.data.remote.api_response.attendance.Attendance
import com.resoluteai.guardapp.data.remote.api_response.otp.SendOnLocationOTPResponse
import com.resoluteai.guardapp.utils.NetworkResult
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Query

interface AttendanceApi {

    @GET("/api/v1/get-attendance-by-employee-event-id")
    suspend fun getAttendanceByEmpEventId(
        @Query("employee_id") empId: String,
        @Query("event_id") eventId: String
    ): Response<BasicApiResponse<Attendance>>

    @POST("/api/v1/update-status-onlocation")
    suspend fun updateStatusOnLocation(@Body request: SendGeofenceOTPRequest): Response<BasicApiResponse<SendOnLocationOTPResponse>>

    @POST("/api/v1/accept-assignment")
    suspend fun acceptAssignment(@Body request: SendGeofenceOTPRequest): Response<BasicApiResponse<String>>

    @GET("/api/v1/mark-employee-present")
    suspend fun markEmployeePresentAtPost(
        @Query("event_id") event_id: String,
        @Query("employee_id") employee_id: String
    ): Response<MarkEmployeePresentResponse>
    @POST("/api/v1/check-post-status")
    suspend fun checkPostStatus(
        @Body checkPostStatusRequest: CheckPostStatusRequest
    ): Response<CheckPostStatusResponse>


    @POST("/api/v1/check-out-location")
    suspend fun checkOutLocationForLocationTrack(
        @Query("event_id") event_id: String,
        @Query("employee_id") employee_id: String
    ): Response<CheckOutLocationResponse>


    @POST("/api/v1/verify-handshake-qr")
    suspend fun verifyHandshakeQR(
        @Query("event_id") eventId: String,
        @Query("employee_id") employeeId: String,
        @Body request : HandshakeQRRequest
    ): Response<BasicApiResponse<Boolean>>

    @PUT("/api/v1/update-attendance-by-employee-id")
    suspend fun updateAttendanceByEmployeeId(
        @Body request: UpdateAttendanceRequest
    ): Response<BasicApiResponse<Attendance>>

    @POST("/api/v1/temporary-transfer-post")
    suspend fun temporaryTransferPost(
        @Query("event_id") eventId: String,
        @Query("employee_id") employeeId: String,
        @Body request: BreakRequest
    ): Response<BasicApiResponse<Boolean>>

    @POST("/api/v1/reclaim-post")
    suspend fun reclaimPost(
        @Query("event_id") eventId: String,
        @Query("employee_id") employeeId: String,
        @Body request: BreakRequest
    ): Response<BasicApiResponse<Boolean>>

}