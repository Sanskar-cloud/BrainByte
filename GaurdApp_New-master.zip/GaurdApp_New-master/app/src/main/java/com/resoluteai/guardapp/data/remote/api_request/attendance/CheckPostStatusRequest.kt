package com.resoluteai.guardapp.data.remote.api_request.attendance

data class CheckPostStatusRequest(
    val event_id: String,
    val employee_id: String,
    val post_id: String,
    val shift: Int
)
