package com.resoluteai.guardapp.domain.model.socket

data class SnapshotListenerQuery(
    val collection: String,
    val where: List<List<String>>
)
