package com.resoluteai.guardapp.data.remote.api_response.attendance


import com.google.gson.annotations.SerializedName

data class Attendance(
    @SerializedName("attendance_log")
    val attendanceLog: Map<String, DayLog>?,
    @SerializedName("break_id")
    val breakId: String? = null,
    @SerializedName("client_id")
    val clientId: String,
    @SerializedName("country_code")
    val countryCode: String,
    @SerializedName("created_at")
    val createdAt: String,
    @SerializedName("email")
    val email: String,
    @SerializedName("employee_id")
    val employeeId: String,
    @SerializedName("event_id")
    val eventId: String,
    @SerializedName("id")
    val id: String,
    @SerializedName("is_deleted")
    val isDeleted: Boolean,
    @SerializedName("name")
    val name: String,
    @SerializedName("phone_number")
    val phoneNumber: String,
    @SerializedName("post_id")
    val postId: String,
    @SerializedName("shift")
    val shift: Int,
    @SerializedName("status")
    val status: Int,
    @SerializedName("uidai")
    val uidai: String,
    @SerializedName("updated_at")
    val updatedAt: String,
    @SerializedName("updated_by")
    val updatedBy: String,
    val is_duty_transfered: String,
    val extended_duty: Boolean,
    val extended_duty_period: String,
    val extended_time: String,
    val false_alert_count: Int,
    val role_id: String
)

