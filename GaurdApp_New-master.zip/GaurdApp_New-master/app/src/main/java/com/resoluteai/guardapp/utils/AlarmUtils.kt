package com.resoluteai.guardapp.utils

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.resoluteai.guardapp.broadcast.AcceptCallNotification

object AlarmUtils {
    fun getAlarmPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, AcceptCallNotification::class.java)
        return PendingIntent.getBroadcast(context, 0, intent,
            PendingIntent.FLAG_IMMUTABLE
        )
    }
}