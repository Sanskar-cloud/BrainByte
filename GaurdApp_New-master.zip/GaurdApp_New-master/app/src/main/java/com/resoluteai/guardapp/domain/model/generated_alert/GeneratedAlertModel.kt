package com.resoluteai.guardapp.domain.model.generated_alert

data class GeneratedAlertModel(
    val id: String,
    val client_id: String,
    val alert_id: String,
    val event_id: String,
    val post_id: String,
    val guard_id: String,
    val alert_name: String,
    val created_at: String,
    val status: Int
    //val attended_status: Int? = null
)
