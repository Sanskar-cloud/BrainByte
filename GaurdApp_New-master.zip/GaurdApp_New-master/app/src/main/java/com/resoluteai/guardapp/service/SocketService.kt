package com.resoluteai.guardapp.service

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.IBinder
import android.os.SystemClock
import android.util.Log
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.google.gson.Gson
import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.presentation.activity.CallActivity
import com.resoluteai.guardapp.presentation.activity.FullScreenCallNotificationActivity
import com.resoluteai.guardapp.socket.MySocketHandler
import com.resoluteai.guardapp.presentation.activity.DashboardActivity
import com.resoluteai.guardapp.utils.AlarmUtils
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.Constant.Action_Call_Notification
import com.resoluteai.guardapp.utils.TokenManager
import dagger.hilt.android.AndroidEntryPoint
import io.socket.emitter.Emitter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONException
import javax.inject.Inject

@AndroidEntryPoint
class SocketService: Service() {

    @Inject
    lateinit var tokenManager: TokenManager

    private lateinit var notificationManager: NotificationManager
    private val delayMillis: Long = 30000

    @Inject
    lateinit var ringtoneHelper: RingtoneHelper
    private val coroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)


    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()

        startForeground(Constant.FOREGROUND_NOTIFICATION_ID, foregroundNotification())
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        Log.d("SocketService", "onCreate Called")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {

        when(intent?.action) {
            ACTION_START -> start()
            ACTION_STOP -> stop()
        }

        return START_REDELIVER_INTENT
    }

    override fun onLowMemory() {
        super.onLowMemory()
    }

    override fun onDestroy() {
        super.onDestroy()
        stop()

    }

    private fun start() {

        if (tokenManager.getEventID().isNotEmpty() && tokenManager.getEmployeeID().isNotEmpty()) {
            try {
                if (MySocketHandler.getSocket() == null) {
                    MySocketHandler.setSocket(
                        eventId = tokenManager.getEventID(),
                        employeeId = tokenManager.getEmployeeID(),
                        clientId = tokenManager.getSomeImportantClientID()
                    )
                    MySocketHandler.establishConnection()
                }
                val mSocket = MySocketHandler.getSocket()

                mSocket?.on("receive-call-request", onCallMessage)
                mSocket?.on("get-captcha", onGetCaptcha)


            } catch (e: Exception) {
                e.printStackTrace()
            }
        }


    }


    private val onCallMessage =
        Emitter.Listener { args ->

            coroutineScope.launch {

                val json = args[0].toString()
                val request = Gson().fromJson(json, com.resoluteai.guardapp.domain.model.call.CallRequest::class.java)
                val callerName: String

                try {
                    callerName = request.metadata.name
                    tokenManager.saveReceiverId(request.receiverId)
                    tokenManager.saveCallerEmpId(request.employeeId)
                    Log.d(Constant.ALERT_SERVICE, "call:${tokenManager.getCallerEmpId()}")
                    tokenManager.saveSocketIdForCall(request.receiverSocketId)
                } catch (e: JSONException) {
                    e.message?.let { Log.e(Constant.ALERT_SERVICE, it) }
                    return@launch
                }
                Log.d(Constant.ALERT_SERVICE, "a call from $callerName")
                if (!Constant.IS_GUARD_GOT_CALL_NOTIFICATION) {
                    Log.d(Constant.ALERT_SERVICE, "call: new notification")
                    setCallNotificationMessage(callerName)
                } else {
                    Log.d(Constant.ALERT_SERVICE, "true")
                }


            }



        }


    private val onGetCaptcha =
        Emitter.Listener { args ->
            coroutineScope.launch {
                Log.d(Constant.ALERT_SERVICE, "Captcha GOT")
                Constant.hasGuardEnteredCaptcha = false
                val intent =  Intent("action_captcha_verification")
                intent.putExtra("captcha_received", true)
                LocalBroadcastManager.getInstance(this@SocketService).sendBroadcast(intent)
                notificationManager.notify(Constant.RECEIVE_CAPTCHA_NOTIFICATION_ID, captchaNotification())

            }
        }



    private fun setCallNotificationMessage(callerName: String) {

        if (!Constant.IS_GUARD_IN_THE_CALL) {
            val nRing = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            ringtoneHelper.playNotificationSound(nRing)
            notificationManager.notify(Constant.CALL_NOTIFICATION_ID, callNotification(callerName))
            Constant.IS_GUARD_GOT_CALL_NOTIFICATION = true

            val intent = Intent(Action_Call_Notification).apply {
                putExtra("call_notif_got", true)
                putExtra("caller_name", callerName)
            }
            LocalBroadcastManager.getInstance(this).sendBroadcast(intent)

            // Schedule the cancellation and starting of activity using AlarmManager
            val startTime = SystemClock.elapsedRealtime() + delayMillis

            val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pendingAlarmIntent = AlarmUtils.getAlarmPendingIntent(applicationContext)
            alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, startTime, pendingAlarmIntent)

        }

    }

    private fun callNotification(callerName: String): Notification {

        val intent = Intent(applicationContext, CallActivity::class.java)
        val activityPendingIntent = PendingIntent.getActivity(
            applicationContext,
            REQUEST_CODE_CALL_NOTIF_INTENT,
            intent,
            PendingIntent.FLAG_IMMUTABLE
        )

        val fullScreenIntent = Intent(this, FullScreenCallNotificationActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        fullScreenIntent.putExtra("caller_name", callerName)
        Log.d(Constant.ALERT_SERVICE, "${fullScreenIntent.getStringExtra("caller_name")}")
        val fullScreenPendingIntent = PendingIntent.getActivity(
            this,
            REQUEST_CODE_FULL_SCREEN_CALL_NOTIF_INTENT,
            fullScreenIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        Log.d(Constant.ALERT_SERVICE, "NOTIFICATION called $callerName")

        // Get the layouts to use in the custom notification
        val notificationLayout = RemoteViews(packageName, R.layout.notification_call)
        val notificationLayoutExpanded = RemoteViews(packageName, R.layout.notification_call_large)
        notificationLayout.setTextViewText(R.id.callerNameText, callerName)
        notificationLayout.setOnClickPendingIntent(R.id.answerCall_btn, activityPendingIntent)
        notificationLayoutExpanded.setTextViewText(R.id.callerNameText, callerName)
        notificationLayoutExpanded.setOnClickPendingIntent(R.id.answerCall_btn, activityPendingIntent)

        return NotificationCompat
            .Builder(this, Constant.CALL_CHANNEL_ID)
            .setSmallIcon(R.drawable.camera_video_icon)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setCustomContentView(notificationLayout)
            .setCustomBigContentView(notificationLayoutExpanded)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setVibrate(longArrayOf(1000, 1000, 1000))
            .setOngoing(true)
            .build()
    }

    private fun captchaNotification(): Notification {

        val intent = Intent(applicationContext, DashboardActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val activityPendingIntent = PendingIntent.getActivity(
            applicationContext,
            1,
            intent,
            PendingIntent.FLAG_IMMUTABLE
        )
        val action = NotificationCompat.Action
            .Builder(
                IconCompat.createWithResource(applicationContext, R.drawable.baseline_video_call_24),
                "Open App",
                activityPendingIntent
            )
            .build()

        val soundUri = Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://"+ applicationContext.packageName + "/" + R.raw.alertsound)
        return NotificationCompat
            .Builder(this@SocketService, Constant.CAPTCHA_CHANNEL_ID)
            .setSmallIcon(R.drawable.camera_video_icon)
            .setContentTitle("CAPTCHA RECEIVED")
            .setContentText("open the app to enter captcha")
            .setSound(soundUri)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(activityPendingIntent)
            .addAction(action)
            .build()
    }

    private fun stop() {
        Log.d("SocketService", "stop service called")
        MySocketHandler.closeConnection()
        stopForeground(true)
        stopSelf()
    }

    private fun foregroundNotification(): Notification {

        return NotificationCompat
            .Builder(this, Constant.FOREGROUND_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentText("GuardApp is running in background")
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val REQUEST_CODE_CALL_NOTIF_INTENT = 111
        const val REQUEST_CODE_FULL_SCREEN_CALL_NOTIF_INTENT = 113
    }



}