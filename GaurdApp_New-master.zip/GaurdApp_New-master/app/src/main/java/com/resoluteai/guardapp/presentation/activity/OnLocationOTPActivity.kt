package com.resoluteai.guardapp.presentation.activity

import android.content.IntentFilter
import android.os.Bundle
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.navigation.findNavController
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.broadcast.NetworkChangeListener
import com.resoluteai.guardapp.broadcast.NetworkChangeReceiver
import com.resoluteai.guardapp.databinding.ActivityOnLocationOtpNewBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class OnLocationOTPActivity: AppCompatActivity(), NetworkChangeListener {


    private lateinit var networkChangeReceiver: NetworkChangeReceiver
    private var noInternetDialog: AlertDialog? = null
    private lateinit var binding: ActivityOnLocationOtpNewBinding



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityOnLocationOtpNewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        networkChangeReceiver = NetworkChangeReceiver(this)
        registerReceiver(networkChangeReceiver, IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"))




        val window: Window = this.window
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
        }
        window.statusBarColor = ContextCompat.getColor(this, R.color.statusBar)

        val navController = this.findNavController(R.id.nav_host_on_location_fragment)
        val navView: BottomNavigationView = findViewById(R.id.bottom_nav_on_location_view)
        navView.setupWithNavController(navController)


    }

    override fun onNetworkChanged(isConnected: Boolean) {
        if (!isConnected) {
            showNoInternetDialog()
        } else {
            dismissNoInternetDialog()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(networkChangeReceiver)
    }

    private fun showNoInternetDialog() {
        if (noInternetDialog == null) {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("No Internet Connection")
                .setMessage("Please check your internet connection and try again.")
                .setCancelable(false)

            noInternetDialog = builder.create()
            noInternetDialog?.show()
        }
    }

    private fun dismissNoInternetDialog() {
        noInternetDialog?.dismiss()
        noInternetDialog = null
    }

}