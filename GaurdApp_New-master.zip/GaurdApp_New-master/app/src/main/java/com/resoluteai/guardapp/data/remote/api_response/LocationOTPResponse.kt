package com.resoluteai.guardapp.data.remote.api_response


import com.google.gson.annotations.SerializedName

data class LocationOTPResponse(
    @SerializedName("message")
    val message: String
)