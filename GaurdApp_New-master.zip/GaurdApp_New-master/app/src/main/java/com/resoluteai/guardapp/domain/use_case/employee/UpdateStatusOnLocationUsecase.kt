package com.resoluteai.guardapp.domain.use_case.employee

import com.resoluteai.guardapp.data.remote.api_request.SendGeofenceOTPRequest
import com.resoluteai.guardapp.domain.repository.OTPRepository
import com.resoluteai.guardapp.utils.NetworkResult
import javax.inject.Inject

class UpdateStatusOnLocationUsecase @Inject constructor(
    private val otpRepository: OTPRepository
) {

    suspend operator fun invoke(requestBody: SendGeofenceOTPRequest): NetworkResult<String> =
        otpRepository.updateStatusOnLocation(requestBody)
}