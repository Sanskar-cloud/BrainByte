package com.resoluteai.guardapp.data.remote.api_response.otp

data class SendOnLocationOTPResponse(
    val message: String
)
