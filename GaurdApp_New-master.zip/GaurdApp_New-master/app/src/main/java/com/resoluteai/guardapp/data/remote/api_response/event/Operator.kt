package com.resoluteai.guardapp.data.remote.api_response.event


import com.google.gson.annotations.SerializedName

data class Operator(
    @SerializedName("employee_id")
    val employeeId: String,
    @SerializedName("name")
    val name: String,
    @SerializedName("post_id")
    val postId: String,
    @SerializedName("shift")
    val shift: Int
)

