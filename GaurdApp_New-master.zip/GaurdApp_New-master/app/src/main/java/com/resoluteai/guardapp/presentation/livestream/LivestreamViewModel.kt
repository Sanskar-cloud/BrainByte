package com.resoluteai.guardapp.presentation.livestream

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.resoluteai.guardapp.data.remote.api_response.event.Event
import com.resoluteai.guardapp.domain.use_case.event.GetEventUseCase
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.SingleLiveData
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.android.awaitFrame
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject

@HiltViewModel
class LivestreamViewModel @Inject constructor(
    private val getEventUC: GetEventUseCase
): ViewModel() {

    private var job: Job? = null

    private val timeMillis = MutableLiveData("00:00:00")

    private val _started = MutableLiveData(false)

    val started: LiveData<Boolean> = _started
    val time = timeMillis

    private val sdf = SimpleDateFormat("hh:mm:ss:SS", Locale.getDefault())


    fun startOrPause() {
        if (_started.value == true) {
            _started.value = false
            job?.cancel()
        } else {
            _started.value = true
            job = viewModelScope.launch { start() }
        }
    }

    private suspend fun CoroutineScope.start() {
        while (isActive) {
            timeMillis.value = sdf.format(Date())
            awaitFrame()
        }
    }


    private val _getEvent = SingleLiveData<NetworkResult<Event>>()
    val getEvent : LiveData<NetworkResult<Event>>
        get() = _getEvent

    fun loadAllOperators(eventId: String) {
        viewModelScope.launch {
            val result = getEventUC(eventId)

            when(result) {

                is NetworkResult.Loading -> {
                    _getEvent.postValue(NetworkResult.Loading())
                }
                is NetworkResult.Success -> {
                    _getEvent.postValue(NetworkResult.Success(result.data!!))
                }
                is NetworkResult.Failed -> {
                    _getEvent.postValue(NetworkResult.Failed(result.message))
                }
            }
        }
    }
}