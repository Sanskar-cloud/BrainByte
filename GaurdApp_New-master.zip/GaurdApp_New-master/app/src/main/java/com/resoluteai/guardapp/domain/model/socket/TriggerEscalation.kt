package com.resoluteai.guardapp.domain.model.socket

data class TriggerEscalation(
    val event_id: String,
    val employee_id: String,
    val message: String,
    val post_id: String
)
