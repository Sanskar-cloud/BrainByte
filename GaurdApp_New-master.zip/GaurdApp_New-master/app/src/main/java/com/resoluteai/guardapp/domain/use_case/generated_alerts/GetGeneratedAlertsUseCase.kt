package com.resoluteai.guardapp.domain.use_case.generated_alerts

import com.resoluteai.guardapp.domain.model.alert.GeneratedAlert
import com.resoluteai.guardapp.domain.repository.GeneratedAlertsRepository
import com.resoluteai.guardapp.utils.NetworkResult
import javax.inject.Inject

class GetGeneratedAlertsUseCase @Inject constructor(
    private val generatedAlertsRepository: GeneratedAlertsRepository
) {

    suspend operator fun invoke(empId: String): NetworkResult<List<com.resoluteai.guardapp.domain.model.alert.GeneratedAlert>>
    = generatedAlertsRepository.getGeneratedAlertsByEmpId(empId)
}