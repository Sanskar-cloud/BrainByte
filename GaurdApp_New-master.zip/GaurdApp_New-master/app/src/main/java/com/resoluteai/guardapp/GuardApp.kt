package com.resoluteai.guardapp


import android.app.Application
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentResolver
import android.content.Context
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.util.Log
import android.widget.Toast
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.Constant.CALL_CHANNEL_ID
import com.resoluteai.guardapp.utils.Constant.CALL_CHANNEL_NAME
import com.resoluteai.guardapp.utils.Constant.CAPTCHA_CHANNEL_ID
import com.resoluteai.guardapp.utils.Constant.CAPTCHA_CHANNEL_NAME
import com.resoluteai.guardapp.utils.Constant.DUTY_START_END_CHANNEL_ID
import com.resoluteai.guardapp.utils.Constant.DUTY_START_END_CHANNEL_NAME
import com.resoluteai.guardapp.utils.Constant.FOREGROUND_CHANNEL_ID
import com.resoluteai.guardapp.utils.Constant.FOREGROUND_CHANNEL_NAME
import com.resoluteai.guardapp.utils.Constant.GuardAppClass
import com.resoluteai.guardapp.utils.Constant.PROXIMITY_ALERT_CHANNEL_ID
import com.resoluteai.guardapp.utils.Constant.PROXIMITY_ALERT_CHANNEL_NAME
import com.resoluteai.guardapp.utils.Constant.TIMER_CHANNEL_ID
import com.resoluteai.guardapp.utils.Constant.TIMER_CHANNEL_NAME
import dagger.hilt.android.HiltAndroidApp


@HiltAndroidApp
class GuardApp : Application() {



    override fun onCreate() {
        super.onCreate()

        Log.d(GuardAppClass, "onCreate called")
//        val sharedPref = getSharedPreferences(Constant.MY_TOKEN_ID,Context.MODE_PRIVATE)
//        sharedPref.edit()
//            .clear()
//            .apply()

//        if (BuildConfig.DEBUG) {
//            StrictMode.setVmPolicy(
//                VmPolicy.Builder()
//                    .detectLeakedClosableObjects()
//                    .penaltyLog()
//                    .build()
//            )
//
//        }

//        AppCenter.start(
//            this, "75836b78-2c86-4701-942d-ebd9ad13df7f",
//            Analytics::class.java, Crashes::class.java
//        )

        // Check if the app has been updated
        // Check if the app has been updated
        val currentVersionCode = BuildConfig.VERSION_CODE
        val current_version_name = BuildConfig.VERSION_NAME
        val prefs = getSharedPreferences(Constant.MY_TOKEN_ID, MODE_PRIVATE)
        val storedVersionCode = prefs.getInt("app_version_code", -1)
        val storedVersionName = prefs.getString("app_version_name", "")

        if (currentVersionCode > storedVersionCode) {
            // The app has been updated, perform data clearance or migration here

            // For example, clear SharedPreferences data
            val editor = prefs.edit()
            editor.clear()
            editor.putInt("app_version_code", currentVersionCode)
            editor.putString("app_version_name", current_version_name)
            editor.apply()

            // Notify the user if necessary
            Toast.makeText(this, "App data cleared due to update.", Toast.LENGTH_SHORT).show()
        } else {

            if (storedVersionName != current_version_name) {
                val editor = prefs.edit()
                editor.clear()
                editor.putInt("app_version_code", currentVersionCode)
                editor.putString("app_version_name", current_version_name)
                editor.apply()

                // Notify the user if necessary
                Toast.makeText(this, "App data cleared due to update.", Toast.LENGTH_SHORT).show()
            }

        }

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        //Notification Channels
        createCallNotificationChannel(notificationManager)
        createCaptchaNotificationChannel(notificationManager)
        createProximityAlertNotificationChannel(notificationManager)
        createTimerNotificationChannel(notificationManager)
        createDutyStartEndNotificationChannel(notificationManager)
        createForegroundNotificationChannel(notificationManager)
        


    }

    //Channel for call notification
    private fun createCallNotificationChannel(notificationManager: NotificationManager) {
        val channel = NotificationChannel(
            CALL_CHANNEL_ID,
            CALL_CHANNEL_NAME,
            NotificationManager.IMPORTANCE_HIGH,
        ).apply {
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        channel.shouldVibrate()

        notificationManager.createNotificationChannel(channel)
    }

    //channel for captcha notification
    private fun createCaptchaNotificationChannel(notificationManager: NotificationManager) {
        val channel = NotificationChannel(
            CAPTCHA_CHANNEL_ID,
            CAPTCHA_CHANNEL_NAME,
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        channel.shouldVibrate()

        val soundUri = Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://"+ applicationContext.packageName + "/" + R.raw.message_ringtone)
        val audioAttributes = AudioAttributes.Builder()
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .build()
        channel.setSound(soundUri, audioAttributes)

        notificationManager.createNotificationChannel(channel)
    }


    //Channel for proximity alert notification
    private fun createProximityAlertNotificationChannel(notificationManager: NotificationManager) {
        val channel = NotificationChannel(
            PROXIMITY_ALERT_CHANNEL_ID,
            PROXIMITY_ALERT_CHANNEL_NAME,
            NotificationManager.IMPORTANCE_HIGH
        )

//            val soundUri = Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://"+ applicationContext.packageName + "/" + R.raw.alertsound)
//            val audioAttributes = AudioAttributes.Builder()
//                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
//                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
//                .build()
//            channel.setSound(soundUri, audioAttributes)

        notificationManager.createNotificationChannel(channel)
    }



    //Channel for timer notification
    private fun createTimerNotificationChannel(notificationManager: NotificationManager) {
        val channel = NotificationChannel(
            TIMER_CHANNEL_ID,
            TIMER_CHANNEL_NAME,
            NotificationManager.IMPORTANCE_HIGH
        )

        notificationManager.createNotificationChannel(channel)
    }

    //Channel for duty start end notification
    private fun createDutyStartEndNotificationChannel(notificationManager: NotificationManager) {
        val channel = NotificationChannel(
            DUTY_START_END_CHANNEL_ID,
            DUTY_START_END_CHANNEL_NAME,
            NotificationManager.IMPORTANCE_HIGH
        )

        notificationManager.createNotificationChannel(channel)
    }

    //Channel for foreground notification
    private fun createForegroundNotificationChannel(notificationManager: NotificationManager) {
        val channel = NotificationChannel(
            FOREGROUND_CHANNEL_ID,
            FOREGROUND_CHANNEL_NAME,
            NotificationManager.IMPORTANCE_LOW
        )

        notificationManager.createNotificationChannel(channel)
    }



}