package com.resoluteai.guardapp.utils

import android.content.res.Resources
import com.google.maps.android.PolyUtil
import com.resoluteai.guardapp.data.remote.api_response.attendance.Attendance
import kotlin.math.roundToInt


object Constant {

 //GLOBAL VARIABLES
 var IS_GUARD_IN_THE_CALL = false
 var IS_GUARD_GOT_CALL_NOTIFICATION = false
 var isBreakOnInApp = false
 var hasGuardEnteredCaptcha = true
 var isEscalationTimerEndedforBreakEnd = false
 var IS_CALL_CAME_FROM_GUARD = false
 var ISGuardLoggedInShown = false
 var IsGuardEnteredAssignmentShown = false
 var ISGuardEnteredOnLocationShown = false






 //SERVER BASE URL

 const val Socket_Path = "/socket/sockets"

 private var isDevelopment = true

 //Development
 var Alert_Service = if (isDevelopment) {
  "https://sm-alert-service-vmwe4oziqq-du.a.run.app"
 } else {
  "https://sm-alert-service-qptmim7gaq-el.a.run.app"
 }
 var Attendance_Service = if (isDevelopment) {
  "https://sm-attendance-service-vmwe4oziqq-du.a.run.app"
 } else {
  "https://sm-attendance-service-qptmim7gaq-el.a.run.app"
 }

 var Breaks_Service = if (isDevelopment) {
  "https://sm-breaks-service-vmwe4oziqq-du.a.run.app"
 } else {
  "https://sm-breaks-service-qptmim7gaq-el.a.run.app"
 }
 var Employee_Service = if (isDevelopment) {
  "https://sm-employee-service-vmwe4oziqq-du.a.run.app"
 } else {
  "https://sm-employee-service-qptmim7gaq-el.a.run.app"
 }
 var Event_Service = if (isDevelopment) {
  "https://sm-event-service-vmwe4oziqq-du.a.run.app"
 } else {
  "https://sm-event-service-qptmim7gaq-el.a.run.app"
 }
 var OTP_Service = if (isDevelopment) {
  "https://sm-otp-service-vmwe4oziqq-du.a.run.app"
 } else {
  "https://sm-otp-service-qptmim7gaq-el.a.run.app"
 }
 var Socket_Service = if (isDevelopment) {
  "http://35.207.205.99"
//  "https://9f6c-2409-40c4-f-972-220d-2db6-a4bd-2daf.ngrok-free.app"
 } else {
  "http://35.207.199.39"
 }
 var GeneratedAlert_Service = if (isDevelopment) {
  "https://sm-generated-alert-service-vmwe4oziqq-du.a.run.app"
 } else {
  "https://sm-generated-alert-service-qptmim7gaq-el.a.run.app"
 }

 //Production
 const val Alert_Service_P = "https://sm-alert-service-qptmim7gaq-el.a.run.app"
 const val Attendance_Service_P = "https://sm-attendance-service-qptmim7gaq-el.a.run.app"
 const val Breaks_Service_P = "https://sm-breaks-service-qptmim7gaq-el.a.run.app"
 const val Employee_Service_P = "https://sm-employee-service-qptmim7gaq-el.a.run.app"
 const val Event_Service_P = "https://sm-event-service-qptmim7gaq-el.a.run.app"
 const val OTP_Service_P = "https://sm-otp-service-qptmim7gaq-el.a.run.app"
 const val Socket_Service_P = "http://35.207.199.39"
 const val GeneratedAlert_Service_P = "https://sm-generated-alert-service-qptmim7gaq-el.a.run.app"




 var isEscalationTimerRunning = false


 //Listener Id for Real Time Update through Socket
 const val Get_Alerts_Listener_Id = "alerts-listener"
 const val Get_GA_Listener_Id = "ga-listener"
 const val Get_Breaks_Listener_Id = "breaks-listener"
 const val Get_Attendance_Listener_Id = "att-listener"
 const val Get_Alert_Status = "alert-status-response"
 const val Get_Device_LoggedIn_Listener_Id = "device_loggedIn"



 //API Keys
 const val API_KEY_REQUEST_OTP = "6cb5200b-1ea4-4576-a4af-d528831560b9"

 //SharedPref
 const val  MY_TOKEN_ID = "GUARD_TOKEN"
 const val  MY_TOKEN_KEY = "GUARD_TOKEN_KEY"

 /*Logger TAG*/

 //Application
 const val  GuardAppClass = "GUARD APP"

 //Repository
 const val EVENT_REPO_TAG = "Event Repository"
 const val EMPLOYEE_REPO_TAG = "Employee Repository"
 const val ATTENDANCE_REPO_TAG = "Attendance Repository"
 const val GENERATED_ALERTS_REPO_TAG = "Generated alerts Repository"

 //ViewModels

 const val HOME_VIEWMODEL_TAG = "Home ViewModel"
 const val LIVESTREAM_VIEWMODEL_TAG = "Livestream ViewModel"
 const val EMPLOYEE_VIEWMODEL_TAG = "Employee ViewModel"
 const val LOGIN_VIEWMODEL_TAG = "Login ViewModel"

 //Fragments
 const val LoginFragmentClass = "LoginFragment"
 const val AssignmentOTPClass = "AssignmentOTPFragment"
 const val HomeFragmentClass = "HomeFragment"
 const val LiveStreamFragmentClass = "LiveStreamFragment"
 const val ProfileFragmentClass = "ProfileFragment"
 const val OnLocationOTP = "OnLocationOTPActivity"

 //Activities
 const val DashboardActivityClass = "DashboardActivity"
 const val DialogActivityClass = "DialogActivity"
 const val CallActivityClass = "CallActivity"
 const val FullScreenCallNotifActivity = "FullScreenCallNotif"
 const val QRScannerActivityClass = "QRScannerActivity"

 //Services
 const val TAG_LOCATION_SERVICE = "LOCATION NEW SERVICE"
 const val ALERT_SERVICE = "Alert Service"

 //Broadcast

 const val ACCEPT_CALL_NOTIFICATION_BROADCAST = "Accepted Call Broadcast"

 const val DefaultLocationClientClass = "DefaultLocationClient"
 const val MySocketHandlerObject = "MySocketHandler"

 //other
 const val MediaPlayerHelper = "MediaPlayer Helper"

 //NOTIFICATION IDs

 //Channel :- Calls
 const val CALL_NOTIFICATION_ID = 1
 //Channel :- Captcha
 const val RECEIVE_CAPTCHA_NOTIFICATION_ID = 2
 //Channel :- Duty Start/End
 const val DUTY_START_IN_30_MIN_NOTIFICATION_ID = 3
 const val ENDED_DUTY_NOTIFICATION_ID = 4
 //Channel :- Proximity Alert - (Repetitive)
 const val NOT_AVAILABLE_IN_POST_NOTIFICATION_ID = 5
 const val NOT_AVAILABLE_IN_EVENT_NOTIFICATION_ID = 6
 //Channel :- Timer
 const val BREAK_TIMER_NOTIFICATION_ID = 7
 const val ESCALATION_TIMER_NOTIFICATION_ID = 8
 //Channel :- Foreground
 const val FOREGROUND_NOTIFICATION_ID = 10


 //Channel Ids
 const val DUTY_START_END_CHANNEL_ID = "duty-start-end"
 const val TIMER_CHANNEL_ID = "timer"
 const val PROXIMITY_ALERT_CHANNEL_ID = "proximity-alert"
 const val CAPTCHA_CHANNEL_ID = "receive_captcha"
 const val CALL_CHANNEL_ID = "calls"
 const val FOREGROUND_CHANNEL_ID = "foreground"

 //Channel Name
 const val DUTY_START_END_CHANNEL_NAME = "Duty Start/End"
 const val TIMER_CHANNEL_NAME = "Timer"
 const val PROXIMITY_ALERT_CHANNEL_NAME = "Proximity Alert"
 const val CAPTCHA_CHANNEL_NAME = "Captcha"
 const val CALL_CHANNEL_NAME = "Calls"
 const val FOREGROUND_CHANNEL_NAME = "Foreground"

 //Action- Intent
 const val Action_Location = "location_coordinates"
 const val Action_EndBreakConfirmation = "break_end_confirmation"
 const val Action_Event_Ended = "action_event_ended"
 const val Action_show_break_end_info = "break_end_info"
 const val Action_End_Break = "end_break_timer"
 const val Action_Call_Notification = "call_notification"
 const val Action_Captcha_Verification = "action_captcha_verification"
 const val Action_Update_Attendance = "attendance-listener"
 const val Action_Status_Update = "status-update"

 //Socket-Event
 const val Hadshakecompleted="handshake-completed"
 const val CloseTheCallEvent = "close-the-call"
 const val CallRequestApprovalEvent = "call-request-approval"


 fun isLatLngInsidePolygon(latLng: com.google.android.gms.maps.model.LatLng, polygonCoords: List<com.google.android.gms.maps.model.LatLng>): Boolean {
  return PolyUtil.containsLocation(latLng, polygonCoords, true)
 }
 fun Int.dpToPx(): Int {
  val density = Resources.getSystem().displayMetrics.density
  return (this * density).roundToInt()
 }


}
