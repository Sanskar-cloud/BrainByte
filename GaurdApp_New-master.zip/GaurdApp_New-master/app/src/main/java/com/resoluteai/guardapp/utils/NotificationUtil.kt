package com.resoluteai.guardapp.utils

import android.app.Notification
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import com.resoluteai.guardapp.R

fun createLocationAlertNotification(desc: String, action: NotificationCompat.Action? = null, context: Context): Notification {

    return if (action != null) {
        NotificationCompat.Builder(context, Constant.PROXIMITY_ALERT_CHANNEL_ID)
            .setContentTitle("Warning: Location Alert")
            .setContentText(desc)
            .setSmallIcon(R.drawable.ic_launcher_background)
            .addAction(action)
            .setOngoing(false)
            .build()
    }
    else {
        NotificationCompat.Builder(context, Constant.PROXIMITY_ALERT_CHANNEL_ID)
            .setContentTitle("Warning: Location Alert")
            .setContentText(desc)
            .setSmallIcon(R.drawable.ic_launcher_background)
            .setOngoing(false)
            .build()
    }
}


fun createTimerNotification(
    timerName: String,
    contentText: String,
    context: Context,
    breakName: String? = null,
    isEscalationTimer: Boolean = false
): Notification {

    if (isEscalationTimer) {
        return NotificationCompat.Builder(context, Constant.TIMER_CHANNEL_ID)
            .setContentTitle("$timerName is running")
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_launcher_background)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationManager.IMPORTANCE_HIGH)
            .build()
    } else {
        return NotificationCompat.Builder(context, Constant.TIMER_CHANNEL_ID)
            .setContentTitle("You are on $breakName")
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_launcher_background)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationManager.IMPORTANCE_HIGH)
            .build()
    }


}

fun foregroundNotification(context: Context): Notification {

    return NotificationCompat
        .Builder(context, Constant.FOREGROUND_CHANNEL_ID)
        .setSmallIcon(R.drawable.ic_launcher_foreground)
        .setContentText("GuardApp is running in background")
        .setPriority(NotificationCompat.PRIORITY_MIN)
        .setCategory(Notification.CATEGORY_SERVICE)
        .build()
}