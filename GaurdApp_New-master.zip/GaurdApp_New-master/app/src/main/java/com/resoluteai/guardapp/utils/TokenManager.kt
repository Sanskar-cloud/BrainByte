package com.resoluteai.guardapp.utils

import android.annotation.SuppressLint
import android.content.Context
import com.google.android.gms.maps.model.LatLng
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.resoluteai.guardapp.utils.Constant.MY_TOKEN_ID
import com.resoluteai.guardapp.utils.Constant.MY_TOKEN_KEY
import javax.inject.Inject
import dagger.hilt.android.qualifiers.ApplicationContext

class TokenManager @Inject constructor (@ApplicationContext context: Context) {

   private val sharedPref = context.getSharedPreferences(MY_TOKEN_ID,Context.MODE_PRIVATE)

    fun clearData() {
        sharedPref.edit()
            .clear()
            .apply()
    }

    @SuppressLint("CommitPrefEdits")
    fun saveToken(token:String){
        val editor = sharedPref.edit()
        editor.putString(MY_TOKEN_KEY,token)
        editor.apply()
    }

    fun  getToken():String{
        return  sharedPref.getString(MY_TOKEN_KEY,"").toString()
    }




    fun saveBreakId(id: String) {
        val editor = sharedPref.edit()
        editor.putString("BREAK_ID", id)
        editor.apply()
    }

    fun getBreakId(): String {
        return  sharedPref.getString("BREAK_ID","").toString()
    }

    fun saveCurrentBreakName(id: String) {
        val editor = sharedPref.edit()
        editor.putString("BREAK_NAME", id)
        editor.apply()
    }

    fun getCurrentBreakName(): String {
        return  sharedPref.getString("BREAK_NAME","").toString()
    }

    fun saveDutyRunningState(value: Boolean) {
        val editor = sharedPref.edit()
        editor.putBoolean("Duty_running", value)
        editor.apply()
    }

    fun getDutyRunningState(): Boolean {
        return  sharedPref.getBoolean("Duty_running", false)
    }

    fun saveUidai(id: String) {
        val editor = sharedPref.edit()
        editor.putString("UIDAI", id)
        editor.apply()
    }

    fun getUidai(): String {
        return  sharedPref.getString("UIDAI","").toString()
    }

    fun saveEventName(name: String) {
        val editor = sharedPref.edit()
        editor.putString("Event_name", name)
        editor.apply()
    }

    fun getEventName(): String {
        return  sharedPref.getString("Event_name","").toString()
    }


    fun saveReceiverId(id: String) {
        val editor = sharedPref.edit()
        editor.putString("RECEIVERID", id)
        editor.apply()
    }

    fun getReceiverId(): String {
        return  sharedPref.getString("RECEIVERID","").toString()
    }



    fun saveCallerEmpId(id: String) {
        val editor = sharedPref.edit()
        editor.putString("Caller_Emp_id", id)
        editor.apply()
    }

    fun getCallerEmpId(): String {
        return  sharedPref.getString("Caller_Emp_id","").toString()
    }



    fun saveProximity(proximity :Int){
        val editor = sharedPref.edit()
        editor.putInt("PROXIMITY", proximity)
        editor.apply()
    }

    fun saveSocketIdForCall(id: String) {
        val editor = sharedPref.edit()
        editor.putString("SOCKET_ID",id)
        editor.apply()
    }

    fun getSocketIdForCall(): String {
        return  sharedPref.getString("SOCKET_ID","").toString()
    }

    fun saveEmployeeId(id: String) {
        val editor = sharedPref.edit()
        editor.putString("EMP_ID",id)
        editor.apply()
    }

    fun saveStatusCode(code: Int) {
        val editor = sharedPref.edit()
        editor.putInt("STATUS",code)
        editor.apply()
    }

    fun getStatusCode():Int{
        return sharedPref.getInt("STATUS",0)
    }


    fun saveEmail(email: String) {
        val editor = sharedPref.edit()
        editor.putString("EMAIL",email)
        editor.apply()
    }

    fun getEmail(): String {
        return  sharedPref.getString("EMAIL","").toString()
    }

    fun saveOtherEmployeeId(id:String){
        val editor = sharedPref.edit()
        editor.putString("otherEmpId",id)
        editor.apply()
    }
    fun getOtherEmployeeId(): String{
        return  sharedPref.getString("otherEmpId","").toString()
    }

    fun saveOtherEmpEventId(id:String){
        val editor = sharedPref.edit()
        editor.putString("otherEmpEventId",id)
        editor.apply()
    }

    fun getOtherEmpEventId(): String{
        return  sharedPref.getString("otherEmpEventId","").toString()
    }



    fun saveProfileName(name: String) {
        val editor = sharedPref.edit()
        editor.putString("profile_name",name)
        editor.apply()
    }

    fun getProfileName(): String {
        return  sharedPref.getString("profile_name","").toString()
    }



    fun saveSomeImportantDetail(
        location: String,
        client: String,
        phoneNumber: String,
        empId: String,
        postId: String,
        latitude: Float,
        longitude: Float,
        proximity: Int,
        role: String,
    ){

        sharedPref.edit()
            .putString("LOCATION_ID",location)
            .putString("CLIENT_ID",client)
            .putString("MOBILE_N",phoneNumber)
            .putString("EMP_ID",empId)
            .putString("POST_ID",postId)
            .putFloat("LAT",latitude)
            .putFloat("LONG",longitude)
            .putInt("PROXIMITY",proximity)
            .putString("ROLE", role)
            .apply()

    }

    fun setProximity(value: Int)
    {
        val editor = sharedPref.edit()
        editor.putInt("PROXIMITY",value)
        editor.apply()
    }

    fun getPromixity():Int{
        return sharedPref.getInt("PROXIMITY",0)
    }

    fun setPostLatitude(latitude: Float) {
        val editor = sharedPref.edit()
        editor.putFloat("LAT",latitude)
        editor.apply()
    }

    fun getPostLatitude():Float{
        return sharedPref.getFloat("LAT", 0F)
    }


    fun setPostLongitude(longitude: Float) {
        val editor = sharedPref.edit()
        editor.putFloat("LONG",longitude)
        editor.apply()
    }

    fun getPostLongitude():Float{
        return sharedPref.getFloat("LONG", 0F)
    }


    fun  getSomeImportantClientID():String{
        return  sharedPref.getString("CLIENT_ID","").toString()
    }

    fun getSomePostId():String{
        return sharedPref.getString("POST_ID","").toString()
    }


    fun setLocationId(locationId: String) {
        val editTor = sharedPref.edit()
        editTor.putString("LOCATION_ID",locationId)
        editTor.apply()
    }

    fun  getLocationID():String{
        return  sharedPref.getString("LOCATION_ID","").toString()
    }

    fun  getMobileNumber():String{
        return  sharedPref.getString("MOBILE_N","").toString()
    }

    fun getEmployeeID():String {
        return sharedPref.getString("EMP_ID","").toString()
    }


    fun saveEventId(eventId :String){
        val editor = sharedPref.edit()
        editor.putString("EVENT_ID",eventId)
        editor.apply()

    }

    fun  getEventID():String{
        return sharedPref.getString("EVENT_ID","").toString();
    }

    fun  getRole():String {
        return sharedPref.getString("ROLE","").toString();
    }

    fun saveGeoFunLiveLocation(coordinates: List<LatLng>?){
        val polygonCoordsJson = Gson().toJson(coordinates)
        val editor = sharedPref.edit()
        editor.putString("polygonCoordsJson", polygonCoordsJson)?.apply()
    }

    fun getGeoFunLiveLocation(): List<LatLng>? {
        val polygonCoordsJson = sharedPref?.getString("polygonCoordsJson", "")
        val type = object : TypeToken<List<LatLng>>() {}.type
        return Gson().fromJson<List<LatLng>>(polygonCoordsJson, type)
    }

    fun savePostId(postId: String)
    {
        val editor = sharedPref.edit()
        editor.putString("POST_ID",postId)
        editor.apply()
    }

    fun saveEscalationTimeout(timeout: String)
    {
        val editor = sharedPref.edit()
        editor.putString("ESC_TIMEOUT", timeout)
        editor.apply()
    }

    fun getEscalationTimeout():String? {
        return sharedPref.getString("ESC_TIMEOUT","")
    }

    fun saveShiftStartTime(startTime: String)
    {
        val editor = sharedPref.edit()
        editor.putString("START_TIME", startTime)
        editor.apply()
    }

    fun getShiftStartTime():String {
        return sharedPref.getString("START_TIME","").toString()
    }

    fun saveShiftEndTime(endTime: String)
    {
        val editor = sharedPref.edit()
        editor.putString("END_TIME", endTime)
        editor.apply()
    }

    fun getShiftEndTime():String {
        return sharedPref.getString("END_TIME","").toString()
    }

    fun saveShiftExtensionHr(extensionHr: Int)
    {
        val editor = sharedPref.edit()
        editor.putInt("Extension_Hr", extensionHr)
        editor.apply()
    }

    fun getShiftExtensionHr():Int {
        return sharedPref.getInt("Extension_Hr",0)
    }

    fun saveShiftExtensionMn(extensionMn: Int)
    {
        val editor = sharedPref.edit()
        editor.putInt("Extension_Mn", extensionMn)
        editor.apply()
    }

    fun getShiftExtensionMn():Int {
        return sharedPref.getInt("Extension_Mn", 0)
    }

    fun saveBreakTimer(time: Int)
    {
        val editor = sharedPref.edit()
        editor.putInt("BREAK_TIME", time)
        editor.apply()
    }

    fun getBreakTimer(): Int {
        return sharedPref.getInt("BREAK_TIME",0)
    }

    fun saveBreakNeedReplacement(key: Boolean)
    {
        val editor = sharedPref.edit()
        editor.putBoolean("BREAK_Need_Replacement", key)
        editor.apply()
    }

    fun getBreakNeedReplacement(): Boolean {
        return sharedPref.getBoolean("BREAK_Need_Replacement", false)
    }

    fun saveStartDate(startDate: String)
    {
        val editor = sharedPref.edit()
        editor.putString("START_DATE", startDate)
        editor.apply()
    }

    fun getStartDate(): String? {
        return sharedPref.getString("START_DATE","")
    }

    fun saveEndDate(endDate: String)
    {
        val editor = sharedPref.edit()
        editor.putString("END_DATE", endDate)
        editor.apply()
    }

    fun getEndDate(): String? {
        return sharedPref.getString("END_DATE","")
    }



    fun savePostName(name: String) {
        val editor = sharedPref.edit()
        editor.putString("POST_NAME", name)
        editor.apply()
    }
    fun getPostName(): String? {
        return sharedPref.getString("POST_NAME","")
    }

    fun saveNeedReplacementBreak(value: Boolean) {
        val editor = sharedPref.edit()
        editor.putBoolean("NEED_REPLACEMENT", value)
        editor.apply()
    }


    fun savePhoneNumber(phoneNumber: String) {
        val editor = sharedPref.edit()
        editor.putString("POST_NAME", phoneNumber)
        editor.apply()
    }

    fun saveClientId(id: String) {
        val editor = sharedPref.edit()
        editor.putString("POST_NAME", id)
        editor.apply()
    }

    fun saveShiftNo(no: Int)
    {
        val editor = sharedPref.edit()
        editor.putInt("SHIFT_NO", no)
        editor.apply()
    }

    fun getShiftNo():Int {
        return sharedPref.getInt("SHIFT_NO", 0)
    }



}