package com.resoluteai.guardapp.domain.model.auth.updated


import com.google.gson.annotations.SerializedName

data class Role(
    @SerializedName("acronym")
    val acronym: String,
    @SerializedName("admin_id")
    val adminId: String,
    @SerializedName("client_id")
    val clientId: String,
    @SerializedName("created_at")
    val createdAt: String,
    @SerializedName("hierarchy_level")
    val hierarchyLevel: Int,
    @SerializedName("id")
    val id: String,
    @SerializedName("is_active")
    val isActive: Boolean,
    @SerializedName("is_deleted")
    val isDeleted: Boolean,
    @SerializedName("is_manage_alert")
    val isManageAlert: Boolean,
    @SerializedName("is_manage_attendance")
    val isManageAttendance: Boolean,
    @SerializedName("is_manage_break")
    val isManageBreak: Boolean,
    @SerializedName("is_manage_camera")
    val isManageCamera: Boolean,
    @SerializedName("is_manage_dashboard")
    val isManageDashboard: Boolean,
    @SerializedName("is_manage_employees")
    val isManageEmployees: Boolean,
    @SerializedName("is_manage_event")
    val isManageEvent: Boolean,
    @SerializedName("is_manage_location")
    val isManageLocation: Boolean,
    @SerializedName("is_manage_post")
    val isManagePost: Boolean,
    @SerializedName("is_manage_role")
    val isManageRole: Boolean,
    @SerializedName("name")
    val name: String,
    @SerializedName("updated_at")
    val updatedAt: String
)