package com.resoluteai.guardapp.broadcast

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class StatusUpdate(private val callback: StatusUpdateCallback): BroadcastReceiver() {

    interface StatusUpdateCallback {
        fun updateStatus(status: Int)
    }

    override fun onReceive(context: Context?, intent: Intent?) {
        val status = intent?.getIntExtra("status_code", 0)
        if (status != 0 && status != null) {
            callback.updateStatus(status)
        }
    }
}