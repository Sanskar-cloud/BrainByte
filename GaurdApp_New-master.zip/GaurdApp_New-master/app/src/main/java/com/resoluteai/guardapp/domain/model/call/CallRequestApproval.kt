package com.resoluteai.guardapp.domain.model.call

data class CallRequestApproval(
    val accepted: Boolean,
    val data: com.resoluteai.guardapp.domain.model.call.CallRequest? = null
)
