package com.resoluteai.guardapp.presentation.activity

import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.Log
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.budiyev.android.codescanner.AutoFocusMode
import com.budiyev.android.codescanner.CodeScanner
import com.budiyev.android.codescanner.DecodeCallback
import com.budiyev.android.codescanner.ErrorCallback

import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.databinding.ActivityQrScanner2Binding
import com.resoluteai.guardapp.domain.model.socket.HandshakeCompletedEvent

import com.resoluteai.guardapp.domain.model.socket.OperatorHandshkae
import com.resoluteai.guardapp.presentation.dialog.SendLoginOTPDialog
import com.resoluteai.guardapp.socket.MySocketHandler
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.Constant.API_KEY_REQUEST_OTP
import com.resoluteai.guardapp.utils.Constant.Hadshakecompleted
import com.resoluteai.guardapp.utils.TokenManager
import com.resoluteai.guardapp.utils.showToast
import dagger.hilt.android.AndroidEntryPoint
import org.json.JSONException
import org.json.JSONObject
import java.util.Calendar
import java.util.UUID
import javax.inject.Inject



@AndroidEntryPoint
class QrScannerActivity2 : AppCompatActivity() {

    private var emittedCommunicationId: String? = null

    private val CAMERA_REQUEST_CODE = 101

    private lateinit var binding: ActivityQrScanner2Binding
    private lateinit var sendLoginOTPDialog: SendLoginOTPDialog
    @Inject
    lateinit var tokenManager: TokenManager

    private lateinit var codeScanner: CodeScanner

    private var isQRCodeValid = false


    private fun startCameraPreview() {

        binding.codeScannerView.setOnClickListener {
            codeScanner.startPreview()
            MySocketHandler.establishConnection()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQrScanner2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        codeScanner = CodeScanner(this, binding.codeScannerView)
        codeScanner.camera = CodeScanner.CAMERA_BACK
        codeScanner.formats = CodeScanner.ALL_FORMATS
        codeScanner.autoFocusMode = AutoFocusMode.SAFE
        codeScanner.isAutoFocusEnabled = true
        codeScanner.isFlashEnabled = false

        if (ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.CAMERA),
                CAMERA_REQUEST_CODE
            )
        } else {
            startCameraPreview()
        }

        sendLoginOTPDialog = SendLoginOTPDialog()
        if (MySocketHandler.getSocket() == null) {

            try {
                MySocketHandler.setSocket(
                    tokenManager.getEventID(),
                    tokenManager.getEmployeeID(),
                    tokenManager.getSomeImportantClientID()
                )
                MySocketHandler.establishConnection()
            } catch (e: Exception) {
                e.printStackTrace()
            }

        }


        codeScanner.decodeCallback = DecodeCallback {
            runOnUiThread {
                sendLoginOTPDialog.show(supportFragmentManager, SendLoginOTPDialog.TAG)

                Log.d(Constant.QRScannerActivityClass, "Scan Success: ${it.text}")
                val intentData = it.text.split(" ")
                if (intentData.size == 4) {

                    val rightNow: Calendar = Calendar.getInstance()
                    val currentHourIn24Format = rightNow.get(Calendar.HOUR_OF_DAY)
                    val currentMin = rightNow.get(Calendar.MINUTE)
                    val timestamp = intentData[0]
                    val empId = intentData[1]
                    val eventId = intentData[2]

                    val splittedTime = timestamp.split(":")
                    val codeHr = splittedTime[0].toInt()
                    val codeMn = splittedTime[1].toInt()

                    isQRCodeValid = if (currentHourIn24Format >= codeHr) {

                        if (currentHourIn24Format == codeHr) {
                            val diff = (currentMin - codeMn) <= 2 && (currentMin - codeMn) >= 0
                            Log.d("QRScannerAct", " == codeHr $diff")
                            diff


                        } else {
                            val diff =
                                ((60 - codeMn) + currentMin) <= 2 && (currentMin - codeMn) >= 0
                            Log.d("QRScannerAct", " > codeHr $diff")
                            diff
                        }
                    } else {
                        Log.d("QRScannerAct", " < codeHr false")
                        false
                    }









                    if (empId.isNotEmpty() && eventId.isNotEmpty() && isQRCodeValid) {

                        if (intentData[3] == "handshake") {


                            Log.d(Constant.QRScannerActivityClass, "QRType: ${intentData[0]}")
                            val communicationId = UUID.randomUUID().toString()
                            emittedCommunicationId = communicationId




                                MySocketHandler.oprhandshake(
                                    OperatorHandshkae(
                                        scanned_op_id =empId,
                                        op_id = tokenManager.getEmployeeID(),
                                        api_key = API_KEY_REQUEST_OTP,
                                        event_id = tokenManager.getEventID(),
                                        communication_id = communicationId


                                    )




                                )
                                Log.d(
                                    Constant.QRScannerActivityClass,
                                    "EVENT EMITTED"
                                )
                                Log.d(Constant.QRScannerActivityClass, "Delay of 1 minute completed")
                                Log.d(Constant.QRScannerActivityClass, "${MySocketHandler.getSocket()}")
//                                if (MySocketHandler.getSocket() == null) {
//
//                                    try {
//                                        MySocketHandler.setSocket(
//                                            tokenManager.getEventID(),
//                                            tokenManager.getEmployeeID(),
//                                            tokenManager.getSomeImportantClientID()
//                                        )
//                                        MySocketHandler.establishConnection()
//                                    } catch (e: Exception) {
//                                        e.printStackTrace()
//                                    }
//
//                                }
                                Log.d(
                                    Constant.QRScannerActivityClass,
                                    "${MySocketHandler.getSocket()}"
                                )
                                MySocketHandler.getSocket()?.on("update-call-ids") { args ->
                                    Log.d(
                                        Constant.QRScannerActivityClass,
                                        "${MySocketHandler.getSocket()}"
                                    )
                                    Log.d(
                                        Constant.QRScannerActivityClass,
                                        "EVENT call id"
                                    )

                                    if (args.isNotEmpty()) {
                                        Log.d(
                                            Constant.QRScannerActivityClass,
                                            "EVENT call id"
                                        )


                                        val eventData = args[0].toString()


                                        try {
                                            val jsonObject = JSONObject(eventData)
                                            val success = jsonObject.getBoolean("success")
                                            val receivedCommunicationId = jsonObject.getString("communication_id")

                                            val expectedCommunicationId =emittedCommunicationId


                                            if (success && receivedCommunicationId == expectedCommunicationId) {
                                                runOnUiThread {

                                                    val handshakeCompletedEvent = HandshakeCompletedEvent(success, receivedCommunicationId)
                                                    showDialog(handshakeCompletedEvent)
                                                }
                                            } else {

                                            }
                                        } catch (e: JSONException) {
                                            e.printStackTrace()
                                        }
                                    }
                                }
                                MySocketHandler.getSocket()?.on("handshake-completed") { args ->
                                    Log.d(
                                        Constant.QRScannerActivityClass,
                                        "${MySocketHandler.getSocket()}"
                                    )
                                    Log.d(
                                        Constant.QRScannerActivityClass,
                                        "EVENT hans"
                                    )

                                    if (args.isNotEmpty()) {
                                        Log.d(
                                            Constant.QRScannerActivityClass,
                                            "EVENT EMITTED"
                                        )


                                        val eventData = args[0].toString()


                                        try {
                                            val jsonObject = JSONObject(eventData)
                                            Log.d(
                                                Constant.QRScannerActivityClass,
                                                "$eventData"
                                            )

                                            val success = jsonObject.getBoolean("success")
                                            val receivedCommunicationId = jsonObject.getString("communication_id")

                                            val expectedCommunicationId =emittedCommunicationId


                                            if (success && receivedCommunicationId == expectedCommunicationId) {
                                                runOnUiThread {

                                                    val handshakeCompletedEvent = HandshakeCompletedEvent(success, receivedCommunicationId)
                                                    showDialog(handshakeCompletedEvent)
                                                    if(sendLoginOTPDialog.isVisible)
                                                    sendLoginOTPDialog.dismiss()
                                                }
                                            } else {

                                            }
                                        } catch (e: JSONException) {
                                            e.printStackTrace()
                                        }
                                    }
                                }



                            }




                        }

                    }
                }

            }



        codeScanner.errorCallback = ErrorCallback {
            runOnUiThread {
                showToast("Scan failed: " + it.message)
            }
        }


















    }


    private fun showDialog(handshakeCompletedEvent: HandshakeCompletedEvent) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Handshake Completed")
        if (handshakeCompletedEvent.success) {
            builder.setMessage("Handshake was successful")
        } else {
            builder.setMessage("Handshake failed")
        }
        builder.setPositiveButton("OK") { dialog, _ ->
            dialog.dismiss()
        }
        val dialog = builder.create()
        dialog.show()
    }


    override fun onResume() {
        super.onResume()
        codeScanner.startPreview()
    }

    override fun onPause() {
        codeScanner.releaseResources()
        super.onPause()
    }

}