package com.resoluteai.guardapp.presentation.profile

import android.content.Intent
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.WriterException
import com.google.zxing.common.BitMatrix
import com.journeyapps.barcodescanner.BarcodeEncoder
import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.databinding.FragmentProfileBinding
import com.resoluteai.guardapp.domain.model.attendance.HistoryLog
import com.resoluteai.guardapp.presentation.LocationViewModel
import com.resoluteai.guardapp.service.LocationService
import com.resoluteai.guardapp.service.SocketService
import com.resoluteai.guardapp.presentation.activity.AuthActivity
import com.resoluteai.guardapp.presentation.activity.QrScannerActivity
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.Constant.LoginFragmentClass
import com.resoluteai.guardapp.utils.Constant.ProfileFragmentClass
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.TokenManager
import com.resoluteai.guardapp.utils.isServiceRunning
import com.resoluteai.guardapp.utils.logout
import com.resoluteai.guardapp.utils.showToast
import dagger.hilt.android.AndroidEntryPoint
import java.text.SimpleDateFormat
import java.util.Calendar
import javax.inject.Inject


@AndroidEntryPoint
class ProfileFragment : Fragment() {

    private  var _binding:FragmentProfileBinding ?= null
    private val binding get() = _binding

    private val profileViewModel by viewModels<ProfileViewModel>()
    private lateinit var locationViewModel: LocationViewModel
    @Inject
    lateinit var  tokenManager: TokenManager
    private var sourceLocation: String? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {



        _binding = FragmentProfileBinding.inflate(inflater,container,false)
          inflater.inflate(R.layout.dialog_logout, container, false)

        profileViewModel.getAttendance()


        if (tokenManager.getStatusCode() == 3) {
            binding?.apply {
                qrScannerProfile.visibility = View.VISIBLE
            }
        }


        locationViewModel = ViewModelProvider(this)[LocationViewModel::class.java]

        locationViewModel.getLastKnownLocation().observe(viewLifecycleOwner) { location ->
            if (location != null) {
                sourceLocation = "${location.latitude},${location.longitude}"
            } else {
                // Handle the case when no location is available
            }
        }



        binding?.apply {
            qrScannerProfile.setOnClickListener {
                val intent = Intent(requireContext(), QrScannerActivity :: class.java)
                startActivity(intent)

            }

            tvPrivacyPolicy.setOnClickListener {
                val url = "https://www.securitymechanics.com/privacy-policy/"

                // Create an Intent to open the URL in a web browser
                val intent = Intent(Intent.ACTION_VIEW)
                intent.data = Uri.parse(url)
                startActivity(intent)
            }

            refreshQRLayout.setOnClickListener {
                if (tokenManager.getEmployeeID().isNotEmpty() && tokenManager.getEventID().isNotEmpty()) {
                    try {
                        val rightNow: Calendar = Calendar.getInstance()
                        val currentHourIn24Format = rightNow.get(Calendar.HOUR_OF_DAY).toString()
                        val currentMin = rightNow.get(Calendar.MINUTE).toString()
                        val multiFormatWriter = MultiFormatWriter()
                        val bitmatrix : BitMatrix = multiFormatWriter.encode(
                            "$currentHourIn24Format:$currentMin ${tokenManager.getEmployeeID()} ${tokenManager.getEventID()} handshake",
                            BarcodeFormat.QR_CODE,
                            300,
                            300
                        )
                        val barcodeEncoder = BarcodeEncoder()
                        val bitmap = barcodeEncoder.createBitmap(bitmatrix)
                        binding?.qrcodeIvNew?.setImageBitmap(bitmap)
                        Toast.makeText(requireContext(), "QR Code Generated Successfully \n क्यूआर कोड सफलतापूर्वक जनरेट हुआ।", Toast.LENGTH_SHORT).show()

                    } catch(e: WriterException){
                        e.printStackTrace()
                    }
                }
            }

            button3.setOnClickListener{

                tokenManager.clearData()
                showCustomLogoutConfirmationDialog()



            }



        }


        return binding?.root
    }

    private fun showCustomLogoutConfirmationDialog() {

        val builder = AlertDialog.Builder(requireContext())
        val inflater = LayoutInflater.from(requireContext())
        val view = inflater.inflate(R.layout.dialog_logout, null)

        builder.setView(view)

        val dialog = builder.create()
        val yesButton = view.findViewById<LinearLayout>(R.id.alertConfirmed)
        val No = view.findViewById<LinearLayout>(R.id.cancel)

        yesButton.setOnClickListener {
            // Handle logout action here
            // For example, you can start the login activity or clear user session
            // startActivity(Intent(this, LoginActivity::class.java))
            // finish()
            logout()
            if (requireActivity().isServiceRunning(LocationService::class.java)) {
                //stop Location Service
                Intent(requireActivity(), LocationService::class.java).apply {
                    action = LocationService.ACTION_STOP
                    requireActivity().startForegroundService(this)
                    Log.d("Activity LOCATION SERVICE", "service started")
                }
            } else {
                Log.d(Constant.DashboardActivityClass, "Service is Running")

            }

            if(requireActivity().isServiceRunning(SocketService::class.java)) {
                //stop Alert Service
                Intent(requireActivity(), SocketService::class.java).apply {
                    action = SocketService.ACTION_STOP
                    requireActivity().startForegroundService(this)
                    Log.d("Dashboard Socket SERVICE", "service started")
                }
            }

            activity?.startActivity(Intent(requireActivity(), AuthActivity:: class.java))
            activity?.finish()

            dialog.dismiss()
        }

        No.setOnClickListener {
            // Dismiss the dialog if the user clicks "No"
            dialog.dismiss()
        }

        dialog.show()
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        Log.d(ProfileFragmentClass, tokenManager.getEventName())

        binding?.apply {
            gaurdEvent.text = "Event\t\t\t\t\t\t:\t${tokenManager.getEventName()}"
            gaurdName.text = "${tokenManager.getProfileName()}"
            gaurdId.text = "UIDAI\t\t\t\t\t\t:\t${tokenManager.getUidai()}"
            emailID.text = "Email\t\t\t\t\t\t:\t${tokenManager.getEmail()}"
            mobileNumber.text = "Mobile No.\t\t:\t${tokenManager.getMobileNumber()}"
            gaurdPost.text = "Post Name\t:\t${tokenManager.getPostName()}"
            gaurdShiftTime.text = "Shift Time\t\t:\t${tokenManager.getShiftStartTime()} to ${tokenManager.getShiftEndTime()}"
        }

        if (tokenManager.getEmployeeID().isNotEmpty() && tokenManager.getEventID().isNotEmpty()) {
            try {
                val rightNow: Calendar = Calendar.getInstance()
                val currentHourIn24Format = rightNow.get(Calendar.HOUR_OF_DAY).toString()
                val currentMin = rightNow.get(Calendar.MINUTE).toString()
                val multiFormatWriter = MultiFormatWriter()
                val bitmatrix : BitMatrix = multiFormatWriter.encode(
                    "$currentHourIn24Format:$currentMin ${tokenManager.getEmployeeID()} ${tokenManager.getEventID()} handshake",
                    BarcodeFormat.QR_CODE,
                    300,
                    300
                )
                val barcodeEncoder = BarcodeEncoder()
                val bitmap = barcodeEncoder.createBitmap(bitmatrix)
                binding?.qrcodeIvNew?.setImageBitmap(bitmap)

            } catch(e: WriterException){
                e.printStackTrace()
            }
        }

        profileViewModel.getAttendance.observe(viewLifecycleOwner) { result ->

            when(result) {

                is NetworkResult.Loading -> {

                }

                is NetworkResult.Success -> {
                    Log.d(ProfileFragmentClass, " Attendance Log ${result.data?.attendanceLog}")
                    Log.d(ProfileFragmentClass, " Attendance Log ${result.data?.attendanceLog?.get("2023-07-20")}")

                    binding?.apply {
                        attendanceRV.layoutManager = LinearLayoutManager(requireActivity())
                        attendanceRV.addItemDecoration(
                            object : RecyclerView.ItemDecoration() {

                                override fun getItemOffsets(
                                    outRect: Rect,
                                    view: View,
                                    parent: RecyclerView,
                                    state: RecyclerView.State
                                ) {
                                    outRect.top = 20
                                    outRect.bottom = 20
                                }
                            }
                        )

                        //attendanceRV.isNestedScrollingEnabled = false


                        val cal = Calendar.getInstance()
                        val sdf = SimpleDateFormat("yyyy-MM-dd")

                        val dateKeyList: MutableList<String> = mutableListOf()




                        (1..7).forEach {
                            val dateOfToday = sdf.format(cal.time)
                            Log.d(ProfileFragmentClass, "$dateKeyList")
                            dateKeyList.add(dateOfToday)
                            if (it != 7) {
                                cal.add(Calendar.DATE, -1)
                            }

                        }

                        val logs = ArrayList<HistoryLog>()

                        dateKeyList.forEach { date ->

                            val log = result.data?.attendanceLog?.get(date)
                            Log.d(LoginFragmentClass, "$log")
                            if (log != null) {
                                logs.add(
                                    HistoryLog(
                                        dutyDate = date,
                                        is_present = log.is_present,
                                        start_duty = log.start_duty,
                                        punch_in_time = log.punch_in_time,
                                        punch_out_time = log.punch_out_time,
                                        relieved = log.relieved
                                    )
                                )
                            }

                        }.also {
                            val attendanceAdapter = AttendanceAdapter(
                                context = requireContext(),
                                attendances = logs

                            )
                            attendanceRV.adapter = attendanceAdapter
                            attendanceRV.setHasFixedSize(true)
                        }



                    }

                    binding?.shimmerViewContainer?.hideShimmer()
                }

                is NetworkResult.Failed -> {
                    binding?.shimmerViewContainer?.hideShimmer()
                }
            }

        }




    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
        Log.d(ProfileFragmentClass, "ondestroy called")
    }


}
