package com.resoluteai.guardapp.domain.model.auth.updated

import com.resoluteai.guardapp.domain.model.auth.DeviceInfo

data class UserInfoClass(
    val api_key: String,
    val otp: String,
    val phone_number: String,
    val device: DeviceInfo? = null
)