package com.resoluteai.guardapp.presentation.profile

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.domain.model.attendance.HistoryLog

class AttendanceAdapter(
    private val context: Context,
    private val attendances: ArrayList<HistoryLog>
) : RecyclerView.Adapter<AttendanceAdapter.ViewHolder>() {

    private val fadeOut: Animation by lazy {
        AnimationUtils.loadAnimation(
            context,
            R.anim.fade_out
        )
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {



        val historyItemCard: LinearLayout
        val shiftDate: TextView
        val isPresent: TextView
        val startTime: TextView
        val punchInTime: TextView
        val punchOutTime: TextView
        val relivedTime: TextView

        init {

            historyItemCard = view.findViewById(R.id.historyItemCard)
            shiftDate = view.findViewById(R.id.shift_date)
            isPresent = view.findViewById(R.id.isPresent_tv)
            startTime = view.findViewById(R.id.startTime_tv)
            punchInTime = view.findViewById(R.id.punchInTime_tv)
            punchOutTime = view.findViewById(R.id.punchOutTime_tv)
            relivedTime = view.findViewById(R.id.relivedTime_tv)


        }

    }

    override fun onCreateViewHolder(
        viewGroup: ViewGroup,
        viewType: Int
    ): ViewHolder {
        val view = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.history_item, viewGroup, false)

        return ViewHolder(view)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val attendance = attendances[position]
        viewHolder.setIsRecyclable(false)


        viewHolder.isPresent.text = "Present: ${attendance.is_present}"


        if (!attendance.dutyDate.isNullOrEmpty()) {
            viewHolder.shiftDate.text = "${attendance.dutyDate}"
        }
        if (!attendance.punch_in_time.isNullOrEmpty()) {
            viewHolder.punchInTime.text = "Punch In Time: ${attendance.punch_in_time}"
        }
        if (!attendance.punch_out_time.isNullOrEmpty()) {
            viewHolder.punchOutTime.text = "Punch out Time: ${attendance.punch_out_time}"
        }
        if (!attendance.start_duty.isNullOrEmpty()) {
            viewHolder.startTime.text = "Start Time: ${attendance.start_duty}"
        }
        if (!attendance.relieved.isNullOrEmpty()) {
            viewHolder.relivedTime.text = "Relived Time: ${attendance.relieved}"
        }



        viewHolder.historyItemCard.setOnClickListener {
            viewHolder.historyItemCard.startAnimation(fadeOut)
        }
    }

    override fun getItemCount() = attendances.size


}

