package com.resoluteai.guardapp.domain.repository

import com.resoluteai.guardapp.data.remote.api_request.SendGeofenceOTPRequest
import com.resoluteai.guardapp.data.remote.api_request.VerifyOtp
import com.resoluteai.guardapp.utils.NetworkResult

interface OTPRepository {

    suspend fun sendOtpFromGeofence(requestBody: SendGeofenceOTPRequest): NetworkResult<String>

    suspend fun updateStatusOnLocation(requestBody: SendGeofenceOTPRequest): NetworkResult<String>

    suspend fun verifyOtpFromGeofence(requestBody: VerifyOtp): NetworkResult<String>
}