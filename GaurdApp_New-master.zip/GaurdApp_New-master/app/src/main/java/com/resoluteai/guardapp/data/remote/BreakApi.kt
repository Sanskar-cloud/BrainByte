package com.resoluteai.guardapp.data.remote

import com.resoluteai.guardapp.data.remote.api_response.BasicApiResponse
import com.resoluteai.guardapp.data.remote.api_response.Break
import retrofit2.Response
import retrofit2.http.GET

interface BreakApi {

    @GET("/api/v1/get-all-breaks")
    suspend fun getAllBreaks(): Response<BasicApiResponse<List<Break>>>


}