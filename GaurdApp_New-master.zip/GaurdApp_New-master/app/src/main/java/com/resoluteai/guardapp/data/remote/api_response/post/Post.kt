package com.resoluteai.guardapp.data.remote.api_response.post

import com.google.gson.annotations.SerializedName

data class Post(
    @SerializedName("client_id")
    val clientId: String,
    @SerializedName("coordinates")
    val coordinates: com.resoluteai.guardapp.data.remote.api_response.Coordinates?,
    @SerializedName("created_at")
    val createdAt: String,
    @SerializedName("id")
    val id: String,
    @SerializedName("is_deleted")
    val isDeleted: Boolean,
    @SerializedName("location_id")
    val locationId: String,
    @SerializedName("location_name")
    val locationName: Any?,
    @SerializedName("max_guards")
    val maxGuards: Int,
    @SerializedName("name")
    val name: String,
    @SerializedName("proximity")
    val proximity: Int?,
    @SerializedName("updated_at")
    val updatedAt: String
)