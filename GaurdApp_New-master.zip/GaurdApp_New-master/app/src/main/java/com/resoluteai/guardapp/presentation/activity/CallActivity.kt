package com.resoluteai.guardapp.presentation.activity

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Rect
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.util.Rational
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.Window
import android.view.WindowManager
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.webkit.ConsoleMessage
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.google.gson.Gson
import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.databinding.ActivityLivestreamBinding
import com.resoluteai.guardapp.domain.model.call.CallMetadata
import com.resoluteai.guardapp.domain.model.call.CallRequest
import com.resoluteai.guardapp.domain.model.call.CallRequestApproval
import com.resoluteai.guardapp.domain.model.socket.CloseCallRequest
import com.resoluteai.guardapp.events.CallRunningEvent
import com.resoluteai.guardapp.presentation.livestream.LiveStreamFragment
import com.resoluteai.guardapp.presentation.livestream.LivestreamViewModel
import com.resoluteai.guardapp.service.RingtoneHelper
import com.resoluteai.guardapp.socket.MySocketHandler
import com.resoluteai.guardapp.utils.AlarmUtils
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.Constant.CALL_NOTIFICATION_ID
import com.resoluteai.guardapp.utils.Constant.CallActivityClass
import com.resoluteai.guardapp.utils.Constant.CallRequestApprovalEvent
import com.resoluteai.guardapp.utils.Constant.CloseTheCallEvent
import com.resoluteai.guardapp.utils.Constant.IS_CALL_CAME_FROM_GUARD
import com.resoluteai.guardapp.utils.Constant.IS_GUARD_GOT_CALL_NOTIFICATION
import com.resoluteai.guardapp.utils.Constant.IS_GUARD_IN_THE_CALL
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.TokenManager
import com.resoluteai.guardapp.utils.call.JavascriptInterface
import com.resoluteai.guardapp.utils.hasRequiredPermissions
import com.resoluteai.guardapp.utils.showToast
import com.resoluteai.guardapp.utils.turnScreenOffAndKeyguardOn
import com.resoluteai.guardapp.utils.turnScreenOnAndKeyguardOff
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import javax.inject.Inject

@AndroidEntryPoint
class CallActivity: AppCompatActivity() {

    private var _binding: ActivityLivestreamBinding?  = null
    private val binding get() = _binding


    @Inject
    lateinit var tokenManager: TokenManager
    private val fadeOut: Animation by lazy { AnimationUtils.loadAnimation(this, R.anim.fade_out) }

    @Inject
    lateinit var ringtoneHelper: RingtoneHelper
    private lateinit var notificationManager: NotificationManager
    private lateinit var timer: CountDownTimer
    private var operatorAcceptedCall = false

    private var operatorIds: MutableList<String> = mutableListOf()
    private val callViewModel by viewModels<LivestreamViewModel>()

    private val isPipSupported by lazy {
        packageManager.hasSystemFeature(
            PackageManager.FEATURE_PICTURE_IN_PICTURE
        )
    }
    private val coroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val mSocket = MySocketHandler.getSocket()

    private var isPeerConnected = false
    private var isFrontendCamera = false
    private var isFlashOn = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!hasRequiredPermissions(REQUIRED_PERMISSIONS)) {
            ActivityCompat.requestPermissions(
                this, REQUIRED_PERMISSIONS, 0
            )
        }
        _binding = ActivityLivestreamBinding.inflate(layoutInflater)
        setContentView(binding?.root)
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancel(CALL_NOTIFICATION_ID)


        IS_GUARD_IN_THE_CALL = true



        if (IS_CALL_CAME_FROM_GUARD) {

            binding?.ringingtextView?.visibility = VISIBLE

            Log.d(CallActivityClass, "call came from guard")

            callViewModel.getEvent.observe(this) {
                when (it) {
                    is NetworkResult.Loading -> {
                        Log.d("idsLoad", "loading")
                    }
                    is NetworkResult.Success -> {
                        Log.d("operatorLen", "$operatorIds")
                        if (operatorIds.isNotEmpty()) {
//                            operatorIds.removeAll(operatorIds)
                            it.data?.operator?.onEach { operator ->
                                Log.d(CallActivityClass, "operatorList: $operator")
                                operatorIds.add(operator.employeeId)
                                Log.d(CallActivityClass, "operatorList: $operatorIds")
                            }
                        } else {
                            it.data?.operator?.onEach { operator ->
                                Log.d(CallActivityClass, "operatorList: $operator")
                                operatorIds.add(operator.employeeId)
                                Log.d(CallActivityClass, "operatorList: $operatorIds")
                            }
                        }

                    }
                    is NetworkResult.Failed -> {
                        Toast.makeText(this, "No Internet Connection", Toast.LENGTH_LONG).show()
                        Log.d("phat", "msg")
                    }

                    else -> {}
                }
            }
            //fetch operators - api call
            callViewModel.loadAllOperators(tokenManager.getEventID())
            val packageName = applicationContext.packageName



            val customRingtoneUri = Uri.parse("android.resource://${packageName}/${R.raw.ring}")
//            val ringtone = RingtoneManager.getRingtone(this, customRingtoneUri)
            ringtoneHelper.playNotificationSound(customRingtoneUri)


//            val callRingtone = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
//            ringtoneHelper.playNotificationSound(callRingtone)
            timer = object : CountDownTimer(30000, 3000L) {
                override fun onTick(p0: Long) {
                    Log.d(CallActivityClass, "${p0/1000L}")

                    operatorIds.forEach {
                        MySocketHandler.sendCallRequest(
                            CallRequest(
                                eventId = tokenManager.getEventID(),
                                employeeId = tokenManager.getEmployeeID(),
                                receiverId = it,
                                receiverSocketId = "",
                                metadata = CallMetadata(
                                    name = tokenManager.getProfileName()
                                ),
                                senderPeerId = "123"
                            )
                        )
                    }

                }

                override fun onFinish() {
                    Log.d(Constant.LiveStreamFragmentClass, "Timer on finish call called")
                    if (!operatorAcceptedCall) {
                        Log.d(Constant.LiveStreamFragmentClass, "$binding")
                        //finish activity
                        _binding?.webView?.loadUrl("about:blank")
                        ringtoneHelper.stopPlayback()
                        Log.d(Constant.LiveStreamFragmentClass, "Ringtone Stopped")
                        finish()
                    }

                }
            }

            timer.start()

        } else {
            notificationManager.cancel(CALL_NOTIFICATION_ID)
            //ringtoneHelper.stopPlayback()
            Log.d(CallActivityClass, "call activity called")
            //set cancel 30 sec alarm
            val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pendingAlarmIntent = AlarmUtils.getAlarmPendingIntent(applicationContext)
            alarmManager.cancel(pendingAlarmIntent)
            pendingAlarmIntent.cancel()
        }


        mSocket?.on(CloseTheCallEvent) { args ->

            if (args[0] != null) {
                coroutineScope.launch {
                    val json = args[0].toString()
                    Log.d(CallActivityClass, "socket-close-the-call $json")
                    val request = Gson().fromJson(json, CloseCallRequest::class.java)
                    val empId = request.employeeId
                    val receiverId = request.receiverId
                    Log.d(CallActivityClass, "Employee Id: ${request.employeeId}, ReceiverId: ${request.receiverId}")
                    Log.d(CallActivityClass, "Local Emp Id: ${tokenManager.getEmployeeID()} && Callerid: ${tokenManager.getCallerEmpId()}")
                    if (receiverId == tokenManager.getEmployeeID() && empId == tokenManager.getCallerEmpId()) {
                        Log.d(CallActivityClass, "verification done")
                        binding?.webView?.loadUrl("about:blank")
                        IS_GUARD_IN_THE_CALL = false
                        IS_GUARD_GOT_CALL_NOTIFICATION = false
                        if (IS_CALL_CAME_FROM_GUARD) {
                            finish()
                            IS_CALL_CAME_FROM_GUARD = false
                        } else {
                            finishAndRemoveTask()
                        }



                    }

                }
            }
        }

        onBackPressedDispatcher.addCallback(
            object: OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    //dont do anything
                }

            }
        )



        setupWebView()

        binding?.endCall?.setOnClickListener {
            ringtoneHelper.stopPlayback()
            Log.d(Constant.LiveStreamFragmentClass, "Ringtone Stopped")
            try {
                if (IS_CALL_CAME_FROM_GUARD) {
                    timer.cancel()
                    finish()
                } else {
                    finishAndRemoveTask()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }



        }

        //Switch Camera
        binding?.switchCameraBtn?.setOnClickListener {
            Log.d("TAG_SWITCHCAMERA", "onclick listener")
            isFrontendCamera = !isFrontendCamera
            callJavascriptFunction("javascript:switchCamera()")
            binding!!.switchCameraBtn.startAnimation(fadeOut)

        }

        //Flash
        binding?.flashToggleBtn?.setOnClickListener {
            Log.d("TAG_SWITCHCAMERA", "onclick listener")
            isFlashOn = !isFlashOn
            callJavascriptFunction("javascript:toggleTorch('$isFlashOn')")
            if (isFlashOn) {
                binding!!.flashToggleBtnBg.visibility = VISIBLE
            } else {
                binding!!.flashToggleBtnBg.visibility = View.INVISIBLE
            }
        }


        val window: Window = this.window
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS
        )
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
        }
        window.statusBarColor = ContextCompat.getColor(this, R.color.black)
        turnScreenOnAndKeyguardOff()


    }





    private fun setupWebView() {

        binding?.webView?.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.grant(request.resources)
            }
            override fun onConsoleMessage(message: ConsoleMessage): Boolean {
                Log.d("CallActivity WebView", "${message.message()} -- From line " +
                        "${message.lineNumber()} of ${message.sourceId()}")
                return true
            }
        }

        binding?.apply {
            webView.setBackgroundColor(Color.BLACK)
            webView.settings.javaScriptEnabled = true
            webView.settings.domStorageEnabled = true
            webView.settings.loadsImagesAutomatically = true
            webView.settings.mediaPlaybackRequiresUserGesture = false
            webView.addJavascriptInterface(JavascriptInterface(this@CallActivity), "Android")
        }

        loadVideoCall()
    }

    private fun loadVideoCall() {
        binding?.webView?.loadUrl(filePath)
        binding?.webView?.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                //After Completing Loading we are initializing peer
                initializePeer()
            }
        }
    }



    private fun callJavascriptFunction(functionString: String) {
        binding?.webView?.post { binding?.webView?.evaluateJavascript(functionString, null) }
    }


    private fun initializePeer() {
        Log.d(CallActivityClass,"Peer Id: ${tokenManager.getEmployeeID()}")
        callJavascriptFunction("javascript:init(\"${tokenManager.getEmployeeID()}\")")
    }




    override fun onDestroy() {
        mSocket?.off(CallRequestApprovalEvent)
        mSocket?.off(CloseTheCallEvent)
        IS_GUARD_IN_THE_CALL = false
        IS_CALL_CAME_FROM_GUARD = false
        Log.d(CallActivityClass, "onDestroy called Call Ref: $IS_CALL_CAME_FROM_GUARD")
        IS_GUARD_GOT_CALL_NOTIFICATION = false
        isPeerConnected = false
        tokenManager.saveCallerEmpId("")
        binding?.webView?.loadUrl("about:blank")
        val intent = Intent(Constant.Action_Call_Notification).apply {
            putExtra("call_notif_got", false)
        }
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
        super.onDestroy()
        ringtoneHelper.stopPlayback()
        _binding = null
        turnScreenOffAndKeyguardOn()

    }

    fun onPeerConnected() {
        Log.d(CallActivityClass, "on Peer Connected Called")
        isPeerConnected = true
        if (!IS_CALL_CAME_FROM_GUARD) {
            MySocketHandler.answerCallRequest(
                CallRequestApproval(
                    accepted = true,
                    data = CallRequest(
                        eventId = tokenManager.getEventID(),
                        employeeId = tokenManager.getEmployeeID(),
                        receiverId = tokenManager.getCallerEmpId(),
                        senderPeerId = "123",
                        metadata = CallMetadata(
                            name = tokenManager.getProfileName()
                        ),
                        receiverSocketId = tokenManager.getSocketIdForCall()
                    )
                )
            )
            ringtoneHelper.stopPlayback()
        } else {
            //Call Request Approval Listening
            mSocket?.on(CallRequestApprovalEvent) { args ->

                Log.d("args", args.toString())
                if (args[0] != null) {
                    coroutineScope.launch {
                        Log.d(CallActivityClass, "call-request-approval called")
                        val json = args[0].toString()
                        val request = Gson().fromJson(json, CallRequestApproval::class.java)
                        operatorAcceptedCall = request.accepted
                        Log.d(CallActivityClass, "Call-Request-Approval: $request")



                        if (!operatorAcceptedCall) {
                            showToast("Call is not accepted")
                            _binding?.webView?.loadUrl("about:blank")
                            ringtoneHelper.stopPlayback()
                            finish()

                        } else {
                            Log.d(CallActivityClass, "Call Request Approval: call is accepted")
                            request.data?.employeeId?.let { tokenManager.saveCallerEmpId(it) }
                            try {
                                timer.cancel()
                                ringtoneHelper.stopPlayback()
                                Log.d(CallActivityClass, "Ringtone Stopped")
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                            binding?.ringingtextView?.visibility = GONE
                            Log.d(CallActivityClass, "$binding")

                        }
                    }
                }
            }
        }

    }



    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if(!isPipSupported) {
            return
        }
        updatePictureInPictureParams()?.let { enterPictureInPictureMode(it) }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            //hide all unimportant views
            binding?.hideLay?.visibility = GONE
            binding?.ringingtextView?.visibility = GONE
            callJavascriptFunction("javascript:hideLocalVideo()")
        } else {
            //show all unimportant views
            binding?.hideLay?.visibility = VISIBLE
            callJavascriptFunction("javascript:reloadLocalVideo()")
            //binding?.ringingtextView?.visibility = VISIBLE
        }
    }


    private fun updatePictureInPictureParams(): PictureInPictureParams? {
        val visibleRect = Rect()

        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.S) {
            return PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .setSourceRectHint(visibleRect)
                .setAutoEnterEnabled(true)
                .setSeamlessResizeEnabled(false)
                .build()
        }

        return PictureInPictureParams.Builder()
            .setAspectRatio(Rational(16, 9))
            .setSourceRectHint(visibleRect)
            .build()

    }


    companion object {
        private const val filePath = "file:android_asset/index.html"
        private val REQUIRED_PERMISSIONS = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
        )
    }



}
