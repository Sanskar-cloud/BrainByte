package com.resoluteai.guardapp.domain.model.socket

data class SocketConfiguration(
    val eventId: String,
    val employeeId: String,
    val clientId: String
)
