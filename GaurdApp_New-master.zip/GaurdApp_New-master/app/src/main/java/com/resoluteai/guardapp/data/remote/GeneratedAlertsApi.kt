package com.resoluteai.guardapp.data.remote

import com.resoluteai.guardapp.data.remote.api_request.alert.CreateGeneratedAlertRequest
import com.resoluteai.guardapp.data.remote.api_response.BasicApiResponse
import com.resoluteai.guardapp.domain.model.alert.GeneratedAlert
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface GeneratedAlertsApi {

    @GET("/api/v1/get-generated_alert-by-employee-id")
    suspend fun getAllGeneratedAlertsByEmpId(
        @Query("employee_id") employeeId: String
    ): Response<BasicApiResponse<List<GeneratedAlert>>>

    @POST("/api/v1/create-generated_alert")
    suspend fun createGeneratedAlert(
        @Body request: CreateGeneratedAlertRequest
    ): Response<BasicApiResponse<GeneratedAlert>>
}