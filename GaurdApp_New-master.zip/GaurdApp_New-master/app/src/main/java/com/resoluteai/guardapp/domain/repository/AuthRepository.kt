package com.resoluteai.guardapp.domain.repository

import com.resoluteai.guardapp.data.remote.api_request.VerifyOtp
import com.resoluteai.guardapp.domain.model.auth.updated.NewAuthResponse
import com.resoluteai.guardapp.utils.NetworkResult

interface AuthRepository {

    suspend fun verifyAssignmentOTP(request: VerifyOtp): NetworkResult<String>
    suspend fun sendLoginOTP(phoneNumber: String, macAddress: String): NetworkResult<String>
    suspend fun verifyLoginOTP(otp: String, phoneNumber: String, macAddress: String): NetworkResult<NewAuthResponse>
}