package com.resoluteai.guardapp.socket

import android.util.Log
import com.google.gson.Gson
import com.resoluteai.guardapp.domain.model.call.CallRequest
import com.resoluteai.guardapp.domain.model.call.CallRequestApproval
import com.resoluteai.guardapp.domain.model.generated_alert.GeneratedAlertModel
import com.resoluteai.guardapp.domain.model.socket.AddSnapshotListenerRequest
import com.resoluteai.guardapp.domain.model.socket.CaptchaResponse
import com.resoluteai.guardapp.domain.model.socket.HandshakeCompletedEvent
import com.resoluteai.guardapp.domain.model.socket.LocationForSocket
import com.resoluteai.guardapp.domain.model.socket.OperatorHandshkae
import com.resoluteai.guardapp.domain.model.socket.ShiftEndedConfirmation
import com.resoluteai.guardapp.domain.model.socket.SnapshotListenerQuery
import com.resoluteai.guardapp.domain.model.socket.SocketConfiguration
import com.resoluteai.guardapp.domain.model.socket.TriggerEscalation
import com.resoluteai.guardapp.presentation.activity.Oprhandshake
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.Constant.Get_Device_LoggedIn_Listener_Id
import com.resoluteai.guardapp.utils.Constant.MySocketHandlerObject
import com.resoluteai.guardapp.utils.Constant.Socket_Path
import com.resoluteai.guardapp.utils.Constant.Socket_Service
import com.resoluteai.guardapp.utils.Constant.Socket_Service_P
import com.resoluteai.guardapp.utils.TokenManager
import dagger.hilt.android.AndroidEntryPoint
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONException
import org.json.JSONObject
import javax.inject.Inject


object MySocketHandler {




    var mSocket: Socket? = null
    var employeeId: String? = null
    var eventId: String? = null
    var clientId: String? = null

    @Synchronized
    fun setSocket(eventId: String, employeeId: String, clientId: String) {
        val options = IO.Options()
        options.path = Socket_Path
        options.query = "eventId=${eventId}&employeeId=${employeeId}"
        options.transports = arrayOf("websocket")
        options.forceNew = true
        mSocket = IO.socket(Socket_Service, options)
        Log.d(MySocketHandlerObject, "setSocket: $eventId")



        mSocket?.on(Socket.EVENT_DISCONNECT) { args ->
            Log.d(
                MySocketHandlerObject,
                "socket is disconnected: conection status ${mSocket!!.connected()}"
            )
        }

        mSocket?.on("update-call-ids") { args ->
            Log.d(
                MySocketHandlerObject,
                "${mSocket}"
            )
            Log.d(
                MySocketHandlerObject,
                "EVENT Listened"
            )

//            if (args.isNotEmpty()) {
//                Log.d(
//                    Constant.QRScannerActivityClass,
//                    "EVENT EMITTED"
//                )
//
//
//                val eventData = args[0].toString()
//
//
//                try {
//                    val jsonObject = JSONObject(eventData)
//                    val success = jsonObject.getBoolean("success")
//                    val receivedCommunicationId = jsonObject.getString("communication_id")
//
//                    val expectedCommunicationId =emittedCommunicationId
//
//
//                    if (success && receivedCommunicationId == expectedCommunicationId) {
//                        runOnUiThread {
//
//                            val handshakeCompletedEvent = HandshakeCompletedEvent(success, receivedCommunicationId)
//                            showDialog(handshakeCompletedEvent)
//                        }
//                    } else {
//
//                    }
//                } catch (e: JSONException) {
//                    e.printStackTrace()
//                }
//            }
        }

        mSocket?.on(Socket.EVENT_CONNECT) { args ->
            Log.d(
                MySocketHandlerObject,
                "socket is trying to connect:conection status  ${mSocket!!.connected()}"
            )



            if (eventId.isNotEmpty() && employeeId.isNotEmpty() ) {
                addSnapshotListenerRequest(
                    AddSnapshotListenerRequest(
                        query = SnapshotListenerQuery(
                            collection = "attendance",
                            where = listOf(
                                listOf("employee_id", "==", employeeId),
                                listOf("event_id", "==", eventId)
                            )
                        ),
                        listener_id = "att-listener",
                        employee_id = employeeId
                    )
                )

                addSnapshotListenerRequest(
                    AddSnapshotListenerRequest(
                        query = SnapshotListenerQuery(
                            collection = "generated_alerts",
                            where = listOf(
                                listOf("guard_id", "==", employeeId),
                            )
                        ),
                        listener_id = "ga-listener",
                        employee_id = employeeId
                    )
                )

                addSnapshotListenerRequest(
                    AddSnapshotListenerRequest(
                        query = SnapshotListenerQuery(
                            collection = "alerts",
                            where = listOf(
                                listOf("client_id", "==", clientId),
                            )
                        ),
                        listener_id = Constant.Get_Alerts_Listener_Id,
                        employee_id = employeeId
                    )
                )

                addSnapshotListenerRequest(
                    AddSnapshotListenerRequest(
                        query = SnapshotListenerQuery(
                            collection = "breaks",
                            where = listOf(
                                listOf("client_id", "==", clientId),
                            )
                        ),
                        listener_id = "breaks-listener",
                        employee_id = employeeId
                    )
                )

                addSnapshotListenerRequest(
                    AddSnapshotListenerRequest(
                        query = SnapshotListenerQuery(
                            collection = "employees",
                            where = listOf(
                                listOf("id", "==", employeeId),
                            )
                        ),
                        listener_id = Get_Device_LoggedIn_Listener_Id,
                        employee_id = employeeId
                    )
                )
            }

        }

        mSocket?.on(Socket.EVENT_CONNECT_ERROR) { args ->
            Log.d(MySocketHandlerObject, "socket event connect error called")
        }

    }

    private fun addSnapshotListenerRequest(request: AddSnapshotListenerRequest) {
        mSocket?.emit("add-snapshot-listener", Gson().toJson(request))
        Log.d("add-snapshot-listener: MYSocketHandler", Gson().toJson(request))
    }

    @Synchronized
    fun sendCallRequest(call: CallRequest? = null) {
        mSocket?.emit("send-call-request", Gson().toJson(call))
        Log.d("send-call-request: MYSocketHandler", Gson().toJson(call))
    }

    @Synchronized
    fun answerCallRequest(call: CallRequestApproval) {
        mSocket?.emit("answer-call-request", Gson().toJson(call))
        Log.d("answer-call-request: MYSocketHandler", Gson().toJson(call))
    }

    @Synchronized
    fun oprhandshake(oprhandshake: OperatorHandshkae) {
        mSocket?.emit("operator-login-handshake", Gson().toJson(oprhandshake))
        Log.d("answer-call-request: MYSocketHandler", Gson().toJson(oprhandshake))

    }


    @Synchronized
    fun sendLocationResponse(location: LocationForSocket) {
        mSocket?.emit("pass_live_location", Gson().toJson(location))
        Log.d("pass_live_location: MySocketHandler", Gson().toJson(location))
    }

    @Synchronized
    fun sendCaptchaResponse(captchaResponse: CaptchaResponse) {

        mSocket?.emit("captcha_response", Gson().toJson(captchaResponse))
        Log.d("socket-captcha: MySocketHandler", Gson().toJson(captchaResponse))
    }


    @Synchronized
    fun sendAlertFromGuard(alert: GeneratedAlertModel) {
        mSocket?.emit("emitAlertFromGuard", Gson().toJson(alert))
        Log.d("socket-alert: MySocketHandler", Gson().toJson(alert))
    }

    @Synchronized
    fun getSocket(): Socket? {

        return mSocket

    }

    fun setData(
        configuration: SocketConfiguration
    ) {
        employeeId = configuration.employeeId
        eventId = configuration.eventId
        clientId = configuration.clientId
    }


    @Synchronized
    fun establishConnection() {
        mSocket?.connect()
        Log.d("MYSocketHandler", "Socket connection is successful")
        Log.d("MYSocketHandler", "Socket connection is successful")

    }


    @Synchronized
    fun closeConnection() {
        mSocket?.disconnect()
        mSocket?.off()
        mSocket = null
        Log.d("MySocketHandler", "Socket is Disconnected")
    }


    @Synchronized
    fun sendEscalation(escalation: TriggerEscalation) {
        mSocket?.emit("trigger_escalation", Gson().toJson(escalation))
        Log.d("trigger_escalation: MySocketHandler", Gson().toJson(escalation))
    }

    @Synchronized
    fun sendDutyEndedConfirmation(confirmation: ShiftEndedConfirmation) {
        mSocket?.emit("guard_duty_ended", Gson().toJson(confirmation))
        Log.d("guard_duty_ended: MySocketHandler", Gson().toJson(confirmation))
    }

    fun setSocket2(eventID: String, employeeID: String, someImportantClientID: String) {
        val options = IO.Options()
        options.path = Socket_Path
        options.query = "eventId=${eventId}&employeeId=${employeeId}"
        options.transports = arrayOf("websocket")
        options.forceNew = true
        mSocket = IO.socket(Socket_Service, options)
        Log.d(MySocketHandlerObject, "setSocket: $eventId")



        mSocket?.on(Socket.EVENT_DISCONNECT) { args ->
            Log.d(
                MySocketHandlerObject,
                "socket is disconnected: conection status ${mSocket!!.connected()}"
            )
        }

        mSocket?.on(Socket.EVENT_CONNECT) { args ->
            Log.d(
                MySocketHandlerObject,
                "socket is trying to connect:conection status  ${mSocket!!.connected()}"
            )


        }

        mSocket?.on(Socket.EVENT_CONNECT_ERROR) { args ->
            Log.d(MySocketHandlerObject, "socket event connect error called")
        }


    }
}