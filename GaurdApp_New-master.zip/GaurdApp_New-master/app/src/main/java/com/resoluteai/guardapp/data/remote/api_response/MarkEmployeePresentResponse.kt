package com.resoluteai.guardapp.data.remote.api_response

data class MarkEmployeePresentResponse(
    val status: Boolean,
    val message: String
)
