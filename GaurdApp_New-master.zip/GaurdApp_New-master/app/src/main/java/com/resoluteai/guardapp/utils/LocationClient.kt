package com.resoluteai.guardapp.utils

import android.location.Location
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

interface LocationClient {
    fun getLocationUpdates(interval: Long): Flow<Location>


    class LocationException(message: String): Exception()
}