package com.resoluteai.guardapp.data.remote

import com.resoluteai.guardapp.data.remote.api_response.BasicApiResponse
import com.resoluteai.guardapp.data.remote.api_response.event.Event
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface EventApi {

    @GET("/api/v1/get-event-by-id")
    suspend fun getEventById(
        @Query("id") eventId: String
    ): Response<BasicApiResponse<Event>>

    @GET("/api/v1/trigger-escalation")
    suspend fun triggerEscalation(
        @Query("id") event_id: String,
    ): Response<BasicApiResponse<Boolean>>


}