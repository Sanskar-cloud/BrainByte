package com.resoluteai.guardapp.broadcast

interface NetworkChangeListener {
    fun onNetworkChanged(isConnected: Boolean)
}