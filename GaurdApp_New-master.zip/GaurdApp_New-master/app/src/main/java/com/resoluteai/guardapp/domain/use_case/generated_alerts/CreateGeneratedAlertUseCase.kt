package com.resoluteai.guardapp.domain.use_case.generated_alerts

import com.resoluteai.guardapp.data.remote.api_request.alert.CreateGeneratedAlertRequest
import com.resoluteai.guardapp.domain.model.alert.GeneratedAlert
import com.resoluteai.guardapp.domain.repository.GeneratedAlertsRepository
import com.resoluteai.guardapp.utils.NetworkResult
import javax.inject.Inject

class CreateGeneratedAlertUseCase @Inject constructor(
    private val generatedAlertsRepository: GeneratedAlertsRepository
) {

    suspend operator fun invoke(requestBody: CreateGeneratedAlertRequest): NetworkResult<com.resoluteai.guardapp.domain.model.alert.GeneratedAlert> =
        generatedAlertsRepository.createGeneratedAlerts(requestBody)
}