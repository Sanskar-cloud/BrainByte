package com.resoluteai.guardapp.presentation.dialog

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import com.resoluteai.guardapp.R

class LocationRequestDialog : DialogFragment() {


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val locationView = inflater.inflate(R.layout.fragment_location_permission_request, container, false)
        dialog?.window?.setBackgroundDrawableResource(R.drawable.card_rounded_desgin)

        val okBtn = locationView.findViewById<Button>(R.id.ok_btn)

        okBtn.setOnClickListener {
            if (!hasLocationPermission()) {
                requestLocationPermission()
                dismiss()
            } else {
                dismiss()
            }
        }

        isCancelable = false

        return locationView
    }

    private fun hasLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            requireContext(),
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestLocationPermission() {
        ActivityCompat.requestPermissions(
            requireActivity(),
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
            LOCATION_PERMISSION_REQUEST_CODE
        )
    }

    companion object {
        const val TAG = "LocationFragment"
        const val LOCATION_PERMISSION_REQUEST_CODE = 123
    }
}
