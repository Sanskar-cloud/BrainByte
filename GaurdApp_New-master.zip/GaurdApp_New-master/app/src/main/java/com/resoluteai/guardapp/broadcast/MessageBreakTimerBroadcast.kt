package com.resoluteai.guardapp.broadcast

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class MessageBreakTimerBroadcast(private val callback: Callback): BroadcastReceiver() {

    interface Callback {
        fun onBreakMessageReceived(message: String)
    }
    override fun onReceive(context: Context?, intent: Intent?) {


        val message = intent?.getStringExtra("message_escalation")
        Log.d("BreakTimer", "message received broadcast fired $message")
        if (message != null) {
            callback.onBreakMessageReceived(message)
        }

    }
}