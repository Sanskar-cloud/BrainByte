package com.resoluteai.guardapp.domain.model

enum class StatusCode(val number: Int) {

    ZERO(0),
    ONE(1),
    TWO(2),
    THREE(3),
    FOUR(4)
}