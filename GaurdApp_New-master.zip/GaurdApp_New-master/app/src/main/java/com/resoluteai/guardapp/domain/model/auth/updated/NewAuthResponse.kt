package com.resoluteai.guardapp.domain.model.auth.updated

data class NewAuthResponse(
    val access_token: String,
    val `data`: com.resoluteai.guardapp.domain.model.auth.updated.DataNew,
    val message: String,
    val status: Boolean,
    val token_type: String
)
