package com.resoluteai.guardapp.service

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.location.Location
import android.os.CountDownTimer
import android.os.Handler
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.google.android.gms.location.LocationServices
import com.resoluteai.guardapp.broadcast.BreakEndConfirmationBroadcast
import com.resoluteai.guardapp.broadcast.BreakStartReceiver
import com.resoluteai.guardapp.broadcast.DutyEndedBroadcastReceiver
import com.resoluteai.guardapp.data.remote.api_request.attendance.CheckPostStatusRequest
import com.resoluteai.guardapp.domain.model.socket.LocationForSocket
import com.resoluteai.guardapp.domain.use_case.attendance.CheckOutLocationUseCase
import com.resoluteai.guardapp.domain.use_case.attendance.CheckPostStatusUseCase
import com.resoluteai.guardapp.domain.use_case.attendance.GetAttendanceUseCase
import com.resoluteai.guardapp.domain.use_case.attendance.MarkEmployeeAtPostUseCase
import com.resoluteai.guardapp.domain.use_case.event.TriggerEscalationUseCase
import com.resoluteai.guardapp.presentation.activity.DashboardActivity
import com.resoluteai.guardapp.presentation.activity.OnLocationOTPActivity
import com.resoluteai.guardapp.socket.MySocketHandler
import com.resoluteai.guardapp.socket.MySocketHandler.mSocket
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.Constant.Action_End_Break
import com.resoluteai.guardapp.utils.Constant.Action_Location
import com.resoluteai.guardapp.utils.Constant.Action_Status_Update
import com.resoluteai.guardapp.utils.Constant.BREAK_TIMER_NOTIFICATION_ID
import com.resoluteai.guardapp.utils.Constant.ESCALATION_TIMER_NOTIFICATION_ID
import com.resoluteai.guardapp.utils.Constant.FOREGROUND_NOTIFICATION_ID
import com.resoluteai.guardapp.utils.Constant.NOT_AVAILABLE_IN_POST_NOTIFICATION_ID
import com.resoluteai.guardapp.utils.Constant.TAG_LOCATION_SERVICE
import com.resoluteai.guardapp.utils.Constant.isBreakOnInApp
import com.resoluteai.guardapp.utils.Constant.isEscalationTimerEndedforBreakEnd
import com.resoluteai.guardapp.utils.Constant.isEscalationTimerRunning
import com.resoluteai.guardapp.utils.DefaultLocationClient
import com.resoluteai.guardapp.utils.LocationClient
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.TokenManager
import com.resoluteai.guardapp.utils.createLocationAlertNotification
import com.resoluteai.guardapp.utils.createTimerNotification
import com.resoluteai.guardapp.utils.distance
import com.resoluteai.guardapp.utils.foregroundNotification
import com.resoluteai.guardapp.utils.isEmployeeInsideEventLocation
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.catch

import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import java.util.Calendar
import java.util.concurrent.TimeUnit
import javax.inject.Inject



@AndroidEntryPoint
class LocationService: LifecycleService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private lateinit var notificationManager: NotificationManager

    @Inject
    lateinit var tokenManager: TokenManager
    @Inject
    lateinit var checkPostStatusUC: CheckPostStatusUseCase
    @Inject
    lateinit var markEmployeeAtPostUC: MarkEmployeeAtPostUseCase
    @Inject
    lateinit var checkOutLocationUC: CheckOutLocationUseCase
    @Inject
    lateinit var getAttendanceUC: GetAttendanceUseCase
    @Inject
    lateinit var ringtoneHelper: RingtoneHelper
    @Inject
    lateinit var triggerEscalationUC: TriggerEscalationUseCase

    private lateinit var locationClient: LocationClient

    private lateinit var breakTimer: CountDownTimer
    private var escalationTimer: CountDownTimer? = null
    private var validateLocationTimer: CountDownTimer?= null

    private val handler = Handler()
    private lateinit var myRunnable: Runnable

    private var isRunnableActive = false
    private var isEndBreakTimerCalled = false
    //Used for Alert
    var isBreakTimerRunning = false
    var isValidateLocationTimerRunning = false
    var escalationTimerCount = 0
    var currentBreakName: String = ""
    var isGuardInsideEvent: Boolean = false
    var isGuardonPost: Boolean = false





    override fun onCreate() {
        super.onCreate()
        Log.d(TAG_LOCATION_SERVICE, "on start called")
        startForeground(FOREGROUND_NOTIFICATION_ID, foregroundNotification(this))

        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        locationClient = DefaultLocationClient(
            applicationContext,
            LocationServices.getFusedLocationProviderClient(applicationContext)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        Log.d(TAG_LOCATION_SERVICE, "onStartCommand Called")

        //set alarm to emit socket event when shift is ended ----START

        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val receiverIntent = Intent(this, DutyEndedBroadcastReceiver::class.java)

        val pendingIntent = PendingIntent.getBroadcast(
            this,
            0,
            receiverIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        val shiftStartTime = tokenManager.getShiftStartTime().split(":")
        val shiftEndTime = tokenManager.getShiftEndTime().split(":")

        try {
            val shiftEndHr = shiftEndTime[0].toInt()
            val shiftEndMn = shiftEndTime[1].toInt()

            Log.d(TAG_LOCATION_SERVICE, "start shift time $shiftEndHr : $shiftEndMn")
            Log.d(TAG_LOCATION_SERVICE, "start shift time $shiftStartTime")
            Log.d(TAG_LOCATION_SERVICE, "end shift time $shiftEndTime")

            // Set the time to start the task
            val calendar = Calendar.getInstance()
            calendar.set(Calendar.HOUR_OF_DAY, shiftEndHr)
            calendar.set(Calendar.MINUTE, shiftEndMn)
            calendar.set(Calendar.SECOND, 0)

            // Schedule the task to start every day at the specified time
            alarmManager.setRepeating(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                AlarmManager.INTERVAL_DAY,
                pendingIntent
            )

            //set alarm to emit socket event when shift is ended ----END
        } catch (e: Exception) {

        }




        LocalBroadcastManager.getInstance(this).registerReceiver(
            BreakEndConfirmationBroadcast(
                object: BreakEndConfirmationBroadcast.EndBreakCallback {
                override fun onBreakEndConfirmationReceived() {
                    Log.d(TAG_LOCATION_SERVICE, "break timer end called")
                    if (isBreakTimerRunning) {
                        isEndBreakTimerCalled = true
                    }

                    Log.d(TAG_LOCATION_SERVICE, "broadcast : $isEndBreakTimerCalled")

                }
            }),
            IntentFilter(Action_End_Break)
        )

        LocalBroadcastManager.getInstance(this).registerReceiver(
            BreakStartReceiver(object : BreakStartReceiver.Callback {
                override fun onReceiveBreakStartEvent(timer: Int, isBreakActive: Boolean, breakName: String) {


                    val duration = (timer) * 60000L // Convert to milliseconds

                    Log.d(TAG_LOCATION_SERVICE, "Break Timer: $duration")

                    breakTimer = object : CountDownTimer(duration, 1000L) {

                        override fun onTick(millisUntilFinished: Long) {
                            isBreakTimerRunning = true

                            if (isEndBreakTimerCalled) {
                                Log.d(TAG_LOCATION_SERVICE, "End Timer: $isEndBreakTimerCalled")
                                notificationManager.cancel(BREAK_TIMER_NOTIFICATION_ID)
                                cancel()
                                isEndBreakTimerCalled = false
                                isBreakTimerRunning = false
                                Log.d(TAG_LOCATION_SERVICE, "End Timer after cancelation: $isEndBreakTimerCalled")
                                Log.d(TAG_LOCATION_SERVICE, "break timer running: $isBreakTimerRunning")
                            } else {
                                val minutes = TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished)
                                val seconds = TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) - TimeUnit.MINUTES.toSeconds(minutes)

                                //Send Broadcast to UI to update Timer Count
                                val intent = Intent("break_timer")
                                intent.putExtra("remainingMillis", millisUntilFinished)
                                LocalBroadcastManager.getInstance(this@LocationService).sendBroadcast(intent)

                                Log.d(TAG_LOCATION_SERVICE, "Break Time Left: ${minutes}: $seconds")
                                if (seconds < 10) {
                                    val breakNotification = createTimerNotification(
                                        timerName = "Break",
                                        contentText = "Break Timer: ${minutes}: 0$seconds Left",
                                        breakName = breakName,
                                        context = this@LocationService
                                    )
                                    notificationManager.notify(BREAK_TIMER_NOTIFICATION_ID, breakNotification)
                                } else {
                                    val breakNotification = createTimerNotification(
                                        timerName = "Break",
                                        contentText = "Break Timer: ${minutes}: $seconds Left",
                                        breakName = breakName,
                                        context = this@LocationService
                                    )
                                    notificationManager.notify(BREAK_TIMER_NOTIFICATION_ID, breakNotification)
                                }



                            }


                        }


                        override fun onFinish() {
                            isBreakTimerRunning = false
                            Log.d(TAG_LOCATION_SERVICE, "Break Timer is finished")
                            notificationManager.cancel(BREAK_TIMER_NOTIFICATION_ID)
                            //start escalation
                            escalationTimer?.start()
                            if (isBreakOnInApp) {
                                val intent = Intent(Constant.Action_show_break_end_info)
                                intent.putExtra("message_escalation", "Escalation Timer Started, Please return to your post")
                                LocalBroadcastManager.getInstance(this@LocationService).sendBroadcast(intent)
                            }

                        }
                    }

                    Log.d(TAG_LOCATION_SERVICE, "Break Timer is Running: $isBreakTimerRunning")

                    if (!isBreakTimerRunning) {
                        breakTimer.start()
                        isBreakTimerRunning = true
                    }

                    try {
                        currentBreakName = breakName
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                }

            }),
            IntentFilter("Send_Break_Start_Event")
        )

        when(intent?.action) {
            ACTION_START -> start()
            ACTION_STOP -> stop()
        }
        return START_REDELIVER_INTENT
    }

    @SuppressLint("MissingPermission")
    private fun start() {

        Log.d(TAG_LOCATION_SERVICE, "start() called")




        val empId = tokenManager.getEmployeeID()
        val eventId = tokenManager.getEventID()

        try {
            val escalationTimeOut = tokenManager.getEscalationTimeout()?.toIntOrNull()
            val validationTimeout = 10000L

            Log.d(TAG_LOCATION_SERVICE, "Escalation Timeout")
            escalationTimeOut?.let { setEscalationTimer(it.toLong()) }
            setValidationTimeout(validationTimeout)
        }catch (e: Exception) {
            e.printStackTrace()
        }




        locationClient
            .getLocationUpdates(5000L)
            .catch { e -> e.printStackTrace() }
            .onEach { location ->



                val locationData = Intent(Action_Location).apply {
                    putExtra("location_lat", location.latitude)
                    putExtra("location_lng", location.longitude)
                }
                LocalBroadcastManager.getInstance(this).sendBroadcast(locationData)

                if (isRunnableActive) {
                    handler.removeCallbacks(myRunnable)
                    stopMyRunnable()
                }
                startMyRunnable(location)

//                if (MySocketHandler.getSocket() == null) {
//
//                    try {
//                        MySocketHandler.setSocket(
//                            tokenManager.getEventID(),
//                            tokenManager.getEmployeeID(),
//                            tokenManager.getSomeImportantClientID()
//                        )
//                        MySocketHandler.establishConnection()
//                    } catch (e: Exception) {
//                        e.printStackTrace()
//                    }
//
//                } else {
//                    MySocketHandler.sendLocationResponse(
//                        LocationForSocket(
//                            employeeId = tokenManager.getEmployeeID(),
//                            eventId = tokenManager.getEventID(),
//                            lat = location.latitude.toString(),
//                            lng = location.longitude.toString()
//                        )
//                    )
//                }


                //check employee is inside event location
                val isEmployeeInsideTheEventLocation = isEmployeeInsideEventLocation(
                    location = location,
                    tokenManager = tokenManager
                )


                if (isEmployeeInsideTheEventLocation == true) {
                    //Guard is on the event

                    Log.d(TAG_LOCATION_SERVICE, "Guard is inside the event location")

                    val distance = distance(
                        location.latitude,
                        location.longitude,
                        tokenManager.getPostLatitude().toDouble(),
                        tokenManager.getPostLongitude().toDouble()
                    )
                    Log.d(TAG_LOCATION_SERVICE, "$distance")


                    if (distance <= tokenManager.getPromixity()) {
                        //Guard is on the post

                        escalationTimer?.cancel()
//                        if(isEscalationTimerRunning == false){
//                            Log.d("status", "${tokenManager.getStatusCode()}")
//                            tokenManager.saveStatusCode(4)
//                            Log.d("status", "${tokenManager.getStatusCode()}")
//                        }
                        notificationManager.cancel(ESCALATION_TIMER_NOTIFICATION_ID)
                        notificationManager.cancel(NOT_AVAILABLE_IN_POST_NOTIFICATION_ID)


                        Log.d(TAG_LOCATION_SERVICE, "Guard is on the post ${tokenManager.getBreakId()}, ${tokenManager.getDutyRunningState()}")
//                        val a=tokenManager.getStatusCode()
//                        if(a==4) {
//                            tokenManager.saveStatusCode(4)
//                            val intent = Intent(this, DashboardActivity::class.java)
//                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
//                            startActivity(intent)
//
//
//                        }

                        if (tokenManager.getBreakId().isEmpty()) {
                            Log.d(TAG_LOCATION_SERVICE, "Guard is on the post 2${tokenManager.getBreakId()}, ${tokenManager.getDutyRunningState()}")
                            if (tokenManager.getStatusCode() == 3 && !tokenManager.getDutyRunningState()) {
                                Log.d(TAG_LOCATION_SERVICE, "Guard is on the post 3${tokenManager.getBreakId()}, ${tokenManager.getDutyRunningState()}")
                                //First Time Mark Attendance

                                markEmployeePresentWithCheckPostStatus(
                                    empId = empId,
                                    eventId = eventId,
                                    postId = tokenManager.getSomePostId()
                                )
                            }
                        } else {
                            Log.d(TAG_LOCATION_SERVICE, "${tokenManager.getBreakId()}, ${tokenManager.getDutyRunningState()}")

                        }

                    } else {

                        //Guard is not in the post but available in the event
                        if (isGuardonPost) {
                            isGuardonPost = false
                        }

//



                        Log.d(TAG_LOCATION_SERVICE, "${tokenManager.getStatusCode()} code")
                        Log.d(TAG_LOCATION_SERVICE, "${tokenManager.getDutyRunningState()}")
//                        if (!tokenManager.getDutyRunningState()) {
                            Log.d(TAG_LOCATION_SERVICE, "${tokenManager.getDutyRunningState()}")



                            when (tokenManager.getStatusCode()) {

                                4 -> {


                                    if (!isEscalationTimerRunning) {

                                        if (!isValidateLocationTimerRunning) {

                                            validateLocationTimer?.start()
                                            Log.d(TAG_LOCATION_SERVICE, "validation location timer")


                                            isValidateLocationTimerRunning = true
                                        }
                                        if (escalationTimerCount == 0 || escalationTimerCount == 1) {


                                        }
                                    }

                                }


                                3 -> {

                                    if (tokenManager.getBreakId().isNotEmpty()) {

                                        if (!isBreakTimerRunning) {

                                            if (!isEscalationTimerRunning) {
                                                if (escalationTimerCount == 0 || escalationTimerCount == 1) {

                                                    if (!isValidateLocationTimerRunning) {
                                                        validateLocationTimer?.start()
                                                        isValidateLocationTimerRunning = true
                                                    }

                                                }


                                            }
                                        }

                                    }

                                }

                            }

                            }
//                        }



                } else if(isEmployeeInsideTheEventLocation == false) {
                    //Guard is not on the event

                    if (isGuardInsideEvent) {
                        isGuardInsideEvent = false
                    }

                    if (tokenManager.getDutyRunningState()) {

                        when(tokenManager.getStatusCode()) {

                            4 -> {


                                if (!isEscalationTimerRunning) {

                                    if (!isValidateLocationTimerRunning) {

                                        validateLocationTimer?.start()
                                        isValidateLocationTimerRunning = true
                                    }
                                    if (escalationTimerCount == 0 || escalationTimerCount == 1) {





                                    }

                                }

                            }

                            3 -> {

                                if (tokenManager.getBreakId().isNotEmpty()) {
                                    Log.d(TAG_LOCATION_SERVICE, "Guard is on Break")
                                    if (!isBreakTimerRunning) {

                                        if (!isEscalationTimerRunning) {
                                            if (escalationTimerCount == 0 || escalationTimerCount == 1) {


                                                if (!isValidateLocationTimerRunning) {
                                                    validateLocationTimer?.start()
                                                    isValidateLocationTimerRunning = true
                                                }



                                            }
                                        }


                                    }
                                } else {
                                    //Implement Checkout location Api
                                    checkOutLocationTrigger(empId, eventId)
                                    Log.d(TAG_LOCATION_SERVICE, "Check out Location Api Triggered")
                                }

                            }
                        }
                    }

                }

            }
            .launchIn(serviceScope)


    }

    private fun stop() {
        Log.d(TAG_LOCATION_SERVICE, "stop service called")
        EventBus.getDefault().unregister(this)
        stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG_LOCATION_SERVICE, "destroy service called")
        stop()
    }


    private fun markEmployeePresentAtPost(empId: String, eventId: String) {
        serviceScope.launch {

            val result = markEmployeeAtPostUC(empId, eventId)
            if (result is NetworkResult.Success) {
                Log.d(TAG_LOCATION_SERVICE, "mark employee present at post success")
                saveStatusCode(empId, eventId)
                tokenManager.saveDutyRunningState(true)
            } else if (result is NetworkResult.Failed) {
                Log.d(TAG_LOCATION_SERVICE, "mark employee failed: ${result.message}")
            }

        }
    }

    private fun saveStatusCode(empId: String, eventId: String) {
        serviceScope.launch {
            val apiResult = getAttendanceUC(empId, eventId)
            if (apiResult is NetworkResult.Success) {
                Log.d(TAG_LOCATION_SERVICE, "save status code ${apiResult.data}")
                apiResult.data?.let { tokenManager.saveStatusCode(it.status) }

                val intent = Intent(Action_Status_Update).apply {
                    putExtra("status_code", tokenManager.getStatusCode())
                }
                LocalBroadcastManager.getInstance(this@LocationService).sendBroadcast(intent)

            } else if (apiResult is NetworkResult.Failed) {
                //handle exception
            }
        }
    }

    private fun checkOutLocationTrigger(empId: String, eventId: String) {
        serviceScope.launch {
            val result = checkOutLocationUC(
                empId, eventId
            )
            if (result is NetworkResult.Success) {
                tokenManager.saveStatusCode(2)

            } else if (result is NetworkResult.Failed) {
                //handle exception
            }
        }
    }

    private fun markEmployeePresentWithCheckPostStatus(
        empId: String,
        eventId: String,
        postId: String
    ) {
        serviceScope.launch {
            val result = checkPostStatusUC(
                CheckPostStatusRequest(
                    eventId,
                    empId,
                    postId,
                    tokenManager.getShiftNo()
                )
            )
            when(result) {
                is NetworkResult.Success -> {
                    if (result.data?.data == false){
                        markEmployeePresentAtPost(
                            empId, eventId
                        )
                    }
                }

                is NetworkResult.Failed -> {
                    Log.d(TAG_LOCATION_SERVICE, "Mark Employee at Post FAILED")
                }

                else -> {}
            }
        }
    }



    private fun startMyRunnable(location: Location) {
        if (!isRunnableActive) {
            isRunnableActive = true

            myRunnable = Runnable {

                if (MySocketHandler.getSocket() == null) {

                    try {
                        MySocketHandler.setSocket(
                            tokenManager.getEventID(),
                            tokenManager.getEmployeeID(),
                            tokenManager.getSomeImportantClientID()
                        )
                        MySocketHandler.establishConnection()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                } else {
                    MySocketHandler.sendLocationResponse(
                        LocationForSocket(
                            employeeId = tokenManager.getEmployeeID(),
                            eventId = tokenManager.getEventID(),
                            lat = location.latitude.toString(),
                            lng = location.longitude.toString()
                        )
                    )
                }




                if (isRunnableActive) {
                    handler.postDelayed(myRunnable, 5000) // Run again after 5 seconds
                }
            }

            handler.post(myRunnable)
        }
    }

    private fun stopMyRunnable() {
        isRunnableActive = false
    }

    private fun setEscalationTimer(escalationTimeOut: Long) {

        escalationTimer = object : CountDownTimer(30000L, 1000L) {

            override fun onTick(millisUntilFinished: Long) {
//                if (tokenManager.getStatusCode() == 4) {
//                    escalationTimer.cancel()
//                }
                // stop timer if guard is on post
                isEscalationTimerRunning = true
//                tokenManager.saveStatusCode(3)


                val minutes = TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished)
                val seconds = TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) - TimeUnit.MINUTES.toSeconds(minutes)
                Log.d(TAG_LOCATION_SERVICE, "Escalation Time in min: ${minutes}:${seconds} ")
                val escalationNotification = createTimerNotification("Escalation", "Escalation Timer: ${minutes}:${seconds} Left", context = this@LocationService, isEscalationTimer = true)
                notificationManager.notify(ESCALATION_TIMER_NOTIFICATION_ID, escalationNotification)


                if (isBreakOnInApp) {
                    val intent = Intent(Constant.Action_show_break_end_info)
                    intent.putExtra("message_escalation", "Escalation Timer: ${minutes}:${seconds}, Please return to your post")
                    LocalBroadcastManager.getInstance(this@LocationService).sendBroadcast(intent)
                }

            }

            override fun onFinish() {
                isEscalationTimerRunning = false

                Log.d(TAG_LOCATION_SERVICE, "Escalation Timer is finished")
                notificationManager.cancel(ESCALATION_TIMER_NOTIFICATION_ID)
                notificationManager.cancel(NOT_AVAILABLE_IN_POST_NOTIFICATION_ID)
                isEscalationTimerEndedforBreakEnd = true

                if (isBreakOnInApp) {
                    val intent = Intent(Constant.Action_show_break_end_info)
                    intent.putExtra("message_escalation", "Escalation Timer is finished, return to your post")
                    LocalBroadcastManager.getInstance(this@LocationService).sendBroadcast(intent)
                }
                //Send Escalation Mail
                if (tokenManager.getStatusCode() != 4) {
                    serviceScope.launch {
                        val result = triggerEscalationUC(eventId = tokenManager.getEventID())
                        when (result) {
                            is NetworkResult.Success -> {
                                Log.d(TAG_LOCATION_SERVICE, "Escalation Mail Triggered Successfully")

                                if (isBreakOnInApp) {
                                    val intent = Intent(Constant.Action_show_break_end_info)
                                    intent.putExtra("message_escalation", "Escalation Mail sent to Authority")
                                    LocalBroadcastManager.getInstance(this@LocationService).sendBroadcast(intent)
                                }
                            }
                            is NetworkResult.Failed -> {
                                Log.d(TAG_LOCATION_SERVICE, "Escalation Mail Failed Successfully")
                                if (isBreakOnInApp) {
                                    val intent = Intent(Constant.Action_show_break_end_info)
                                    intent.putExtra("message_escalation", "Escalation Mail failed to sent to Authority")
                                    LocalBroadcastManager.getInstance(this@LocationService).sendBroadcast(intent)
                                }
                            }
                            is NetworkResult.Loading -> {

                            }
                        }
                    }
                }

            }

        }
    }

    private fun setValidationTimeout(validationTimeout: Long) {

        validateLocationTimer = object : CountDownTimer(validationTimeout, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                isValidateLocationTimerRunning = true
                Log.d("Location Service", "ValidatetimeriSRunning")
            }

            override fun onFinish() {
                isValidateLocationTimerRunning = false

                if (!isGuardInsideEvent) {

                    val alert = createLocationAlertNotification( "You're not on your Event", context = this@LocationService)
                    notificationManager.notify(NOT_AVAILABLE_IN_POST_NOTIFICATION_ID, alert)

                } else {

                    if (!isGuardonPost) {

                        val alert = createLocationAlertNotification( "You're not on your post", context = this@LocationService)
                        notificationManager.notify(NOT_AVAILABLE_IN_POST_NOTIFICATION_ID, alert)

                    }
                }

                if (isBreakOnInApp && !isBreakTimerRunning) {
                    val alert = createLocationAlertNotification( "you're break is ended, return to your post", context = this@LocationService)
                    notificationManager.notify(NOT_AVAILABLE_IN_POST_NOTIFICATION_ID, alert)
                }



                if (escalationTimer != null) {
                    escalationTimer!!.start()
                    isEscalationTimerRunning = true
                    escalationTimerCount++
                } else {

                    try {
                        val timeout = tokenManager.getEscalationTimeout()?.toIntOrNull()
                        timeout?.let {  }
                        Log.d(TAG_LOCATION_SERVICE, "$timeout")
                        setEscalationTimer(escalationTimeOut = 30000L)
                        escalationTimer!!.start()
                        isEscalationTimerRunning = true
                        escalationTimerCount++
                    }catch (e: Exception) {
                        e.printStackTrace()
                    }


                }



            }

        }
    }




    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
    }
}

