package com.resoluteai.guardapp.domain.model.alert

data class GeneratedAlertList(
    val data: List<com.resoluteai.guardapp.domain.model.alert.GeneratedAlert>
)
