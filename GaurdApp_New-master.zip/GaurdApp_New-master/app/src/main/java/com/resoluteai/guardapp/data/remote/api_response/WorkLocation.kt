package com.resoluteai.guardapp.data.remote.api_response

data class WorkLocation(
    val lat: Double,
    val lng: Double
)