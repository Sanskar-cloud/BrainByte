package com.resoluteai.guardapp.domain.model.socket

data class OperatorHandshkae (
    val scanned_op_id: String,
    val op_id: String,
    val api_key: String,
    val event_id: String,
    val communication_id:String

)
data class HandshakeCompletedEvent(
    val success: Boolean,
    val communication_id: String,

)

