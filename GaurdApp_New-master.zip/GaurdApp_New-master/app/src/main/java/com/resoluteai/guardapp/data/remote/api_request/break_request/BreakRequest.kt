package com.resoluteai.guardapp.data.remote.api_request.break_request

data class BreakRequest(
    val event_id: String,
    val employee_id: String,
    val break_id: String
)
