package com.resoluteai.guardapp.utils

import android.location.Location
import com.google.android.gms.maps.model.LatLng
import com.resoluteai.guardapp.data.remote.api_response.WorkLocation

fun isEmployeeInsideEventLocation(location: Location, tokenManager: TokenManager): Boolean? {
    val latitude = location.latitude
    val longitude = location.longitude
    val currentLocation = LatLng(latitude, longitude)
    return tokenManager.getGeoFunLiveLocation()
        ?.let { Constant.isLatLngInsidePolygon(currentLocation, it) }

}

fun distance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Int{
    val startPoint = Location("current location")
    startPoint.latitude = lat1
    startPoint.longitude = lon1
    val endPoint = Location("work location")
    endPoint.latitude = lat2
    endPoint.longitude = lon2
    val distance = startPoint.distanceTo(endPoint)

    return distance.toInt()
}
fun createPolygonCoords(coordinates: List<WorkLocation>?): List<LatLng>? {
    val polygonCoords = mutableListOf<LatLng>()
    for (coordinate in coordinates!!) {
        polygonCoords.add(LatLng(coordinate.lat, coordinate.lng))
    }
    return polygonCoords
}