package com.resoluteai.guardapp.broadcast

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class BreakEndedBroadcastReceiver(private val callback: DutyEndedListener): BroadcastReceiver() {

    interface DutyEndedListener {
        fun dutyEnded()
        fun breakEnded()
    }
    override fun onReceive(context: Context?, intent: Intent?) {
        Log.d("BreakEndedBroadcast", "called")
        val data = intent?.getStringExtra("message")
        val isDutyEnded = intent?.getBooleanExtra("is_duty_ended", false)
        val isBreakEnded = intent?.getBooleanExtra("is_break_ended", false)
        if (isBreakEnded == true) {
            Log.d("BreakEndedBroadcast", "break end called")
            callback.breakEnded()
        }
        if (data != null && isDutyEnded == true) {
            Log.d("BreakEndedBroadcast", "duty end called")
            callback.dutyEnded()
        }
    }
}