package com.resoluteai.guardapp.domain.use_case.otp

import com.resoluteai.guardapp.data.remote.api_request.SendGeofenceOTPRequest
import com.resoluteai.guardapp.domain.repository.OTPRepository
import com.resoluteai.guardapp.utils.NetworkResult
import javax.inject.Inject

class SendOnLocationOTPUseCase @Inject constructor(
    private val otpRepository: OTPRepository
) {

    suspend operator fun invoke(requestBody: SendGeofenceOTPRequest): NetworkResult<String> =
        otpRepository.sendOtpFromGeofence(requestBody)
}