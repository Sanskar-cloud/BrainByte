package com.resoluteai.guardapp.domain.model.call

data class Call(
    val callId: String
)
