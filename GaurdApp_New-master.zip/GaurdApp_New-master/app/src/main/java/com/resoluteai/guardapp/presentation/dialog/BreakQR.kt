package com.resoluteai.guardapp.presentation.dialog

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.WriterException
import com.google.zxing.common.BitMatrix
import com.journeyapps.barcodescanner.BarcodeEncoder
import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.presentation.profile.ProfileViewModel
import com.resoluteai.guardapp.presentation.dashboard.HomeFragment
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.TokenManager
import com.resoluteai.guardapp.utils.showToast
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import java.util.Calendar
import javax.inject.Inject

@AndroidEntryPoint
class BreakQR: BottomSheetDialogFragment() {

    @Inject
    lateinit var tokenManager: TokenManager
    private val profileViewModel by viewModels<ProfileViewModel>()
    private lateinit var myJob: Job


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val qrView = inflater.inflate(R.layout.dialog_break_qr, container, false)


        val cancelLayout = qrView.findViewById<ImageView>(R.id.dismissButton)
        cancelLayout.setOnClickListener {
            if(dialog?.isShowing == true){
                dismiss()
                HomeFragment.isQRDialogCancelled = true
            }
        }

        val breakId = arguments?.getString("breakId")
        Log.d("BreakQR", "$breakId")


        if(tokenManager.getEmployeeID().isNotEmpty() && tokenManager.getEventID().isNotEmpty() && !breakId.isNullOrEmpty()) {
            try {
                val rightNow: Calendar = Calendar.getInstance()
                val currentHourIn24Format = rightNow.get(Calendar.HOUR_OF_DAY).toString()
                val currentMin = rightNow.get(Calendar.MINUTE).toString()

                val multiFormatWriter = MultiFormatWriter()
                val bitMatrix: BitMatrix = multiFormatWriter.encode(
                    "$currentHourIn24Format:$currentMin ${tokenManager.getEmployeeID()} ${tokenManager.getEventID()} $breakId",
                    BarcodeFormat.QR_CODE,
                    300,
                    300
                )
                val barcodeEncoder = BarcodeEncoder()
                val bitmap = barcodeEncoder.createBitmap(bitMatrix)
                val qrcodeView = qrView.findViewById<ImageView>(R.id.qrcode_iv)
                qrcodeView.setImageBitmap(bitmap)


            } catch (e: WriterException) {
                e.printStackTrace()
                dismiss()
            }
        }


        return qrView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        profileViewModel.getAttendance.observe(viewLifecycleOwner) { result ->

            when(result) {

                is NetworkResult.Loading -> {

                }
                is NetworkResult.Success -> {
                    Log.d("BREAKqrDIALOG", "employee fetched ${result.data?.status}")
                    if (result.data?.status == 3) {
                        result.data.breakId?.let { it1 -> tokenManager.saveBreakId(it1) }
                        tokenManager.saveStatusCode(result.data.status)
                        EventBus.getDefault().post(
                            com.resoluteai.guardapp.data.remote.api_request.event.StatusEvent(
                                3
                            )
                        )

                        val argBreakName = arguments?.getString("break_name")
                        if (argBreakName?.isNotEmpty() == true) {
                            tokenManager.saveCurrentBreakName(argBreakName)
                        }
                        val intent = Intent("Send_Break_Start_Event")
                        intent.putExtra("timer",tokenManager.getBreakTimer())
                        intent.putExtra("isBreakActive", true)
                        intent.putExtra("breakName", tokenManager.getCurrentBreakName())
                        LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(intent)
//                        EventBus.getDefault().post(
//                            BreakEvent(
//                                timer = tokenManager.getBreakTimer().toString(),
//                                isBreakActive = true,
//                                breakName = tokenManager.getCurrentBreakName()
//                            )
//                        )
                        if (dialog?.isShowing == true) {
                            //dismiss()
                            //Show BreakTimer Dialog
                            Constant.isBreakOnInApp = true
                            Log.d("BREAK QR inside", "${Constant.isBreakOnInApp}")
                            tokenManager.saveNeedReplacementBreak(true)
                            val breakTimerDialog = BreakTimerDialog()
                            breakTimerDialog.show(childFragmentManager, BreakTimerDialog.TAG)
                            myJob.cancel()
                        }

                    }
                }
                is NetworkResult.Failed -> {
                    requireActivity().showToast("Server Error \n सर्वर त्रुटि")
                }
            }
        }


        myJob = CoroutineScope(Dispatchers.Default).launch {
            while (NonCancellable.isActive) {
                profileViewModel.getAttendance()
                delay(5000)
            }
        }

    }

    override fun dismiss() {
        super.dismiss()
        myJob.cancel()
    }

    override fun onDestroy() {
        super.onDestroy()
        myJob.cancel()
    }


    companion object {
        const val TAG = "BREAK_QR_DIALOG"
    }





}