package com.resoluteai.guardapp.data.remote.api_response.alert


data class Alert(
    val event_id: String?,
    val client_id: String,
    val created_at: String,
    val created_by: String,
    val emergency_authority: List<EmergencyAuthority>?,
    val icon_background_color: String,
    val icon_code: String,
    val icon_foreground_color: String,
    val icon_name: Any,
    val id: String,
    val image_url: String,
    val is_deleted: Boolean,
    val location_id: String,
    val location_name: String,
    val message: String,
    val name: String,
    val updated_at: String,
    val updated_by: String,
    val icon_unicode:String
)
