package com.resoluteai.guardapp.presentation.dashboard

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.resoluteai.guardapp.data.remote.api_response.Break
import com.resoluteai.guardapp.domain.model.alert.GeneratedAlert
import com.resoluteai.guardapp.domain.use_case.alerts.GetAllAlertsUseCase
import com.resoluteai.guardapp.domain.use_case.breaks.GetAllBreaksUseCase
import com.resoluteai.guardapp.domain.use_case.generated_alerts.CreateGeneratedAlertUseCase
import com.resoluteai.guardapp.domain.use_case.generated_alerts.GetGeneratedAlertsUseCase
import com.resoluteai.guardapp.utils.Constant.HOME_VIEWMODEL_TAG
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.SingleLiveData
import com.resoluteai.guardapp.utils.TokenManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val getAllAlertsUC: GetAllAlertsUseCase,
    private val getAllBreaksUC: GetAllBreaksUseCase,
    private val getGeneratedAlerts: GetGeneratedAlertsUseCase,
    private val createGeneratedAlertUC: CreateGeneratedAlertUseCase,
    private val tokenManager: TokenManager
): ViewModel() {


    private  val _generatedAlerts = SingleLiveData<NetworkResult<List<GeneratedAlert>>>()
    val generatedAlerts : LiveData<NetworkResult<List<GeneratedAlert>>>
        get() = _generatedAlerts

    private  val _createGeneratedAlert = SingleLiveData<NetworkResult<GeneratedAlert>>()
    val createGeneratedAlert : LiveData<NetworkResult<GeneratedAlert>>
        get() = _createGeneratedAlert

    private  val _getAllAlerts = SingleLiveData<NetworkResult<List<com.resoluteai.guardapp.data.remote.api_response.alert.Alert>>>()
    val getAllAlerts : LiveData<NetworkResult<List<com.resoluteai.guardapp.data.remote.api_response.alert.Alert>>>
        get() = _getAllAlerts

    private  val _getAllBreaks = SingleLiveData<NetworkResult<List<Break>>>()
    val getAllBreaks : LiveData<NetworkResult<List<Break>>>
        get() = _getAllBreaks

    fun getGeneratedAlerts() {
        viewModelScope.launch {
            val result = getGeneratedAlerts(empId = tokenManager.getEmployeeID())
            when (result) {

                is NetworkResult.Loading -> {
                    Log.d(HOME_VIEWMODEL_TAG, "generated alerts -loading")
                    _generatedAlerts.postValue(NetworkResult.Loading())
                }

                is NetworkResult.Success -> {
                    Log.d(HOME_VIEWMODEL_TAG, "generated alerts -success")
                    _generatedAlerts.postValue(NetworkResult.Success(result.data!!))
                }

                is NetworkResult.Failed -> {
                    Log.d(HOME_VIEWMODEL_TAG, "generated alerts -failed")
                    _generatedAlerts.postValue(NetworkResult.Failed(result.message))
                }
            }
        }
    }


    fun loadAllAlerts() {
        viewModelScope.launch {
            val result = getAllAlertsUC()
            when (result) {

                is NetworkResult.Loading -> {
                    Log.d(HOME_VIEWMODEL_TAG, "generated alerts -loading")
                    _getAllAlerts.postValue(NetworkResult.Loading())
                }

                is NetworkResult.Success -> {
                    Log.d(HOME_VIEWMODEL_TAG, "generated alerts -success")
                    _getAllAlerts.postValue(NetworkResult.Success(result.data!!))
                }

                is NetworkResult.Failed -> {
                    Log.d(HOME_VIEWMODEL_TAG, "generated alerts -failed")
                    _getAllAlerts.postValue(NetworkResult.Failed(result.message))
                }
            }
        }
    }

    fun loadAllBreaks() {
        viewModelScope.launch {
            val result = getAllBreaksUC()
            when (result) {

                is NetworkResult.Loading -> {
                    Log.d(HOME_VIEWMODEL_TAG, "generated alerts -loading")
                    _getAllBreaks.postValue(NetworkResult.Loading())
                }

                is NetworkResult.Success -> {
                    Log.d(HOME_VIEWMODEL_TAG, "generated alerts -success")
                    _getAllBreaks.postValue(NetworkResult.Success(result.data!!))
                }

                is NetworkResult.Failed -> {
                    Log.d(HOME_VIEWMODEL_TAG, "generated alerts -failed")
                    _getAllBreaks.postValue(NetworkResult.Failed(result.message))
                }
            }
        }
    }

    fun createGeneratedAlert(request: com.resoluteai.guardapp.data.remote.api_request.alert.CreateGeneratedAlertRequest) {
        viewModelScope.launch {
            val result = createGeneratedAlertUC(request)
            when (result) {

                is NetworkResult.Loading -> {
                    Log.d(HOME_VIEWMODEL_TAG, "generated alerts -loading")
                    _createGeneratedAlert.postValue(NetworkResult.Loading())
                }

                is NetworkResult.Success -> {
                    Log.d(HOME_VIEWMODEL_TAG, "generated alerts -success")
                    _createGeneratedAlert.postValue(NetworkResult.Success(result.data!!))
                }

                is NetworkResult.Failed -> {
                    Log.d(HOME_VIEWMODEL_TAG, "generated alerts -failed")
                    _createGeneratedAlert.postValue(NetworkResult.Failed(result.message))
                }
            }
        }
    }
}