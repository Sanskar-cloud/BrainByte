package com.resoluteai.guardapp.data.remote.api_request.event

data class LocationPermissionEvent(
    val isPermissionMissing: Boolean
)
