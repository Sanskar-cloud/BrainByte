package com.resoluteai.guardapp.broadcast

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.resoluteai.guardapp.presentation.dialog.StartBreakDialog
import com.resoluteai.guardapp.utils.Constant.Action_Event_Ended

class AlarmReceiver: BroadcastReceiver() {


    override fun onReceive(context: Context?, intent: Intent?) {

        Log.d("Alarm Receiver", "onreceive called")

        val message = intent?.getStringExtra("message")
        val isDutyEndAlarm = intent?.getBooleanExtra("is_duty_alarm", false)
        val isBreakEndAlarm = intent?.getBooleanExtra("is_break_alarm", false)

        Log.d("Alarm Receiver", "isDutyEndAlarm $isDutyEndAlarm")
        Log.d("Alarm Receiver", "isbreakEndAlarm $isBreakEndAlarm")

        val localIntent = Intent("updateUIBreakEnd")
        localIntent.putExtra("message", message)
        if (isDutyEndAlarm == true) {
            Log.d("Alarm Receiver", "isDutyEndAlarm true")
            localIntent.putExtra("is_duty_ended", true)
        }

        if (isBreakEndAlarm == true) {
            Log.d("Alarm Receiver", "isbreakEndAlarm true")
            localIntent.putExtra("is_break_ended", true)
        }


        LocalBroadcastManager.getInstance(context!!).sendBroadcast(localIntent)


    }


}