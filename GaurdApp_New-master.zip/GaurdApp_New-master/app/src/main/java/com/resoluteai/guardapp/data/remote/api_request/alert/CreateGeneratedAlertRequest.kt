package com.resoluteai.guardapp.data.remote.api_request.alert

data class CreateGeneratedAlertRequest(
    val alert_id: String,
    val event_id: String,
    val guard_id: String,
    val alert_name: String,
    val post_id: String,
    val summary: String = "This is sample summary !"
)
