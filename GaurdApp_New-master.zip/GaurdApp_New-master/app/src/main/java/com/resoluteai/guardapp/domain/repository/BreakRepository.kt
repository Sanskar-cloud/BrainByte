package com.resoluteai.guardapp.domain.repository

import com.resoluteai.guardapp.data.remote.api_response.Break
import com.resoluteai.guardapp.utils.NetworkResult

interface BreakRepository {

    suspend fun getAllBreaks(): NetworkResult<List<com.resoluteai.guardapp.data.remote.api_response.Break>>
}