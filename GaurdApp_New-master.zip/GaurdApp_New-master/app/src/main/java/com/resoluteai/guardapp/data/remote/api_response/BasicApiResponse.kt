package com.resoluteai.guardapp.data.remote.api_response

import com.google.gson.JsonDeserializationContext
import com.google.gson.JsonDeserializer
import com.google.gson.JsonElement
import com.google.gson.annotations.SerializedName
import java.lang.reflect.Type


data class BasicApiResponse<T>(
    val status: Boolean?= null,
    val message: String? = null,
    val data: T? = null
)

data class Detail(
    var error: String?,
    var traceback: String?
)

data class Error(
    @SerializedName("detail")
    val detail: String
)

class DetailDeserializer : JsonDeserializer<com.resoluteai.guardapp.data.remote.api_response.Detail> {

    override fun deserialize(
        json: JsonElement?,
        typeOfT: Type?,
        context: JsonDeserializationContext?
    ): com.resoluteai.guardapp.data.remote.api_response.Detail {
        val jsonObject = json?.asJsonObject

        // Extract the fields from the JSON object
        val error = jsonObject?.get("error")?.asString

        val traceback = jsonObject?.get("traceback")?.asString

        // Create a new Detail object with the extracted fields
        return com.resoluteai.guardapp.data.remote.api_response.Detail(error, traceback)
    }

}