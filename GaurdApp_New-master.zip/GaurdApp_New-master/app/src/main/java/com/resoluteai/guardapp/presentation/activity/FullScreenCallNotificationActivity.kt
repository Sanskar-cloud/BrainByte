package com.resoluteai.guardapp.presentation.activity

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.resoluteai.guardapp.databinding.ActivityIncomingCallFullScreenBinding
import com.resoluteai.guardapp.utils.turnScreenOffAndKeyguardOn
import com.resoluteai.guardapp.utils.turnScreenOnAndKeyguardOff


class FullScreenCallNotificationActivity: AppCompatActivity() {

    private lateinit var binding: ActivityIncomingCallFullScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIncomingCallFullScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val data = intent.getStringExtra("caller_name")
        Log.d("FULL SCREEN ACT", "data: $data")
        binding.textView2.text = data



       turnScreenOnAndKeyguardOff()

        binding.button.setOnClickListener {

            finish()
            val intent = Intent(this, CallActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            startActivity(intent)
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        turnScreenOffAndKeyguardOn()
    }
}

