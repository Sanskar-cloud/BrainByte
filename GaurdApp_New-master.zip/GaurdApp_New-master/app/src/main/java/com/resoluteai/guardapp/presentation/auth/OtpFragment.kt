package com.resoluteai.guardapp.presentation.auth

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.databinding.FragmentOtpBinding
import com.resoluteai.guardapp.presentation.EmployeeViewModel
import com.resoluteai.guardapp.presentation.dialog.LoadingDialog
import com.resoluteai.guardapp.presentation.dialog.NotifyAssignmentDialog
import com.resoluteai.guardapp.presentation.activity.OnLocationOTPActivity
import com.resoluteai.guardapp.utils.Constant.AssignmentOTPClass
import com.resoluteai.guardapp.utils.Constant.IsGuardEnteredAssignmentShown
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.TokenManager
import com.resoluteai.guardapp.utils.createPolygonCoords
import com.resoluteai.guardapp.utils.saveEmployeeInformation
import com.resoluteai.guardapp.utils.showToast
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject


@AndroidEntryPoint
class OtpFragment : Fragment() {

    private var _binding: FragmentOtpBinding? = null
    private val binding get() = _binding!!

    private val assignmentOTPViewModel by viewModels<LoginViewModel>()
    private val employeeViewModel by viewModels<EmployeeViewModel>()

    @Inject
    lateinit var tokenManager: TokenManager

    private lateinit var verifyAssignmentOTPDialog: LoadingDialog
    private var sourceLocation: String? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {







        _binding = FragmentOtpBinding.inflate(inflater,container,false)
        binding.gaurdEvent.text = "Event     : ${tokenManager.getEventName()}"
        binding.gaurdName.text = "${tokenManager.getProfileName()}"
         binding.gaurdId.text = "UIDAI     : ${tokenManager.getUidai()}"
            binding.emailID.text = "Email      : ${tokenManager.getEmail()}"
            binding.mobileNumber.text = "Mobile No.: ${tokenManager.getMobileNumber()}"
           binding.gaurdPost.text = "Post Name : ${tokenManager.getPostName()}"
            binding.gaurdShiftTime.text = "Shift Time: ${tokenManager.getShiftStartTime()} to ${tokenManager.getShiftEndTime()}"


        val notifyAssignmentDialog = NotifyAssignmentDialog()

        if (!IsGuardEnteredAssignmentShown) {
            requireActivity().supportFragmentManager.apply {
                notifyAssignmentDialog.show(this, NotifyAssignmentDialog.TAG)
            }
        }




        binding.backButton.setOnClickListener {
            findNavController().navigate(R.id.action_otpFragment_to_loginFragment)
        }

        binding.contiBtn.setOnClickListener {
                verifyAssignmentOTPDialog = LoadingDialog()
                verifyAssignmentOTPDialog.show(childFragmentManager, LoadingDialog.TAG)
                //API Call to Verify Assignment OTP
                assignmentOTPViewModel.acceptAssigment()
        }
        binding.directBtn.setOnClickListener {

            sourceLocation?.let {
                val source = sourceLocation
                val destination = "${tokenManager.getPostLatitude()},${tokenManager.getPostLongitude()}"
                val uri = Uri.parse("https://www.google.com/maps/dir/?api=1&origin=$source&destination=$destination")
                val mapIntent = Intent(Intent.ACTION_VIEW, uri)
                mapIntent.setPackage("com.google.android.apps.maps")

                if (mapIntent.resolveActivity(requireActivity().packageManager) != null) {
                    startActivity(mapIntent)
                } else {
                    val webIntent = Intent(Intent.ACTION_VIEW, uri)
                    startActivity(webIntent)
                }
            }?: kotlin.run {
                requireActivity().showToast("Not able to get your current location \n आपका वर्तमान स्थान प्राप्त करने में सक्षम नहीं है।")
            }


        }

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

            Log.d("Accept Assignment", tokenManager.getEventName())
        binding.gaurdEvent.text = "Event     : ${tokenManager.getEventName()}"
        binding.gaurdName.text = "${tokenManager.getProfileName()}"
        binding.gaurdId.text = "UIDAI     : ${tokenManager.getUidai()}"
        binding.emailID.text = "Email      : ${tokenManager.getEmail()}"
        binding.mobileNumber.text = "Mobile No.: ${tokenManager.getMobileNumber()}"
        binding.gaurdPost.text = "Post Name : ${tokenManager.getPostName()}"
        binding.gaurdShiftTime.text = "Shift Time: ${tokenManager.getShiftStartTime()} to ${tokenManager.getShiftEndTime()}"






        employeeViewModel.getEmployee.observe(viewLifecycleOwner) { result ->

            when(result) {

                is NetworkResult.Loading -> {

                }

                is NetworkResult.Success -> {
//                    Log.d("Accept Assignment", tokenManager.getEventName())


                    result.data?.let { saveEmployeeInformation(it, tokenManager) }
//                    Log.d("Accept Assignment", tokenManager.getEventName())

                    //check post id
                    if (result.data?.postId == null) {
                        employeeViewModel.fetchEmployee(true)
                                  } else {
                        Log.d("Accept Assignment", tokenManager.getEventName())
//                        binding.gaurdEvent.text = "Event     : ${tokenManager.getEventName()}"
//                        binding.gaurdName.text = "${tokenManager.getProfileName()}"
//                        binding.gaurdId.text = "UIDAI     : ${tokenManager.getUidai()}"
//                        binding.emailID.text = "Email      : ${tokenManager.getEmail()}"
//                        binding.mobileNumber.text = "Mobile No.: ${tokenManager.getMobileNumber()}"
//                        binding.gaurdPost.text = "Post Name : ${tokenManager.getPostName()}"
//                        binding.gaurdShiftTime.text = "Shift Time: ${tokenManager.getShiftStartTime()} to ${tokenManager.getShiftEndTime()}"

                        Log.d("Accept Assignment", tokenManager.getShiftEndTime())
                        Log.d(AssignmentOTPClass, result.message.toString())
                        verifyAssignmentOTPDialog.dismiss()
                        val intentStartDashboard = Intent(requireActivity(), OnLocationOTPActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        startActivity(intentStartDashboard)
                        activity?.finish()
                    }



                }

                is NetworkResult.Failed -> {
                    verifyAssignmentOTPDialog.dismiss()
                    requireActivity().showToast("Fetch Employee Data Failed \n कर्मचारी डेटा प्राप्ति असफल हुई")
                    result.message?.let { it1 -> Log.d("Fetch Employee FAILED", it1) }
                }
            }

        }

        assignmentOTPViewModel.acceptAssigment.observe(viewLifecycleOwner) {
            when(it) {

                is NetworkResult.Loading -> {

                }

                is NetworkResult.Success -> {
                    binding.gaurdEvent.text = "Event     : ${tokenManager.getEventName()}"

                    val delayInMillis = 5000L
                    viewLifecycleOwner.lifecycleScope.launch {
                        delay(delayInMillis)
                        employeeViewModel.fetchEmployee(merge = true)
                    }

                }

                is NetworkResult.Failed -> {
                    verifyAssignmentOTPDialog.dismiss()
                    requireActivity().showToast("Accept Assignment Failed: ${it.message}")
                    it.message?.let { it1 -> Log.d("VERIFY ACKNOWLEDGEMENT OTP FAILED", it1) }
                }
            }
        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
