package com.resoluteai.guardapp.data.remote.api_response.alert

data class EmergencyAuthority(
    val contact_detail: String,
    val contact_type: String,
    val name: String
)