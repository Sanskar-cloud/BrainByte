package com.resoluteai.guardapp.presentation.dialog


import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.data.remote.api_request.attendance.UpdateAttendanceRequest
import com.resoluteai.guardapp.data.remote.api_request.event.StatusEvent
import com.resoluteai.guardapp.domain.use_case.attendance.UpdateAttendanceUseCase
import com.resoluteai.guardapp.domain.use_case.event.TriggerEscalationUseCase
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.Constant.Action_EndBreakConfirmation
import com.resoluteai.guardapp.utils.Constant.Action_End_Break
import com.resoluteai.guardapp.utils.Constant.isBreakOnInApp
import com.resoluteai.guardapp.utils.Constant.isEscalationTimerEndedforBreakEnd
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.TokenManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import java.util.Calendar
import javax.inject.Inject

@AndroidEntryPoint
class EndBreakDialog: DialogFragment() {

    private lateinit var listener: EndBreakDialogListener

    interface EndBreakDialogListener {
        fun onEndBreakButtonClick(dialog: EndBreakDialog)
    }

    @Inject
    lateinit var tokenManager: TokenManager
    @Inject
    lateinit var updateAttendanceUC: UpdateAttendanceUseCase
    @Inject
    lateinit var triggerEscalationUC: TriggerEscalationUseCase

    override fun onAttach(context: Context) {
        super.onAttach(context)

        listener = context as EndBreakDialogListener
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val endBreakView = inflater.inflate(R.layout.dialog_break_end, container, false)
        dialog?.window?.setBackgroundDrawableResource(R.drawable.card_rounded_desgin)

        endBreakView.findViewById<Button>(R.id.cancelBtn).setOnClickListener {
            dismiss()
        }

        val timer = tokenManager.getBreakTimer()

        endBreakView.findViewById<Button>(R.id.startBtn).setOnClickListener {
            //end Break
            if (tokenManager.getCurrentBreakName().isNotBlank()) {
                updateattendance(
                    tokenManager.getEmployeeID(),
                    tokenManager.getEventID(),
                    tokenManager.getCurrentBreakName()
                ).also {
                    val intent = Intent(Action_EndBreakConfirmation)
                    intent.putExtra("user_confirmation_end", true)
                    LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(intent)
                }
            } else {
                Toast.makeText(requireContext(), "something went wrong: break name parsing error", Toast.LENGTH_SHORT).show()
            }



        }

        isCancelable = true

        return endBreakView
    }

    companion object {
        const val TAG = "EndBreak"
        const val LOG_TAG = "EndBreakDialog"
    }

    private fun updateattendance(empId: String, eventId: String, breakName: String?) {
        viewLifecycleOwner.lifecycleScope.launch {
            val rightNow: Calendar = Calendar.getInstance()
            val currentHourIn24Format = rightNow.get(Calendar.HOUR_OF_DAY).toString()
            val currentMin = rightNow.get(Calendar.MINUTE).toString()
            val result = updateAttendanceUC(
                UpdateAttendanceRequest(
                    employee_id = empId,
                    event_id = eventId,
                    break_id = "",
                    status = 4,
                    log = "Break $breakName ended at ${currentHourIn24Format}:${currentMin}"
                )
            )

            when(result) {

                is NetworkResult.Loading -> {

                }
                is NetworkResult.Success -> {

                    Log.d(LOG_TAG, "save status code ${result.data}")

                    result.data?.let {

                        tokenManager.saveStatusCode(it.status)
                        tokenManager.saveCurrentBreakName("")
                        if (tokenManager.getBreakNeedReplacement()) {
                            tokenManager.saveBreakNeedReplacement(false)
                        }
                        tokenManager.saveBreakId("")
                        //To Stop Showing Timer Dialog
                        isBreakOnInApp = false
                        isEscalationTimerEndedforBreakEnd = false

                        Log.d(LOG_TAG, "status code after successful update attendance for break end:${tokenManager.getStatusCode()}")

                        Log.d(LOG_TAG, "break id after successful update attendance for break end:${tokenManager.getBreakId()}")

                        //notify Location Service to stop Timer
                        val intent = Intent(Action_End_Break)
                        intent.putExtra("confirmation", true)
                        LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(intent)


                        listener.onEndBreakButtonClick(this@EndBreakDialog)

                        Toast.makeText(requireContext(), "Break $breakName ended successfully \n $breakName सफलतापूर्वक समाप्त हुआ।", Toast.LENGTH_SHORT).show()

                    }

                }
                is NetworkResult.Failed -> {
                    //handle exception
                    Toast.makeText(requireActivity(), "Break $breakName has not been ended \n $breakName अभी तक समाप्त नहीं किया गया है।", Toast.LENGTH_SHORT).show()
                }
            }

        }
    }

}