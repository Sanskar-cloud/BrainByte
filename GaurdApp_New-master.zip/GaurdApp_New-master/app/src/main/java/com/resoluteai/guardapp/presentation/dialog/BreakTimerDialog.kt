package com.resoluteai.guardapp.presentation.dialog

import android.content.Context
import android.content.IntentFilter
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.broadcast.BreakTimerReceiver
import com.resoluteai.guardapp.broadcast.MessageBreakTimerBroadcast
import com.resoluteai.guardapp.utils.Constant.Action_show_break_end_info
import com.resoluteai.guardapp.utils.Constant.isEscalationTimerEndedforBreakEnd
import com.resoluteai.guardapp.utils.TokenManager
import com.resoluteai.guardapp.utils.showToast
import dagger.hilt.android.AndroidEntryPoint
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@AndroidEntryPoint
class BreakTimerDialog: DialogFragment() {

    private lateinit var listener: BreakTimerDialogListener

    interface BreakTimerDialogListener {
        fun onEndButtonClick(dialog: BreakTimerDialog)
        fun onQRScannerClick(dialog: BreakTimerDialog)
    }

    @Inject
    lateinit var tokenManager: TokenManager


    override fun onAttach(context: Context) {
        super.onAttach(context)

        listener = context as BreakTimerDialogListener
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val breakTimerView = inflater.inflate(R.layout.dialog_break_timer, container, false)

        dialog?.window?.setBackgroundDrawableResource(R.drawable.card_rounded_desgin)

        Log.d(LOG_TAG, "${tokenManager.getBreakNeedReplacement()}")

        if (isEscalationTimerEndedforBreakEnd) {
            breakTimerView.findViewById<TextView>(R.id.break_timer).text = "Break Ended, Go to your post"
            isEscalationTimerEndedforBreakEnd = false
        }

        LocalBroadcastManager.getInstance(requireActivity()).registerReceiver(
            MessageBreakTimerBroadcast(
                object : MessageBreakTimerBroadcast.Callback {
                    override fun onBreakMessageReceived(message: String) {
                        Log.d("BreakTimer", "message received $message")
                        breakTimerView.findViewById<TextView>(R.id.break_timer).text = message
                    }

                }
            ),
            IntentFilter(Action_show_break_end_info)
        )

        if (tokenManager.getBreakNeedReplacement()) {
            Log.d(LOG_TAG, "${tokenManager.getBreakNeedReplacement()}")
            breakTimerView.findViewById<LinearLayout>(R.id.cancelDialog).visibility = View.GONE
            breakTimerView.findViewById<LinearLayout>(R.id.qr_scanner_dialog).visibility = View.VISIBLE
        }


        LocalBroadcastManager.getInstance(requireActivity()).registerReceiver(
            BreakTimerReceiver(
                object : BreakTimerReceiver.BreakTimerCallBack {
                    override fun onReceiveMillis(millis: Long) {
                        //update Dialog
                        val minutes = TimeUnit.MILLISECONDS.toMinutes(millis)
                        val seconds = TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(minutes)

                        if (minutes == 0L && seconds ==0L) {
                            breakTimerView.findViewById<TextView>(R.id.break_timer).text = "Break ended"
                        } else {
                            breakTimerView.findViewById<TextView>(R.id.break_timer).text = "Break ${tokenManager.getCurrentBreakName()} ends in $minutes:$seconds"
                        }


                    }

                }
            ),
            IntentFilter("break_timer")
        )

        breakTimerView.findViewById<LinearLayout>(R.id.cancelDialog).setOnClickListener {
            //cancel break and dismiss the dialog
            if (tokenManager.getCurrentBreakName().isNotBlank()) {

                listener.onEndButtonClick(this@BreakTimerDialog)

            } else {
                requireActivity().showToast("something went wrong \n कुछ गलत हुआ है")
            }

        }

        breakTimerView.findViewById<LinearLayout>(R.id.qr_scanner_dialog).setOnClickListener {
            if (tokenManager.getCurrentBreakName().isNotBlank() && tokenManager.getBreakNeedReplacement()) {
                listener.onQRScannerClick(this)

            } else {
                requireActivity().showToast("something went wrong \n कुछ गलत हुआ है")
            }
        }

        isCancelable = false

        return breakTimerView
    }




    companion object {
        const val TAG = "breakTimerDialog"
        const val LOG_TAG = "BreakTimerDialog"
    }




}