package com.resoluteai.guardapp.broadcast

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class CallNotifIndicatorBroadcast(private val callback: Callback): BroadcastReceiver() {

    interface Callback {
        fun onCallNotificationReceived(callerName: String)
        fun onCallEnded()
    }
    override fun onReceive(context: Context?, intent: Intent?) {
        val data = intent?.getBooleanExtra("call_notif_got", false)
        val name = intent?.getStringExtra("caller_name")

        if (data == true) {
            name?.let {
                callback.onCallNotificationReceived(it)
            }

        } else if (data == false) {
            callback.onCallEnded()
        }
    }
}