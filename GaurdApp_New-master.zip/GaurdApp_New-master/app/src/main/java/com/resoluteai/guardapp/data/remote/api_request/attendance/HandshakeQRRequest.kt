package com.resoluteai.guardapp.data.remote.api_request.attendance

data class HandshakeQRRequest(
    val event_id: String,
    val employee_id: String
)
