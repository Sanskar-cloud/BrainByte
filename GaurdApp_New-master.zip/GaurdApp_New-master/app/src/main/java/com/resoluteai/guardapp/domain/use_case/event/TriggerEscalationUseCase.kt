package com.resoluteai.guardapp.domain.use_case.event

import com.resoluteai.guardapp.domain.repository.EventRepository
import com.resoluteai.guardapp.utils.NetworkResult
import javax.inject.Inject

class TriggerEscalationUseCase @Inject constructor(
    private val eventRepository: EventRepository
) {

    suspend operator fun invoke(eventId: String): NetworkResult<Boolean> =
        eventRepository.triggerEscalation(eventId)
}