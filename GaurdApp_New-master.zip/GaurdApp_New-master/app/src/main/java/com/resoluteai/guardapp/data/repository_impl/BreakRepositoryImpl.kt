package com.resoluteai.guardapp.data.repository_impl

import android.util.Log
import com.google.gson.GsonBuilder
import com.resoluteai.guardapp.data.remote.BreakApi
import com.resoluteai.guardapp.data.remote.api_response.Break
import com.resoluteai.guardapp.domain.repository.BreakRepository
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.NetworkResult
import java.lang.Exception
import javax.inject.Inject

class BreakRepositoryImpl @Inject constructor(
    private val breakApi: BreakApi
): BreakRepository {
    override suspend fun getAllBreaks(): NetworkResult<List<Break>> {
        return try {

            val result = breakApi.getAllBreaks()

            if (result.isSuccessful) {

                if (result.body()!!.status == true) {
                    NetworkResult.Success(result.body()!!.data!!)
                } else {
                    NetworkResult.Failed(result.body()!!.message)
                }


            } else {

                if (result.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        result.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            com.resoluteai.guardapp.data.remote.api_response.Detail::class.java,
                            com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, com.resoluteai.guardapp.data.remote.api_response.Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, com.resoluteai.guardapp.data.remote.api_response.Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }
            }

        } catch (e: Exception) {
            NetworkResult.Failed(e.message)
        }
    }
}