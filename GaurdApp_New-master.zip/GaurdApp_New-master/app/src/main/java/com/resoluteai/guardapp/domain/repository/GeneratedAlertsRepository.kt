package com.resoluteai.guardapp.domain.repository

import com.resoluteai.guardapp.data.remote.api_request.alert.CreateGeneratedAlertRequest
import com.resoluteai.guardapp.domain.model.alert.GeneratedAlert
import com.resoluteai.guardapp.utils.NetworkResult

interface GeneratedAlertsRepository {

    suspend fun getGeneratedAlertsByEmpId(employeeId: String): NetworkResult<List<com.resoluteai.guardapp.domain.model.alert.GeneratedAlert>>

    suspend fun createGeneratedAlerts(requestBody: com.resoluteai.guardapp.data.remote.api_request.alert.CreateGeneratedAlertRequest): NetworkResult<com.resoluteai.guardapp.domain.model.alert.GeneratedAlert>
}