package com.resoluteai.guardapp.domain.model.socket

data class CaptchaResponse(
    val employeeId: String,
    val eventId: String
)
