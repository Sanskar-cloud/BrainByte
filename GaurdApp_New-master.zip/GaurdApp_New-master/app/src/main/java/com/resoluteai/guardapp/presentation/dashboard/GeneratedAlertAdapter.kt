package com.resoluteai.guardapp.presentation.dashboard

import android.content.Context
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.domain.model.generated_alert.GeneratedAlertModel
import com.resoluteai.guardapp.domain.model.socket.AlertStatus

class GeneratedAlertAdapter(
    private val context: Context,
    private val onClick: (String) -> Unit,
    private val alerts: ArrayList<GeneratedAlertModel>,
): RecyclerView.Adapter<GeneratedAlertAdapter.ViewHolder>() {

    private var alertStatus: AlertStatus? = null


    inner class ViewHolder(view: View): RecyclerView.ViewHolder(view) {

        val timpstamp : TextView
        val alertName : TextView
        val viewButton: TextView
        val statusIcon: ImageView

        init {
            timpstamp = view.findViewById(R.id.alertTimestamp)
            alertName = view.findViewById(R.id.alertName)
            viewButton = view.findViewById(R.id.viewButton)
            statusIcon = view.findViewById(R.id.statusIcon)
        }
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.sample_alert_row, viewGroup, false)

        return ViewHolder(view)
    }

    override fun getItemCount() = alerts.size + 1

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {

        viewHolder.setIsRecyclable(false)

        if (position == 0) {

            viewHolder.alertName.setTextColor(context.resources.getColor(R.color.black))
            val originalTypeface = viewHolder.timpstamp.typeface
            val newTypeface = Typeface.create(originalTypeface, Typeface.BOLD)

            viewHolder.timpstamp.text = "Timestamp"
            viewHolder.timpstamp.setTextColor(context.resources.getColor(R.color.black))
            viewHolder.timpstamp.typeface = newTypeface
            viewHolder.alertName.text = "Name"
            viewHolder.alertName.textSize = 12.0f
            viewHolder.timpstamp.textSize = 12.0f

            viewHolder.alertName.typeface = newTypeface
            //viewHolder.serialNo.text = (position+1).toString()
            viewHolder.statusIcon.visibility = View.GONE
            viewHolder.viewButton.visibility = View.VISIBLE
            viewHolder.viewButton.typeface = newTypeface
            viewHolder.viewButton.setTextColor(context.resources.getColor(R.color.black))
            viewHolder.viewButton.text = "Status"
            viewHolder.viewButton.textSize = 12.0f


        } else {

            val alert = alerts[position-1]
            viewHolder.timpstamp.text = alert.created_at
            viewHolder.alertName.text = alert.alert_name
            viewHolder.statusIcon.visibility = View.VISIBLE
            viewHolder.viewButton.visibility = View.GONE
            viewHolder.statusIcon.setImageResource(R.drawable.single_check)

            when(alert.status) {
                1 -> {
                    //Alert received
                    viewHolder.statusIcon.setImageResource(R.drawable.double_check)
                }
                2 -> {
                    //Alert action taken by operator
                    viewHolder.statusIcon.setImageResource(R.drawable.double_check_read)
                }
                3 -> {
                    //Alert escalated (No action taken by operator)
                    viewHolder.statusIcon.setImageResource(R.drawable.double_check_escalate)
                }
            }

            if (alertStatus != null) {
                if (alertStatus!!.employee_id == alert.guard_id && alertStatus!!.event_id == alert.event_id) {
                    when(alertStatus!!.status) {
                        1 -> {
                            //Alert received
                            viewHolder.statusIcon.setImageResource(R.drawable.double_check)
                        }
                        2 -> {
                            //Alert action taken by operator
                            viewHolder.statusIcon.setImageResource(R.drawable.double_check_read)
                        }
                        3 -> {
                            //Alert escalated (No action taken by operator)
                            viewHolder.statusIcon.setImageResource(R.drawable.double_check_escalate)
                        }
                    }
                }
            }




        }

    }

    fun setAlertStatus(data: AlertStatus) {
        alertStatus = data
    }

}