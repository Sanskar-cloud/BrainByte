package com.resoluteai.guardapp.data.remote.api_response

data class VerifyOtpFromGeofResData(
    val `data`: String,
    val message: String,
    val status: Boolean
)