package com.resoluteai.guardapp.broadcast

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.resoluteai.guardapp.data.remote.api_response.event.Shift
import com.resoluteai.guardapp.domain.model.socket.ShiftEndedConfirmation
import com.resoluteai.guardapp.socket.MySocketHandler
import com.resoluteai.guardapp.utils.TokenManager
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class DutyEndedBroadcastReceiver : BroadcastReceiver() {

    @Inject
    lateinit var tokenManager: TokenManager
    val socket = MySocketHandler.getSocket()

    override fun onReceive(context: Context, intent: Intent) {
        // This method will be called when shift time ended
        Log.d("DutyEndedBroadcastReceiver", "intent received")
        emitDutyEndedEvent()
    }

    private fun emitDutyEndedEvent(){
        if (socket?.connected() == true) {
            MySocketHandler.sendDutyEndedConfirmation(
                ShiftEndedConfirmation(
                    employee_id = tokenManager.getEmployeeID(),
                    event_id = tokenManager.getEventID(),
                    post_id = tokenManager.getSomePostId(),
                    guard_name = tokenManager.getProfileName(),
                    shift = Shift(
                        startTime = tokenManager.getShiftStartTime(),
                        endTime = tokenManager.getShiftEndTime()
                    ),
                    status = tokenManager.getStatusCode()
                )
            )
        } else {
            socket?.connect()
            MySocketHandler.sendDutyEndedConfirmation(
                ShiftEndedConfirmation(
                    employee_id = tokenManager.getEmployeeID(),
                    event_id = tokenManager.getEventID(),
                    post_id = tokenManager.getSomePostId(),
                    guard_name = tokenManager.getProfileName(),
                    shift = Shift(
                        startTime = tokenManager.getShiftStartTime(),
                        endTime = tokenManager.getShiftEndTime()
                    ),
                    status = tokenManager.getStatusCode()
                )
            )
        }
    }
}