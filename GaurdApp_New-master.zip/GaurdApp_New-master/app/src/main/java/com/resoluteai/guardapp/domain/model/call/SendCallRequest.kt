package com.resoluteai.guardapp.domain.model.call

data class CallRequest(
    val eventId: String,
    val employeeId: String,
    val receiverId: String,
    val senderPeerId: String,
    val metadata: com.resoluteai.guardapp.domain.model.call.CallMetadata,
    val receiverSocketId: String
)

data class CallMetadata(
    val name: String
)


data class SendCallRequest(
    val eventId: String,
    val employeeId: String,
    val receiverId: List<String>,
    val senderPeerId: String,
    val metadata: com.resoluteai.guardapp.domain.model.call.CallMetadata,
    val receiverSocketId: String
)
