package com.resoluteai.guardapp.domain.use_case.auth

import com.resoluteai.guardapp.domain.repository.AuthRepository
import com.resoluteai.guardapp.utils.NetworkResult
import javax.inject.Inject

class SendLoginOTPUseCase @Inject constructor(
    private val authRepository: AuthRepository
) {

    suspend operator fun invoke(phoneNumber: String, macAddress: String): NetworkResult<String> =
        authRepository.sendLoginOTP(phoneNumber, macAddress)
}