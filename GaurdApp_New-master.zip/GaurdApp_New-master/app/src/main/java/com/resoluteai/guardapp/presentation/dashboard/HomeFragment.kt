package com.resoluteai.guardapp.presentation.dashboard


import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.IntentSender
import android.graphics.Color
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.flexbox.FlexboxLayout.LayoutParams
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.LocationSettingsRequest
import com.google.android.gms.location.LocationSettingsResponse
import com.google.android.gms.location.SettingsClient
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.tasks.Task
import com.google.gson.Gson
import com.resoluteai.guardapp.R.*
import com.resoluteai.guardapp.broadcast.AttendanceUpdate
import com.resoluteai.guardapp.broadcast.LocationReceiver
import com.resoluteai.guardapp.broadcast.StatusUpdate
import com.resoluteai.guardapp.data.remote.api_response.Break
import com.resoluteai.guardapp.data.remote.api_response.alert.Alert
import com.resoluteai.guardapp.data.remote.api_response.attendance.Attendance
import com.resoluteai.guardapp.data.remote.api_response.employee.Employee
import com.resoluteai.guardapp.databinding.FragmentHomeBinding
import com.resoluteai.guardapp.domain.model.alert.GeneratedAlert
import com.resoluteai.guardapp.domain.model.generated_alert.GeneratedAlertModel
import com.resoluteai.guardapp.domain.model.socket.AlertStatus
import com.resoluteai.guardapp.presentation.EmployeeViewModel
import com.resoluteai.guardapp.presentation.LocationViewModel
import com.resoluteai.guardapp.presentation.dialog.BreakQR
import com.resoluteai.guardapp.presentation.dialog.ConfirmationAlertDialog
import com.resoluteai.guardapp.presentation.dialog.StartBreakDialog
import com.resoluteai.guardapp.socket.MySocketHandler
import com.resoluteai.guardapp.presentation.activity.DashboardActivity
import com.resoluteai.guardapp.presentation.activity.OnLocationOTPActivity
import com.resoluteai.guardapp.presentation.activity.Oprhandshake
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.Constant.Action_Location
import com.resoluteai.guardapp.utils.Constant.Action_Status_Update
import com.resoluteai.guardapp.utils.Constant.Action_Update_Attendance
import com.resoluteai.guardapp.utils.Constant.Get_Alert_Status
import com.resoluteai.guardapp.utils.Constant.Get_Alerts_Listener_Id
import com.resoluteai.guardapp.utils.Constant.Get_Attendance_Listener_Id
import com.resoluteai.guardapp.utils.Constant.Get_Breaks_Listener_Id
import com.resoluteai.guardapp.utils.Constant.Get_GA_Listener_Id
import com.resoluteai.guardapp.utils.Constant.HomeFragmentClass
import com.resoluteai.guardapp.utils.Constant.isLatLngInsidePolygon
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.TokenManager
import com.resoluteai.guardapp.utils.createPolygonCoords
import com.resoluteai.guardapp.utils.distance
import com.resoluteai.guardapp.utils.saveEmployeeInformation
import com.resoluteai.guardapp.utils.showToast
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class HomeFragment : Fragment() {

    @Inject
    lateinit var tokenManager: TokenManager
    lateinit var binding : FragmentHomeBinding

    private val homeViewModel by viewModels<HomeViewModel>()
    private val employeeViewModel by viewModels<EmployeeViewModel>()

    private var alertHistorys = ArrayList<GeneratedAlertModel>()
    private var alertsList = mutableListOf<Alert>()

    private lateinit var startBreakDialog: StartBreakDialog
    private lateinit var confirmationAlertDialog: ConfirmationAlertDialog
    private lateinit var locationViewModel: LocationViewModel

    private var alertHistoryAdapter: GeneratedAlertAdapter? = null
    private lateinit var alertAdapter: AlertAdapter


    private val fadeOut: Animation by lazy { AnimationUtils.loadAnimation(context, anim.fade_out) }


    @SuppressLint("MissingPermission")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {


        Log.d(HomeFragmentClass, "onCreate Called")


        //GET EMPLOYEE to Update Data
        employeeViewModel.fetchEmployee(true)

        binding = FragmentHomeBinding.inflate(inflater, container, false)


        if (MySocketHandler.mSocket == null) {

            try {
                MySocketHandler.setSocket(
                    tokenManager.getEventID(),
                    tokenManager.getEmployeeID(),
                    tokenManager.getSomeImportantClientID()
                )
                MySocketHandler.establishConnection()
            } catch (e: Exception) {
                e.printStackTrace()
            }

        }


        var lastScrollY = 0

        binding.scrollView2.viewTreeObserver.addOnScrollChangedListener {


            val newScrollY = binding.scrollView2.scrollY
            Log.d(HomeFragmentClass, "New Scroll: $newScrollY, Last Scroll: $lastScrollY")

            if (newScrollY == 0) {
                showBottomNavBar()
            }

            if (newScrollY > lastScrollY) {
                hideBottomNavBar()
            } else {
                showBottomNavBar()
            }

            lastScrollY = newScrollY
            Log.d(HomeFragmentClass, "After Assignment -- New Scroll: $newScrollY, Last Scroll: $lastScrollY")


        }


        alertAdapter = AlertAdapter(
            context = requireContext(),
            onClick = { alertId, alertName, bcolor, fcolor, unicode ->

                val args = Bundle().apply {
                    putString("alert_id", alertId)
                    putString("alert_name", alertName)
                    putString("b_color", bcolor)
                    putString("f_color", fcolor)
                    putString("unicode", unicode)
                }


                confirmationAlertDialog = ConfirmationAlertDialog(
                    object : ConfirmationAlertDialog.Callback {
                        override fun alertGenerated(data: GeneratedAlertModel) {
                            try {

                                if (MySocketHandler.getSocket() == null) {
                                    MySocketHandler.setSocket(
                                        tokenManager.getEventID(),
                                        tokenManager.getEmployeeID(),
                                        tokenManager.getSomeImportantClientID()
                                    )
                                    MySocketHandler.establishConnection()
                                    MySocketHandler.sendAlertFromGuard(data)
                                } else {
                                    MySocketHandler.sendAlertFromGuard(data)
                                }

                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                            alertHistorys.add(data)
                            alertHistoryAdapter?.notifyDataSetChanged()
                        }

                    }
                )
                confirmationAlertDialog.arguments = args
                confirmationAlertDialog.show(
                    childFragmentManager,
                    ConfirmationAlertDialog.TAG
                )

            },
            alerts = alertsList
        )
        alertHistoryAdapter = GeneratedAlertAdapter(
            context = requireContext(),
            onClick = { alertId ->
                //onClick on View Button
            },
            alerts = alertHistorys
        )

        locationViewModel = ViewModelProvider(this)[LocationViewModel::class.java]



        locationViewModel.getLastKnownLocation().observe(viewLifecycleOwner) { location ->
            if (location != null) {
                locationUpdateFarDistance(latitude = location.latitude, longitude = location.longitude)
            } else {
                // Handle the case when no location is available
            }
        }

        binding.meters.text = "..."
        binding.locationBoxMeterText.text = "fetching your location"


        if (savedInstanceState == null){
            homeViewModel.loadAllAlerts()
            homeViewModel.loadAllBreaks()
            homeViewModel.getGeneratedAlerts()
            Log.d(HomeFragmentClass, "Alert & Break & Generated Alerts API Called")
        }

        LocalBroadcastManager.getInstance(requireActivity()).registerReceiver(
            LocationReceiver(
                object : LocationReceiver.Callback {
                    override fun onLocationReceived(lat: Double, lng: Double) {
                        Log.d(HomeFragmentClass, "location update $isLocationUpdatesLoaded")
                        locationUpdateFarDistance(lat, lng)
                    }

                }
            ),

            IntentFilter(Action_Location)
        )

        //Show STATUS LAYOUT
        showStatusLayout()

        LocalBroadcastManager.getInstance(requireActivity()).registerReceiver(
            StatusUpdate(
                object: StatusUpdate.StatusUpdateCallback {
                    override fun updateStatus(status: Int) {
                        showStatusLayout()
                    }

                }
            ),
            IntentFilter(Action_Status_Update)
        )

        val manager = context?.getSystemService(Context.LOCATION_SERVICE) as LocationManager

        binding.refreshfromHome.setOnClickListener {
            fadeOut.start()
            if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER).not()) {

                requireActivity().showToast("Location Refreshed Successfully \n स्थान सफलतापूर्वक रिफ्रेश किया गया")
            } else {
                checkGPSEnabled()
                requireActivity().showToast("Location Refreshed Successfully \n स्थान सफलतापूर्वक रिफ्रेश किया गया")

            }
        }



        MySocketHandler.mSocket?.on(Get_GA_Listener_Id) { args ->
            if (args[0] != null) {
                Log.d(HomeFragmentClass, "Generated Alerts FETCHING socket")
                val json = args[0].toString()
                Log.d(HomeFragmentClass, "Alerts Listener: $json")
                try {

                    lifecycleScope.launch {

                        val alerts = Gson().fromJson(json, Array<GeneratedAlert>::class.java)
                        alertHistorys.clear()
                        alerts.forEach {
                            val data = it.toViewGeneratedAlert()
                            alertHistorys.add(data)
                        }.also {
                            alertHistoryAdapter?.notifyDataSetChanged()
                        }


                        Log.d(HomeFragmentClass, "Generated Alert Listener Successfully Added: $alerts")
                    }

                } catch (e: Exception) {
                    e.printStackTrace()
                }

            }
        }

        MySocketHandler.mSocket?.on(Get_Alerts_Listener_Id) { args ->
            try {
                if (args[0] != null) {
                    val json = args[0].toString()
                    Log.d(HomeFragmentClass, "alerts Listener: $json")

                    viewLifecycleOwner.lifecycleScope.launch {
                        try {

                            alertsList = Gson().fromJson(json, Array<Alert>::class.java).toMutableList()

                            alertAdapter.notifyDataSetChanged()

                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }


                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

        }

        MySocketHandler.mSocket?.on(Get_Breaks_Listener_Id) { args ->
            try {
                if (args[0] != null) {
                    val json = args[0].toString()
                    Log.d(HomeFragmentClass, "breaks Listener: $json")
                    viewLifecycleOwner.lifecycleScope.launch {
                        val breaksList = Gson().fromJson(json, Array<Break>::class.java)

                        binding.flowLayout.removeAllViews()
                        breaksList.forEach { breakOne ->
                            addItemToFlowLayout(
                                breakOne.name,
                                breakOne.id,
                                breakOne.time.toInt(),
                                breakOne.needReplacement,
                                breakOne.name
                            )
                        }

                    }


                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

        }

        MySocketHandler.mSocket?.on(Get_Attendance_Listener_Id) { args ->
            try {
                if (args[0] != null) {
                    val json = args[0].toString()
                    Log.d(HomeFragmentClass, "Attendance Listener: $json")
                    try {

                        val attendance = Gson().fromJson(json, Array<Attendance>::class.java)


                        if (attendance[0].extended_duty) {
                            //update shift end timer
                            val extendTime = attendance[0].extended_time
                            val regex = "(\\d+)h(\\d+)m".toRegex()
                            Log.d(HomeFragmentClass, "Duty has been Extended")

                            val matchResult = regex.find(extendTime)
                            if (matchResult != null) {
                                val (hoursStr, minutesStr) = matchResult.destructured
                                val hours = hoursStr.toInt()
                                val minutes = minutesStr.toInt()
                                tokenManager.saveShiftEndTime("$hours:$minutes")
                                Log.d(HomeFragmentClass, "${tokenManager.getShiftEndTime()}")

                                println("Hours: $hours")
                                println("Minutes: $minutes")
                            } else {
                                println("Invalid input format")
                            }

                        }

                        tokenManager.saveStatusCode(attendance[0].status)
                        showStatusLayout()

                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

        }

        MySocketHandler.mSocket?.on(Get_Alert_Status) { args ->
            if (args[0] != null) {
                Log.d(HomeFragmentClass, "Get Alert Status")
                val json = args[0].toString()
                lifecycleScope.launch {
                    val alertStatus = Gson().fromJson(json, AlertStatus::class.java)

//                    alertHistoryAdapter = GeneratedAlertAdapter(
//                        context = requireActivity(),
//                        onClick = { alertId ->
//                            //onClick on View Button
//                        },
//                        alerts = alertHistorys,
//
//                    )
//                    alertHistoryAdapter?.setAlertStatus(alertStatus)
//
//                    binding.generatedAlertRecycler.layoutManager = LinearLayoutManager(requireContext())
//                    binding.generatedAlertRecycler.adapter = alertHistoryAdapter
//                    binding.generatedAlertRecycler.setHasFixedSize(true)

                    if (alertHistoryAdapter != null) {
                        alertHistoryAdapter?.setAlertStatus(alertStatus)
                        alertHistoryAdapter?.notifyDataSetChanged()
                    }

                }


            }
        }




        LocalBroadcastManager.getInstance(requireContext()).registerReceiver(
            AttendanceUpdate(object : AttendanceUpdate.AttendanceUpdateCallback {
                override fun updateAttendance(attendance: Array<Attendance>) {
                    showStatusLayout()
                }
            }),
            IntentFilter(Action_Update_Attendance)
        )



        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner){
            activity?.finishAffinity()
        }


        return binding.root
    }



    private fun locationUpdateFarDistance(latitude: Double, longitude: Double) {

        Log.d(HomeFragmentClass, "Current Location: $latitude and $longitude")
        Log.d(HomeFragmentClass, "Post Location: ${tokenManager.getPostLatitude().toDouble()} and ${tokenManager.getPostLongitude().toDouble()}")
        val distance = distance(
            lat1 = latitude,
            lon1 = longitude,
            lat2 = tokenManager.getPostLatitude().toDouble(),
            lon2 = tokenManager.getPostLongitude().toDouble()
        )

        Log.d(HomeFragmentClass, "Dist From Post: $distance")
        Log.d(HomeFragmentClass, "Proximity: ${tokenManager.getPromixity()}")

        val currentLocation = LatLng(latitude, longitude)
        tokenManager.getGeoFunLiveLocation()?.let {

            if (isLatLngInsidePolygon(currentLocation, it)) {
                if (distance < tokenManager.getPromixity()) {

                    if (tokenManager.getRole() == "SG") {
                        if (tokenManager.getStatusCode() == 4) {
                            binding.locationBox.visibility = GONE
                        }
                        if (tokenManager.getStatusCode() == 3) {
                            binding.locationBox.visibility = VISIBLE
                            binding.meters.text = distance.toString()
                            binding.locationBoxMeterText.text = "meters away from post: ${tokenManager.getPostName()}"
                        }
                    }


                } else {

                    if (tokenManager.getRole() == "SG") {
                        Log.d(HomeFragmentClass, "location update else ccclaledc")
                        binding.locationBox.visibility = VISIBLE
                        binding.meters.text = distance.toString()
                        binding.locationBoxMeterText.text = "meters away from post: ${tokenManager.getPostName()}"
                        Log.d(HomeFragmentClass, "${binding.locationBoxMeterText.text}")
                    }

                }
            }
        }?: kotlin.run {
//            lifecycleScope.launch {
//                Toast.makeText(requireActivity(), "event location error", Toast.LENGTH_SHORT).show()
//            }

        }




    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        homeViewModel.generatedAlerts.observe(viewLifecycleOwner) { result ->
            when (result) {

                is NetworkResult.Loading -> {

                }

                is NetworkResult.Success -> {

                    Log.d(HomeFragmentClass, "Generated Alerts FETCHING")
                    alertHistorys.clear()
                    result.data?.forEach {
                        val data = it.toViewGeneratedAlert()
                        alertHistorys.add(data)
                    }

                    alertHistoryAdapter = GeneratedAlertAdapter(
                        context = requireContext(),
                        onClick = { alertId ->
                            //onClick on View Button
                        },
                        alerts = alertHistorys
                    )

                    binding.generatedAlertRecycler.layoutManager = LinearLayoutManager(requireContext())
                    binding.generatedAlertRecycler.adapter = alertHistoryAdapter
                    binding.generatedAlertRecycler.setHasFixedSize(true)

                }

                is NetworkResult.Failed -> {
                    Log.d(HomeFragmentClass, "G-Alert Failed: ${result.message}")
                    Toast.makeText(requireContext(), "G-Alert Loading Failed: ${result.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }

        homeViewModel.createGeneratedAlert.observe(viewLifecycleOwner) { result ->

            when(result) {

                is NetworkResult.Loading -> {

                }
                is NetworkResult.Success -> {
                    Toast.makeText(
                        requireActivity(),
                        "Alert has been successfully triggered \n अलर्ट सफलतापूर्वक ट्रिगर किया गया है।",
                        Toast.LENGTH_SHORT
                    ).show()


                    Log.d("confirmation alert dialog", "created generated alert")
                }
                is NetworkResult.Failed -> {

                    Log.d(HomeFragmentClass, "G-Alert Failed: ${result.message}")
                    Toast.makeText(requireContext(), "G-Alert Create Failed: ${result.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }

        employeeViewModel.getEmployee.observe(viewLifecycleOwner) { result ->

            when (result) {

                is NetworkResult.Loading -> {

                }

                is NetworkResult.Success -> {


                    binding.shimmerViewContainer.hideShimmer()

                    Log.d(HomeFragmentClass, "Employee Success: ${tokenManager.getStatusCode()}")

                    result.data?.let {
                        saveEmployeeInformation(it, tokenManager)
                        showStatusLayout()
                    }?: kotlin.run {
                        Toast.makeText(requireActivity(), "Employee Null in database", Toast.LENGTH_SHORT).show()
                    }


                }

                is NetworkResult.Failed -> {
                    binding.shimmerViewContainer.hideShimmer()
                    Log.d(HomeFragmentClass, "Employee Fetch Failed: ${result.message}")
                    Toast.makeText(requireActivity(), "Employee Fetch Failed: ${result.message}", Toast.LENGTH_SHORT).show()
                }

            }
        }

        homeViewModel.getAllAlerts.observe(viewLifecycleOwner) { result ->

            when (result) {
                is NetworkResult.Loading -> {
                    Log.d(HomeFragmentClass, "Alert Loading")
                }

                is NetworkResult.Success -> {

                    alertsList.clear().also {
                        alertsList = result.data?.toMutableList() ?: mutableListOf()
                        Log.d(HomeFragmentClass, "Alert List: $alertsList")
                        alertAdapter = AlertAdapter(
                            context = requireActivity(),
                            onClick = { alertId, alertName, bcolor, fcolor, unicode ->

                                val args = Bundle().apply {
                                    putString("alert_id", alertId)
                                    putString("alert_name", alertName)
                                    putString("b_color", bcolor)
                                    putString("f_color", fcolor)
                                    putString("unicode", unicode)
                                }


                                confirmationAlertDialog = ConfirmationAlertDialog(
                                    object : ConfirmationAlertDialog.Callback {
                                        override fun alertGenerated(data: GeneratedAlertModel) {
                                            try {
                                                if (MySocketHandler.getSocket() == null) {
                                                    MySocketHandler.setSocket(
                                                        tokenManager.getEventID(),
                                                        tokenManager.getEmployeeID(),
                                                        tokenManager.getSomeImportantClientID()
                                                    )
                                                    MySocketHandler.establishConnection()
                                                    MySocketHandler.sendAlertFromGuard(data)
                                                } else {
                                                    MySocketHandler.sendAlertFromGuard(data)
                                                }
                                            } catch (e: Exception) {
                                                e.printStackTrace()
                                            }
                                            alertHistorys.add(data)
                                            alertHistoryAdapter?.notifyDataSetChanged()
                                        }

                                    }
                                )
                                confirmationAlertDialog.arguments = args
                                confirmationAlertDialog.show(
                                    childFragmentManager,
                                    ConfirmationAlertDialog.TAG
                                )

                            },
                            alerts = alertsList
                        )
                        binding.alertRecycler.layoutManager = GridLayoutManager(requireContext(), 4)
                        binding.alertRecycler.adapter = alertAdapter
                        binding.alertRecycler.setHasFixedSize(true)
                    }

                }

                is NetworkResult.Failed -> {
                    Log.d(HomeFragmentClass, "Alert Failed: ${result.message}")
                    Toast.makeText(requireActivity(), "Alert Loading Failed: ${result.message}", Toast.LENGTH_SHORT).show()
                }
            }

        }

        homeViewModel.getAllBreaks.observe(viewLifecycleOwner) { result ->

            when (result) {
                is NetworkResult.Loading -> {

                }

                is NetworkResult.Success -> {

                    binding.flowLayout.removeAllViews()
                    result.data?.forEach { breakOne ->
                        Log.d(HomeFragmentClass, "break list item $breakOne")
                        addItemToFlowLayout(
                            breakOne.name,
                            breakOne.id,
                            breakOne.time.toInt(),
                            breakOne.needReplacement,
                            breakOne.name
                        )

                    }


                }

                is NetworkResult.Failed -> {
                    binding.shimmerViewContainer.hideShimmer()
                    Log.d(HomeFragmentClass, "Break Failed: ${result.message}")
                    Toast.makeText(requireActivity(), "Break Loading Failed: ${result.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }



    }








    private fun addItemToFlowLayout(
        itemText: String,
        breakId: String,
        timer: Int,
        needReplacement: Boolean,
        breakName: String
    ) {
        val itemTextView = TextView(context)
        itemTextView.text = itemText

        val drawable = ContextCompat.getDrawable(requireContext(), drawable.card_break_rounded_design)
        itemTextView.setPaddingRelative(40, 20, 40, 20)
        itemTextView.background = drawable// Optional: Set a background drawable
        itemTextView.setTextColor(Color.BLACK)
        itemTextView.textSize = 12F

        val layoutParams = LayoutParams(
            LayoutParams.WRAP_CONTENT,
            LayoutParams.WRAP_CONTENT
        )
        layoutParams.setMargins(20, 20, 20, 20) // Optional: Set margins

        itemTextView.layoutParams = layoutParams
        binding.flowLayout.addView(itemTextView)

        itemTextView.setOnClickListener {

            tokenManager.saveNeedReplacementBreak(needReplacement)

            itemTextView.startAnimation(fadeOut)

            if (tokenManager.getStatusCode() == 4) {

                //Guard can access the break if he/she is on duty

                if (needReplacement) {
                    //If Guard need replacement then show Break QR Code Dialog
                    tokenManager.saveBreakNeedReplacement(true)
                    //Save Break Time
                    tokenManager.saveBreakTimer(timer)

                    val dialog = BreakQR()
                    val args = Bundle()
                    args.putString("break_name", breakName)
                    args.putBoolean("need_replacement", true)
                    args.putString("breakId", breakId)
                    dialog.arguments = args
                    Log.d(HomeFragmentClass, "${args.getString("breakId")}")
                    activity?.supportFragmentManager?.let {
                        dialog.show(it, BreakQR.TAG)
                    }

                } else {

                    //If Guard don't need replacement then confirmation dialog to start a break
                    val args = Bundle()
                    args.putInt("clicked_break_time_in_min", timer)
                    args.putString("break_name", breakName)
                    args.putString("argBreakId", breakId)

                    tokenManager.saveBreakNeedReplacement(false)
                    //Save Break Time
                    tokenManager.saveBreakTimer(timer)

                    Log.d(HomeFragmentClass, "${tokenManager.getBreakNeedReplacement()}")
                    startBreakDialog = StartBreakDialog()
                    startBreakDialog.arguments = args
                    activity?.supportFragmentManager?.let {
                        startBreakDialog.show(it, StartBreakDialog.TAG)
                    }?: kotlin.run {
                        Log.d(HomeFragmentClass, "Start Break Dialog: SupportManager is null")
                    }


                }

            } else {

                //if Guard is not on duty then he/she is not allowed to get break
                requireActivity().showToast("YOU ARE NOT ALLOWED TO GET BREAK \n आपको अवकाश मिलने की अनुमति नहीं है।")
            }

        }
    }


    private fun showStatusLayout() {
        Log.d(HomeFragmentClass, "show status called")
        when(tokenManager.getStatusCode()) {
            0 ->  {
                binding.currentStatusBoxlayout.text = "Current Status - "+tokenManager.getStatusCode()+" : NONE"
            }
            1 -> {

            }
            2 -> {
                binding.currentStatusBoxlayout.text = "Current Status - "+tokenManager.getStatusCode()+" : ASSIGNED"
                //navigate to onLocation
                val intent = Intent(requireContext(), OnLocationOTPActivity::class.java).apply{
                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
                activity?.finish()
            }
            3 -> {
                binding.currentStatusBoxlayout.text = "Current Status - "+tokenManager.getStatusCode()+" : ON LOCATION"
                if (!binding.locationBox.isVisible) {
                    binding.locationBox.visibility = VISIBLE
                }
            }
            4 -> {
                if(tokenManager.getRole()=="OPR"){
                    val intentStartDashboard = Intent(requireActivity(), Oprhandshake::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intentStartDashboard)
                    activity?.finish()
                }
                binding.currentStatusBoxlayout.text = "Current Status - "+tokenManager.getStatusCode()+" : ON DUTY"
                binding.locationBox.visibility = GONE


            }
        }

    }



    override fun onDestroyView() {
        super.onDestroyView()
        Log.d(HomeFragmentClass, "on destroy view called")
        isLocationUpdatesLoaded = false
    }






    private fun checkGPSEnabled() {
        val manager = context?.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (manager.isProviderEnabled(LocationManager.GPS_PROVIDER).not()) {
            binding.meters.text = "..."
            binding.locationBoxMeterText.text = "turn on GPS to fetch the Location"
            turnOnGPS()
        }
    }
    private fun turnOnGPS() {
        Log.d(Constant.OnLocationOTP, "turned on GPS Called")
        val request = LocationRequest.create().apply {
            interval = 2000
            priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        }
        val client: SettingsClient = LocationServices.getSettingsClient(requireActivity())
        val builder = LocationSettingsRequest.Builder()
            .addLocationRequest(request)
            .build()
        val task: Task<LocationSettingsResponse> = client.checkLocationSettings(builder)
        task.addOnFailureListener {
            if (it is ResolvableApiException) {
                try {
                    it.startResolutionForResult(requireActivity(), 12345)
                } catch (sendEx: IntentSender.SendIntentException) {
                }
            }
        }.addOnSuccessListener {
            //here GPS is On

            Log.d(Constant.OnLocationOTP, "suceess locationotp")

        }
    }
    private fun hideBottomNavBar() {
        (activity as DashboardActivity).hideBottomNavBar()
    }

    private fun showBottomNavBar() {
        (activity as DashboardActivity).showBottomNavBar()
    }

    companion object {
        var isQRDialogCancelled = false
        var isLocationUpdatesLoaded = false
    }


}
