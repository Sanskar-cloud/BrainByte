package com.resoluteai.guardapp.presentation

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.resoluteai.guardapp.data.remote.api_response.employee.Employee
import com.resoluteai.guardapp.domain.use_case.employee.GetEmployeeUseCase
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.SingleLiveData
import com.resoluteai.guardapp.utils.TokenManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class EmployeeViewModel @Inject constructor(
    private val getEmployeeUC: GetEmployeeUseCase,
    private val tokenManager: TokenManager
): ViewModel() {



    private  val _getEmployee = SingleLiveData<NetworkResult<Employee>>()
    val getEmployee : LiveData<NetworkResult<Employee>>
        get() = _getEmployee

    fun fetchEmployee(merge: Boolean) {
        viewModelScope.launch {
            val result = getEmployeeUC(
                tokenManager.getEmployeeID(),
                merge
            )

            when (result) {

                is NetworkResult.Loading -> {
                    _getEmployee.postValue((NetworkResult.Loading()))                }
                is NetworkResult.Success -> {
                    _getEmployee.postValue(NetworkResult.Success(result.data!!))

                }
                is NetworkResult.Failed -> {
                    _getEmployee.postValue(NetworkResult.Failed(result.message))
                }

            }
        }
    }

}