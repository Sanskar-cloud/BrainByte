package com.resoluteai.guardapp.data.remote

import com.resoluteai.guardapp.data.remote.api_response.BasicApiResponse
import com.resoluteai.guardapp.data.remote.api_response.alert.Alert
import retrofit2.Response
import retrofit2.http.GET

interface AlertApi {

    @GET("/api/v1/get-all-alerts")
    suspend fun getAllAlerts(): Response<BasicApiResponse<List<Alert>>>


}