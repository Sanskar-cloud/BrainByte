package com.resoluteai.guardapp.presentation.on_location

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.IntentSender
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.Granularity
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.LocationSettingsRequest
import com.google.android.gms.location.LocationSettingsResponse
import com.google.android.gms.location.Priority
import com.google.android.gms.location.SettingsClient
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.tasks.Task
import com.google.gson.Gson
import com.google.maps.android.PolyUtil
import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.broadcast.LocationEnabledBroadcast
import com.resoluteai.guardapp.data.remote.api_response.attendance.Attendance
import com.resoluteai.guardapp.databinding.FragmentOnLocationOtpBinding
import com.resoluteai.guardapp.presentation.EmployeeViewModel
import com.resoluteai.guardapp.presentation.LocationViewModel
import com.resoluteai.guardapp.presentation.dialog.LoadingDialog
import com.resoluteai.guardapp.presentation.dialog.NotifyAssignmentDialog
import com.resoluteai.guardapp.presentation.dialog.NotifyOnLocationOTPDialog
import com.resoluteai.guardapp.socket.MySocketHandler
import com.resoluteai.guardapp.presentation.activity.DashboardActivity
import com.resoluteai.guardapp.presentation.activity.Oprhandshake
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.Constant.Get_Attendance_Listener_Id
import com.resoluteai.guardapp.utils.Constant.ISGuardEnteredOnLocationShown
import com.resoluteai.guardapp.utils.Constant.OnLocationOTP
import com.resoluteai.guardapp.utils.DefaultLocationClient
import com.resoluteai.guardapp.utils.LocationClient
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.TokenManager
import com.resoluteai.guardapp.utils.checkShiftIsValid
import com.resoluteai.guardapp.utils.checkShiftTime
import com.resoluteai.guardapp.utils.distance
import com.resoluteai.guardapp.utils.isEmployeeInsideEventLocation
import com.resoluteai.guardapp.utils.saveEmployeeInformation
import com.resoluteai.guardapp.utils.showToast
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Calendar
import javax.inject.Inject

@AndroidEntryPoint
class OnLocationFragment: Fragment() {

    @Inject
    lateinit var tokenManager: TokenManager

    private val onLocationOTPViewModel by viewModels<OnLocationOTPViewModel>()
    private val employeeViewModel by viewModels<EmployeeViewModel>()
    private lateinit var locationManager: LocationManager

    lateinit var binding : FragmentOnLocationOtpBinding
    private lateinit var verifyOnLocationDialog: LoadingDialog
    private lateinit var locationClient: LocationClient

    private lateinit var locationViewModel: LocationViewModel

    private val locationEnabledBroadcast: LocationEnabledBroadcast = LocationEnabledBroadcast(object : LocationEnabledBroadcast.LocationCallBack {
        override fun turnedOn() {
            Log.d(OnLocationOTP, "location is turnedOn")
            locationUpdatesJob = locationClient
                .getLocationUpdates(5000L)
                .catch { e -> e.printStackTrace() }
                .onEach { location ->
                    locationUpdateFarDistance(location)
                }
                .launchIn(lifecycleScope)


        }

        override fun turnedOff() {
            Log.d(OnLocationOTP, "location is turned Off")
            locationUpdatesJob?.cancel()
            turnOnGPS()
        }
    })

    private var isEmployeeInsideLocation = false

    private val fadeOut: Animation by lazy { AnimationUtils.loadAnimation(context, R.anim.fade_out) }

    private var locationUpdatesJob: Job? = null



    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        locationManager  = requireActivity().getSystemService(Context.LOCATION_SERVICE) as LocationManager

        locationClient = DefaultLocationClient(
            requireActivity(),
            LocationServices.getFusedLocationProviderClient(requireActivity())
        )
        binding = FragmentOnLocationOtpBinding.inflate(layoutInflater)



        val manager = requireContext().getSystemService(Context.LOCATION_SERVICE) as LocationManager
        locationEnabledUpdates(locationManager)

        val notifyOnLocationOTPDialog = NotifyOnLocationOTPDialog()



        if (!ISGuardEnteredOnLocationShown) {
            requireActivity().supportFragmentManager.apply {
                notifyOnLocationOTPDialog.show(this, NotifyAssignmentDialog.TAG)
                ISGuardEnteredOnLocationShown = true
            }
        }







        //show current status
        showStatusLayout()

        binding.meters.text = "..."
        binding.locationBoxMeterText.text = "fetching your location"



        locationViewModel = ViewModelProvider(this)[LocationViewModel::class.java]

        locationViewModel.getLastKnownLocation().observe(viewLifecycleOwner) { location ->
            if (location != null) {
                locationUpdateFarDistance(location)
            } else {
                // Handle the case when no location is available
            }
        }


        requireActivity().registerReceiver(
            locationEnabledBroadcast,
            IntentFilter(LocationManager.MODE_CHANGED_ACTION)
        )

        if (MySocketHandler.getSocket() == null) {
            MySocketHandler.setSocket(
                eventId = tokenManager.getEventID(),
                employeeId = tokenManager.getEmployeeID(),
                clientId = tokenManager.getSomeImportantClientID()
            )
            MySocketHandler.establishConnection()
        }



        MySocketHandler.mSocket?.on(Get_Attendance_Listener_Id) { args ->
            try {
                if (args[0] != null) {
                    val json = args[0].toString()
                    Log.d(OnLocationOTP, "Attendance Listener: $json")
                    try {

                        val attendance = Gson().fromJson(json, Array<Attendance>::class.java)

                        val currentShift = tokenManager.getShiftNo()
                        if (attendance[0].shift != currentShift) {
                            employeeViewModel.fetchEmployee(true)
                        }

                        if (attendance[0].extended_duty) {
                            //update shift end timer
                            val extendTime = attendance[0].extended_time
                            val regex = "(\\d+)h(\\d+)m".toRegex()
                            Log.d(OnLocationOTP, "Duty has been Extended")

                            val matchResult = regex.find(extendTime)
                            if (matchResult != null) {
                                val (hoursStr, minutesStr) = matchResult.destructured
                                val hours = hoursStr.toInt()
                                val minutes = minutesStr.toInt()
                                tokenManager.saveShiftEndTime("$hours:$minutes")
                                Log.d("OnLocationOTP", "${tokenManager.getShiftEndTime()}")

                                Log.d("OnLocationOTP","Hours: $hours")
                                Log.d("OnLocationOTP","Minutes: $minutes")
                            } else {
                                Log.d("OnLocationOTP","Invalid input format")
                            }

                        }

                        tokenManager.saveStatusCode(attendance[0].status)
                        showStatusLayout()

                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

        }


        binding.infoIcon.setOnClickListener {
            requireActivity().supportFragmentManager.apply {
                notifyOnLocationOTPDialog.show(this, NotifyAssignmentDialog.TAG)
                ISGuardEnteredOnLocationShown = true
            }
        }


        binding.refreshBtnLocation.setOnClickListener {
            fadeOut.start()
            locationViewModel.getLastKnownLocation().observe(viewLifecycleOwner) { location ->
                if (location != null) {
                    locationUpdateFarDistance(location)
                }

                    requireActivity().showToast("Location Refreshed Successfully \n स्थान सफलतापूर्वक रिफ्रेश किया गया")
                }
            }


        binding.sendOtpBtn.setOnClickListener {

            val shiftStartTime = tokenManager.getShiftStartTime().split(":")
            val shiftEndTime = tokenManager.getShiftEndTime().split(":")
            val bufferInMin = 20

            try {
                if (checkShiftTime(shiftStartTime, shiftEndTime, bufferInMin)) {
                    if (isEmployeeInsideLocation) {
                        verifyOnLocationDialog = LoadingDialog()
                        verifyOnLocationDialog.show(childFragmentManager, LoadingDialog.TAG)
                        onLocationOTPViewModel.checkInToLoaction()
                    } else {
                        requireActivity().showToast("you are not in the Event Location \n आप घटना स्थान पर नहीं हैं")
                    }
                } else {
                    requireActivity().showToast("your shift isn't started \n आपका शिफ्ट शुरू नहीं हुआ है।")
                }
            } catch (e: Exception) {
                e.printStackTrace()

            }


        }



        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        employeeViewModel.getEmployee.observe(viewLifecycleOwner) { result ->
            when(result) {
                is NetworkResult.Success -> {
                    result.data?.let { saveEmployeeInformation(it, tokenManager) }
                }

                is NetworkResult.Failed -> {
                    Log.d(OnLocationOTP, "Employee Api Failed")
                }

                is NetworkResult.Loading -> {

                }


            }
        }

        onLocationOTPViewModel.sendOnLocationOTP.observe(viewLifecycleOwner) { result ->
            when(result) {
                is NetworkResult.Success -> {
                    Log.d(OnLocationOTP,"Status has been Updated")
                    verifyOnLocationDialog.dismiss()
                    tokenManager.saveStatusCode(3)
                    if(tokenManager.getRole()=="OPR"){
                        val intent = Intent(requireActivity(), Oprhandshake::class.java).apply{
                            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        startActivity(intent)
                        requireActivity().finish()


                    }

                    val intent = Intent(requireActivity(), DashboardActivity::class.java).apply{
                        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                    requireActivity().finish()
                    requireActivity().showToast("Status has been updated \n स्थिति अपडेट की गई है।")
                }

                is NetworkResult.Failed -> {
                    verifyOnLocationDialog.dismiss()
                    requireActivity().showToast("error!!")
                }

                is NetworkResult.Loading -> {

                }


            }
        }
    }

    private fun locationUpdateFarDistance(location: Location) {

        Log.d(OnLocationOTP, "current Location: ${location.latitude} and ${location.longitude}")
        val currentLocation = LatLng(location.latitude, location.longitude)
        val polygonCoords = tokenManager.getGeoFunLiveLocation()

        Log.d(OnLocationOTP,"Post Location: ${tokenManager.getPostLatitude().toDouble()}" +" and "+tokenManager.getPostLongitude().toString())

        val distance = distance(
            location.latitude,
            location.longitude,
            tokenManager.getPostLatitude().toDouble(),
            tokenManager.getPostLongitude().toDouble()
        )

        Log.d(OnLocationOTP, distance.toString())

        val distancesToEdges = mutableListOf<Float>()
        if (polygonCoords != null) {
            for (i in polygonCoords.indices) {
                val j = (i + 1) % polygonCoords.size
                val distanceToEdge = PolyUtil.distanceToLine(currentLocation, polygonCoords[i], polygonCoords[j])
                    .toInt()
                distancesToEdges.add(distanceToEdge.toFloat())
            }
        }
        val distanceToNearestEdge = distancesToEdges.minOrNull()?.toInt()

        //isLocationUpdatesLoaded = true

        when(isEmployeeInsideEventLocation(location, tokenManager)) {
            true -> {

                Log.d(OnLocationOTP, "employee is inside event")
                isEmployeeInsideLocation = true

                binding.locationBox.visibility = View.VISIBLE
                binding.meters.text = distance.toString()
                binding.locationBoxMeterText.text = "meters away from post: ${tokenManager.getPostName()}"
            }

            false -> {
                Log.d(OnLocationOTP, "employee is not inside event")
                isEmployeeInsideLocation = false
                binding.locationBox.visibility = View.VISIBLE
                binding.meters.text = distanceToNearestEdge.toString()
                binding.locationBoxMeterText.text = "meters away from Event Location: ${tokenManager.getEventName()}"
            }

            null -> {
                binding.locationBoxMeterText.text = "location error"
            }
        }


    }




    override fun onStop() {
        super.onStop()
        isEmployeeInsideLocation = false
    }

    override fun onResume() {
        super.onResume()

        Log.d(OnLocationOTP, "onResume called")

    }

    override fun onDestroyView() {
        super.onDestroyView()
        locationUpdatesJob?.cancel()
        MySocketHandler.closeConnection()
        requireActivity().unregisterReceiver(locationEnabledBroadcast)
        Log.d(OnLocationOTP, "on destroy view called")
    }

    private fun checkGPSEnabled() {
        val manager = context?.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (manager.isProviderEnabled(LocationManager.GPS_PROVIDER).not()) {
            binding.meters.text = "..."
            binding.locationBoxMeterText.text = "turn on GPS to fetch the Location"
            turnOnGPS()
        }
    }


    private fun locationEnabledUpdates(manager: LocationManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            if (manager.isLocationEnabled) {
                locationUpdatesJob?.cancel()
                locationUpdatesJob = lifecycleScope.launch {
                    locationClient
                        .getLocationUpdates(5000L)
                        .catch { e -> e.printStackTrace() }
                        .onEach { location ->
                            locationUpdateFarDistance(location)
                        }
                }
            } else {
                turnOnGPS()
            }
        }
    }

    private fun turnOnGPS() {
        Log.d(OnLocationOTP, "turned on GPS Called")
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000).apply {
            setMinUpdateDistanceMeters(1f)
            setGranularity(Granularity.GRANULARITY_PERMISSION_LEVEL)
            setWaitForAccurateLocation(true)
        }.build()

        val client: SettingsClient = LocationServices.getSettingsClient(requireActivity())
        val builder = LocationSettingsRequest.Builder()
            .addLocationRequest(request)
            .build()

        val task: Task<LocationSettingsResponse> = client.checkLocationSettings(builder)
        task.addOnFailureListener {
            if (it is ResolvableApiException) {
                try {
                    it.startResolutionForResult(requireActivity(), 12345)
                } catch (sendEx: IntentSender.SendIntentException) {
                }
            }
        }.addOnSuccessListener {
            //here GPS is On

            Log.d(OnLocationOTP, "suceess locationotp")

        }
    }

    private fun showStatusLayout() {
        Log.d(Constant.HomeFragmentClass, "show status called")
        when(tokenManager.getStatusCode()) {
            0 ->  {
                binding.currentStatusBoxlayout.text = "Current Status - "+tokenManager.getStatusCode()+" : NONE"
            }
            1 -> {

            }
            2 -> {
                binding.currentStatusBoxlayout.text = "Current Status - "+tokenManager.getStatusCode()+" : ASSIGNED"
            }
            3 -> {
                binding.currentStatusBoxlayout.text = "Current Status - "+tokenManager.getStatusCode()+" : ON LOCATION"
            }
            4 -> {
                if(tokenManager.getRole()=="OPR"){
                    startActivity(Intent(requireActivity(), Oprhandshake::class.java))
                    requireActivity().finishAffinity()
                }
                binding.currentStatusBoxlayout.text = "Current Status - "+tokenManager.getStatusCode()+" : ON DUTY"
            }
        }

    }



}