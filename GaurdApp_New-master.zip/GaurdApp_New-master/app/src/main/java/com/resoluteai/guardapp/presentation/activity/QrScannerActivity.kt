package com.resoluteai.guardapp.presentation.activity

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.budiyev.android.codescanner.AutoFocusMode
import com.budiyev.android.codescanner.CodeScanner
import com.budiyev.android.codescanner.DecodeCallback
import com.budiyev.android.codescanner.ErrorCallback
import com.resoluteai.guardapp.data.remote.api_request.attendance.HandshakeQRRequest
import com.resoluteai.guardapp.data.remote.api_request.break_request.BreakRequest
import com.resoluteai.guardapp.presentation.profile.ProfileViewModel
import com.resoluteai.guardapp.databinding.ActivityQrScannerBinding
import com.resoluteai.guardapp.presentation.dialog.LoadingDialog
import com.resoluteai.guardapp.utils.Constant.QRScannerActivityClass
import com.resoluteai.guardapp.utils.Constant.isBreakOnInApp
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.TokenManager
import com.resoluteai.guardapp.utils.checkShiftTime
import com.resoluteai.guardapp.utils.showToast
import dagger.hilt.android.AndroidEntryPoint
import java.util.Calendar
import javax.inject.Inject

@AndroidEntryPoint
class QrScannerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityQrScannerBinding

    private lateinit var codeScanner: CodeScanner
    @Inject
    lateinit var tokenManager: TokenManager
    private val profileViewModel by viewModels<ProfileViewModel>()
    private var isQRCodeValid = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQrScannerBinding.inflate(layoutInflater)
        setContentView(binding.root)


        codeScanner = CodeScanner(this, binding.codeScannerView)
        codeScanner.camera = CodeScanner.CAMERA_BACK
        codeScanner.formats = CodeScanner.ALL_FORMATS
        codeScanner.autoFocusMode = AutoFocusMode.SAFE
        codeScanner.isAutoFocusEnabled = true
        codeScanner.isFlashEnabled = false

        val ownBreakId = tokenManager.getBreakId()

        profileViewModel.tempTransferPost.observe(this) { result ->

            when(result) {
                is NetworkResult.Loading -> {

                }

                is NetworkResult.Success -> {
                    Toast.makeText(this@QrScannerActivity, "Request for transfer post successfully executed", Toast.LENGTH_SHORT).show()
                    Log.d(QRScannerActivityClass, "temporary transfer post API Success")

                    val intent = Intent(this@QrScannerActivity, DashboardActivity::class.java).apply {
                        putExtra("QR_CODE_SCANNED", true)
                        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                    finish()
                }

                is NetworkResult.Failed -> {
                    Toast.makeText(this@QrScannerActivity, "Request for transfer post not successfully executed", Toast.LENGTH_SHORT).show()
                }
            }
        }

        profileViewModel.reclaimPost.observe(this) { result ->


            when(result) {
                is NetworkResult.Loading -> {

                }

                is NetworkResult.Success -> {

                    isBreakOnInApp = false

                    Log.d("BREAK TIMER0", "$isBreakOnInApp")

                    val endBreakTimer = Intent("end_break_timer")
                    endBreakTimer.putExtra("confirmation", true)

                    LocalBroadcastManager.getInstance(this@QrScannerActivity).sendBroadcast(endBreakTimer)


                    if (!isBreakOnInApp) {
                        val intent = Intent(this@QrScannerActivity, DashboardActivity::class.java).apply {
                            putExtra("RECLAIM_POST_SUCCESS", true)
                            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        startActivity(intent)
                        finish()
                        Toast.makeText(this@QrScannerActivity, "Request for reclaim post successfully executed", Toast.LENGTH_SHORT).show()
                        Log.d(QRScannerActivityClass, "reclaim post API Success")
                    }
                }

                is NetworkResult.Failed -> {
                    showToast("Request for reclaim post not successfully executed")
                }
            }
        }

        profileViewModel.verifyHandshakeQR.observe(this) { result ->

            when(result) {
                is NetworkResult.Loading -> {

                }

                is NetworkResult.Success -> {
                    tokenManager.saveStatusCode(4)
                    showToast("Request for handshake successfully executed")
                    Log.d(QRScannerActivityClass, "handshake API Success")
                    val intent = Intent(this@QrScannerActivity, DashboardActivity::class.java).apply {
                        putExtra("QR_CODE_SCANNED", true)
                        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                    finish()
                }

                is NetworkResult.Failed -> {
                    showToast("Request for handshake not successfully executed")
                }
            }
        }

        codeScanner.decodeCallback = DecodeCallback {
            runOnUiThread {

                Log.d(QRScannerActivityClass, "Scan Success: ${it.text}")
                val intentData = it.text.split(" ")
                if (intentData.size == 4) {

                    val rightNow: Calendar = Calendar.getInstance()
                    val currentHourIn24Format = rightNow.get(Calendar.HOUR_OF_DAY)
                    val currentMin = rightNow.get(Calendar.MINUTE)
                    val timestamp = intentData[0]
                    val empId = intentData[1]
                    val eventId = intentData[2]

                    val splittedTime = timestamp.split(":")
                    val codeHr = splittedTime[0].toInt()
                    val codeMn = splittedTime[1].toInt()

                    isQRCodeValid = if (currentHourIn24Format >= codeHr) {

                        if (currentHourIn24Format == codeHr) {
                            val diff = (currentMin - codeMn) <= 2 && (currentMin - codeMn) >= 0
                            Log.d("QRScannerAct", " == codeHr $diff")
                            diff


                        } else {
                            val diff = ((60 - codeMn) + currentMin) <= 2 && (currentMin - codeMn) >= 0
                            Log.d("QRScannerAct", " > codeHr $diff")
                            diff
                        }
                    } else {
                        Log.d("QRScannerAct", " < codeHr false")
                        false
                    }





                    tokenManager.saveOtherEmpEventId(eventId)
                    tokenManager.saveOtherEmployeeId(empId)

                    Log.d(QRScannerActivityClass, "Other Emp id" + tokenManager.getOtherEmployeeId())
                    Log.d(QRScannerActivityClass, "Other Event id" + tokenManager.getOtherEmpEventId())

                    if (empId.isNotEmpty() && eventId.isNotEmpty() && isQRCodeValid) {

                        if (intentData[3] == "handshake") {

                            Log.d(QRScannerActivityClass, "QRType: ${intentData[0]}")

                            when(tokenManager.getStatusCode()) {
                                3 -> {

                                    if (tokenManager.getBreakId().isNotEmpty()) {
                                        profileViewModel.reclaimPost(
                                            request = BreakRequest(
                                                event_id = eventId,
                                                employee_id = empId,
                                                break_id = ownBreakId
                                            )
                                        )

                                    } else {

                                        Log.d(QRScannerActivityClass, "CALLED verify handshake qr API")

                                        val shiftStartTime = tokenManager.getShiftStartTime().split(":")
                                        val shiftEndTime = tokenManager.getShiftEndTime().split(":")
                                        val bufferInMin = 30

                                        try {
                                            if (checkShiftTime(shiftStartTime, shiftEndTime, bufferInMin)) {
                                                profileViewModel.verifyHandshakeQR(
                                                    request = HandshakeQRRequest(
                                                        employee_id = tokenManager.getOtherEmployeeId(),
                                                        event_id = tokenManager.getOtherEmpEventId()
                                                    )
                                                )
                                            } else {
                                                showToast("your shift isn't started \n आपका शिफ्ट शुरू नहीं हुआ है।")
                                            }
                                        } catch (e: Exception) {
                                            e.printStackTrace()
                                        }




                                    }

                                }
                                else -> {
                                    showToast("Not Allowed to Handshake: Status not 3")
                                }
                            }

                        } else {
                            Log.d(QRScannerActivityClass, "QRType: ${intentData[2]}")
                            Log.d(QRScannerActivityClass, ownBreakId)
                            if (ownBreakId.isBlank()) {
                                Log.d(QRScannerActivityClass, "breakId is blank")
                                profileViewModel.tempTransferPost(
                                    request = BreakRequest(
                                        event_id = eventId,
                                        employee_id = empId,
                                        break_id = intentData[3]
                                    )
                                )
                            }
                        }

                    } else {
                        showToast("Invalid QR Code")
                    }

                } else {
                    showToast("Invalid QR Code")
                }

            }
        }

        codeScanner.errorCallback = ErrorCallback {
            runOnUiThread {
                showToast("Scan failed: " + it.message)
            }
        }

        binding.codeScannerView.setOnClickListener {
            codeScanner.startPreview()
        }



    }

    override fun onResume() {
        super.onResume()
        codeScanner.startPreview()
    }

    override fun onPause() {
        codeScanner.releaseResources()
        super.onPause()
    }


}