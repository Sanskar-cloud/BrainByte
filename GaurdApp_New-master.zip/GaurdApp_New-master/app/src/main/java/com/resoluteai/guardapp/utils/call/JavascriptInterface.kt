package com.resoluteai.guardapp.utils.call

import android.util.Log
import android.webkit.JavascriptInterface
import com.resoluteai.guardapp.presentation.activity.CallActivity

class JavascriptInterface(private val activity: CallActivity) {
    @JavascriptInterface
    fun onPeerConnected() {
        Log.d("JavascriptInterface", "Onpeerconnected == true")
        activity.onPeerConnected()
    }
}




