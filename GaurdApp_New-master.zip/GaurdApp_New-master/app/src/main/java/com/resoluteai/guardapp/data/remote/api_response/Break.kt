package com.resoluteai.guardapp.data.remote.api_response


import com.google.gson.annotations.SerializedName

data class Break(
    @SerializedName("client_id")
    val clientId: String,
    @SerializedName("created_at")
    val createdAt: String,
    @SerializedName("id")
    val id: String,
    @SerializedName("is_active")
    val isActive: Boolean,
    @SerializedName("is_deleted")
    val isDeleted: Boolean,
    @SerializedName("name")
    val name: String,
    @SerializedName("time")
    val time: String,
    @SerializedName("updated_at")
    val updatedAt: String,
    @SerializedName("need_replacement")
    val needReplacement: Boolean,
    val location_id: String
)