package com.resoluteai.guardapp.broadcast

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class LocationReceiver(private val callback: Callback):  BroadcastReceiver() {

    interface Callback {
        fun onLocationReceived(lat:Double, lng: Double)
    }
    override fun onReceive(context: Context?, intent: Intent?) {
        val lat = intent?.getDoubleExtra("location_lat", 0.0)
        val lng = intent?.getDoubleExtra("location_lng", 0.0)

        if (lat != null && lng != null) {

            if (lat != 0.0 && lng != 0.0) {
                callback.onLocationReceived(lat, lng)
            }
        }
    }
}