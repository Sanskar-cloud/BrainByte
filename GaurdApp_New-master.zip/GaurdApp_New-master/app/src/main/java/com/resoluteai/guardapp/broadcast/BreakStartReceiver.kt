package com.resoluteai.guardapp.broadcast

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BreakStartReceiver(private val callback: Callback): BroadcastReceiver() {

    interface Callback {
        fun onReceiveBreakStartEvent(timer: Int, isBreakActive: Boolean, breakName: String)
    }
    override fun onReceive(context: Context?, intent: Intent?) {
        val timer = intent?.getIntExtra("timer", 0)
        val isBreakActive = intent?.getBooleanExtra("isBreakActive", false)
        val breakName = intent?.getStringExtra("breakName")

        if (timer != null && isBreakActive != null && breakName != null) {
            callback.onReceiveBreakStartEvent(timer, isBreakActive, breakName)
        }
    }
}