package com.resoluteai.guardapp.data.repository_impl

import android.util.Log
import com.google.gson.GsonBuilder
import com.resoluteai.guardapp.data.remote.EmployeeApi
import com.resoluteai.guardapp.data.remote.OTPApi
import com.resoluteai.guardapp.data.remote.api_request.VerifyOtp
import com.resoluteai.guardapp.data.remote.api_response.Detail
import com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer
import com.resoluteai.guardapp.domain.model.auth.DeviceInfo
import com.resoluteai.guardapp.domain.model.auth.updated.NewAuthResponse
import com.resoluteai.guardapp.domain.model.auth.updated.UserInfoClass
import com.resoluteai.guardapp.domain.repository.AuthRepository
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.getDeviceName
import com.resoluteai.guardapp.utils.getMac
import javax.inject.Inject

class AuthRepositoryImpl @Inject constructor(
    private val otpApi: OTPApi,
    private val employeeApi: EmployeeApi
): AuthRepository {
    override suspend fun verifyAssignmentOTP(request: VerifyOtp): NetworkResult<String> {

        return try {
            val response = otpApi.verifyAssignmentOTP(request)
            if (response.isSuccessful) {

                if (response.body()!!.status == true) {
                    NetworkResult.Success(response.body()!!.data!!)
                } else {
                    NetworkResult.Failed(response.body()!!.message)
                }

            } else {

                if (response.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        response.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            Detail::class.java,
                            com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, com.resoluteai.guardapp.data.remote.api_response.Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }
            }
        } catch (e: Exception) {
            Log.d("Auth Repo Exception", "${e.message}")
            NetworkResult.Failed(e.message)
        }
    }

    override suspend fun sendLoginOTP(
        phoneNumber: String,
        macAddress: String
    ): NetworkResult<String> {


        return try {
            val response = employeeApi.requestLoginOTP(
                UserInfoClass(
                    api_key = Constant.API_KEY_REQUEST_OTP,
                    otp = "string",
                    phone_number = phoneNumber,
                    device = DeviceInfo(
                        name = getDeviceName(),
                        uid = macAddress
                    )
                )
            )
            if (response.isSuccessful) {
                if (response.body()!!.status == true) {
                    NetworkResult.Success(response.body()!!.data!!)
                } else {
                    NetworkResult.Failed(response.body()!!.message)
                }

            } else {

                if (response.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        response.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            Detail::class.java,
                            DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, com.resoluteai.guardapp.data.remote.api_response.Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }
            }
        } catch (e: Exception) {
            Log.d("Auth Repo Exception", "${e.message}")
            NetworkResult.Failed(e.message)
        }
    }

    override suspend fun verifyLoginOTP(
        otp: String,
        phoneNumber: String,
        macAddress: String
    ): NetworkResult<NewAuthResponse> {

        return try {
            val response = employeeApi.verifyLoginOTP(
                UserInfoClass(
                    api_key = Constant.API_KEY_REQUEST_OTP,
                    otp = otp,
                    phone_number = phoneNumber,
                    DeviceInfo(
                        name = getDeviceName(),
                        uid = macAddress
                    )
                )
            )
            if (response.isSuccessful) {
                if (response.body()!!.status) {
                    NetworkResult.Success(response.body()!!)
                } else {
                    NetworkResult.Failed(response.body()!!.message)
                }
            } else {

                if (response.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        response.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            Detail::class.java,
                            com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, com.resoluteai.guardapp.data.remote.api_response.Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }
            }
        } catch (e: Exception) {
            NetworkResult.Failed(e.message)
        }
    }
}