package com.resoluteai.guardapp.domain.use_case.alerts

import com.resoluteai.guardapp.domain.repository.AlertRepository
import javax.inject.Inject

class GetAllAlertsUseCase @Inject constructor(
    private val alertRepository: AlertRepository
) {
    suspend operator fun invoke() = alertRepository.getAllAlerts()
}