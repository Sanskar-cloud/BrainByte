package com.resoluteai.guardapp.domain.use_case.attendance

import com.resoluteai.guardapp.data.remote.api_request.break_request.BreakRequest
import com.resoluteai.guardapp.domain.repository.AttendanceRepository
import com.resoluteai.guardapp.utils.NetworkResult
import javax.inject.Inject

class ReclaimPostUseCase @Inject constructor(
    private val attendanceRepository: AttendanceRepository
) {

    suspend operator fun invoke(employeeId: String, eventId: String, requestBody: BreakRequest): NetworkResult<Boolean> =
        attendanceRepository.reclaimPost(employeeId, eventId, requestBody)
}