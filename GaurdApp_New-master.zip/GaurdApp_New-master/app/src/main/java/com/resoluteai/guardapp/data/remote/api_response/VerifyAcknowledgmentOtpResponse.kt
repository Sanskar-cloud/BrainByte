package com.resoluteai.guardapp.data.remote.api_response

data class VerifyAcknowledgmentOtpResponse(
    val status: Boolean,
    val data: String,
    val message: String
)
