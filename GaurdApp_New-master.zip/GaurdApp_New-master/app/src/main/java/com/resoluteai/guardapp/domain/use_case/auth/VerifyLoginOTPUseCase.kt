package com.resoluteai.guardapp.domain.use_case.auth

import com.resoluteai.guardapp.domain.model.auth.updated.NewAuthResponse
import com.resoluteai.guardapp.domain.repository.AuthRepository
import com.resoluteai.guardapp.utils.NetworkResult
import javax.inject.Inject

class VerifyLoginOTPUseCase @Inject constructor(
    private val authRepository: AuthRepository
) {

    suspend operator fun invoke(otp: String, phoneNumber: String, macAddress: String): NetworkResult<com.resoluteai.guardapp.domain.model.auth.updated.NewAuthResponse> =
        authRepository.verifyLoginOTP(otp, phoneNumber, macAddress)
}