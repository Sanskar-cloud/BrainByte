package com.resoluteai.guardapp.presentation.activity

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.IntentSender
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.util.Log
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.navigation.findNavController
import androidx.navigation.ui.setupWithNavController
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.Granularity
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.LocationSettingsRequest
import com.google.android.gms.location.LocationSettingsResponse
import com.google.android.gms.location.Priority
import com.google.android.gms.location.SettingsClient
import com.google.android.gms.tasks.Task
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.gson.Gson
import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.broadcast.BreakEndedBroadcastReceiver
import com.resoluteai.guardapp.broadcast.CallNotifIndicatorBroadcast
import com.resoluteai.guardapp.broadcast.CaptchaReceivedBroadcast
import com.resoluteai.guardapp.broadcast.LocationEnabledBroadcast
import com.resoluteai.guardapp.broadcast.NetworkChangeListener
import com.resoluteai.guardapp.broadcast.NetworkChangeReceiver
import com.resoluteai.guardapp.data.remote.api_response.attendance.Attendance
import com.resoluteai.guardapp.data.remote.api_response.employee.EmployeeN
import com.resoluteai.guardapp.data.remote.api_response.employee.EmployeeNN
import com.resoluteai.guardapp.data.remote.api_response.event.Guard
import com.resoluteai.guardapp.data.remote.api_response.event.Shift
import com.resoluteai.guardapp.databinding.ActivityDashboardBinding
import com.resoluteai.guardapp.domain.model.socket.ShiftEndedConfirmation
import com.resoluteai.guardapp.domain.model.socket.SocketConfiguration
import com.resoluteai.guardapp.domain.use_case.attendance.GetAttendanceUseCase
import com.resoluteai.guardapp.domain.use_case.event.TriggerEscalationUseCase
import com.resoluteai.guardapp.presentation.dialog.BreakTimerDialog
import com.resoluteai.guardapp.presentation.dialog.DutyEndedDialog
import com.resoluteai.guardapp.presentation.dialog.EndBreakDialog
import com.resoluteai.guardapp.presentation.dialog.StartBreakDialog
import com.resoluteai.guardapp.service.AlarmItem
import com.resoluteai.guardapp.service.AndroidAlarmScheduler
import com.resoluteai.guardapp.service.LocationService
import com.resoluteai.guardapp.service.SocketService
import com.resoluteai.guardapp.socket.MySocketHandler
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.Constant.Action_Call_Notification
import com.resoluteai.guardapp.utils.Constant.Action_Captcha_Verification
import com.resoluteai.guardapp.utils.Constant.BREAK_TIMER_NOTIFICATION_ID
import com.resoluteai.guardapp.utils.Constant.DashboardActivityClass
import com.resoluteai.guardapp.utils.Constant.Get_Attendance_Listener_Id
import com.resoluteai.guardapp.utils.Constant.Get_Device_LoggedIn_Listener_Id
import com.resoluteai.guardapp.utils.Constant.RECEIVE_CAPTCHA_NOTIFICATION_ID
import com.resoluteai.guardapp.utils.Constant.hasGuardEnteredCaptcha
import com.resoluteai.guardapp.utils.Constant.isBreakOnInApp
import com.resoluteai.guardapp.utils.Constant.isEscalationTimerRunning
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.TokenManager
import com.resoluteai.guardapp.utils.getDeviceId
import com.resoluteai.guardapp.utils.hasRequiredPermissions
import com.resoluteai.guardapp.utils.isServiceRunning
import com.resoluteai.guardapp.utils.logout
import com.resoluteai.guardapp.utils.showToast
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.util.*
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@AndroidEntryPoint
class DashboardActivity : AppCompatActivity(),
    StartBreakDialog.StartBreakDialogListener,
    EndBreakDialog.EndBreakDialogListener,
    BreakTimerDialog.BreakTimerDialogListener,
    NetworkChangeListener{



    private lateinit var binding: ActivityDashboardBinding
    private lateinit var networkChangeReceiver: NetworkChangeReceiver
    private var noInternetDialog: AlertDialog? = null


    @Inject
    lateinit var tokenManager: TokenManager
    @Inject
    lateinit var triggerEscalationUC: TriggerEscalationUseCase
    @Inject
    lateinit var getAttendanceUC: GetAttendanceUseCase

    private lateinit var locationManager: LocationManager
    private lateinit var notificationManager: NotificationManager
    private lateinit var breakTimerDialog: BreakTimerDialog
    private lateinit var escalationTimer: CountDownTimer
    private lateinit var endShiftTimer: CountDownTimer



    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    @SuppressLint("MissingPermission")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)



        if (!hasRequiredPermissions(REQUIRED_PERMISSIONS)) {
            ActivityCompat.requestPermissions(
                this, REQUIRED_PERMISSIONS, 0
            )
        }

        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        Log.d(DashboardActivityClass, "Activity LOCATION SERVICE:${isServiceRunning(LocationService::class.java)}")

        if (!isServiceRunning(LocationService::class.java)) {
            //Initialize Location Service
            Intent(this, LocationService::class.java).apply {
                action = LocationService.ACTION_START
                startForegroundService(this)
                Log.d("Activity LOCATION SERVICE", "service started")
            }
        } else {
            Log.d(DashboardActivityClass, "Service is Running")

        }

        if(!isServiceRunning(SocketService::class.java)) {
            //Initialize Alert Service
            Intent(this, SocketService::class.java).apply {
                action = SocketService.ACTION_START
                startForegroundService(this)
                Log.d("Dashboard Socket SERVICE", "service started")
            }
        }

        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        networkChangeReceiver = NetworkChangeReceiver(this)
        registerReceiver(networkChangeReceiver, IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"))





        if (!isBreakOnInApp) {
            notificationManager.cancel(BREAK_TIMER_NOTIFICATION_ID)
        } else {
            breakTimerDialog = BreakTimerDialog()
            breakTimerDialog.show(supportFragmentManager, BreakTimerDialog.TAG)
        }

        if (!hasGuardEnteredCaptcha) {
            captchaDialogShow()
        } else {
            notificationManager.cancel(RECEIVE_CAPTCHA_NOTIFICATION_ID)
        }

        checkGPSEnabled()

        val scheduler = AndroidAlarmScheduler(this, isDutyEndAlarm = true)
        var alarmItem: AlarmItem?


        var converted_time_h = 0
        var converted_time_m = 0
        try {
            val time = tokenManager.getShiftEndTime()
            if (time.isNotBlank()) {
                val list = time.split(":")
                converted_time_h = list[0].toInt()
                converted_time_m = list[1].toInt()

                Log.d("AndroidAlarmSchedular Dashboard", "time end time: ${time}")
                Log.d("AndroidAlarmSchedular Dashboard", "converted_h: ${converted_time_h}")
                Log.d("AndroidAlarmSchedular Dashboard", "converted_m: ${converted_time_m}")
            } else {

            }

        } catch (e: Exception) {
            println("${e.message}")
        }.also {


            if (converted_time_h == 0)
            {
                if (converted_time_m == 0) {

                    val hour = LocalDateTime.now().hour
                    val min = LocalDateTime.now().minute
                    val netCurrentMin = ((hour*60) + min)

                    Log.d("AndroidAlarmSchedular Dashboard", "netCurrentMin: ${netCurrentMin}")
                    val netMin = (24*60) - netCurrentMin

                    val calendar = Calendar.getInstance()
                    calendar[Calendar.HOUR_OF_DAY] = 24
                    calendar[Calendar.MINUTE] = 0
                    calendar[Calendar.SECOND] = 0


                    Log.d("AndroidAlarmSchedular Dashboard", "converted_time_h: ${converted_time_h}")
                    Log.d("AndroidAlarmSchedular Dashboard", "converted_time_m: ${converted_time_m}")
                    Log.d("AndroidAlarmSchedular Dashboard", "data: ${netMin}")

                    alarmItem = AlarmItem(
                        time = calendar,
                        message = "duty time ended"
                    )
                    alarmItem?.let {
                        scheduler.schedule(it)
                    }
                }
            } else {


                val hour = LocalDateTime.now().hour
                val min = LocalDateTime.now().minute

                val netMin = ((hour*60) + min) -((converted_time_h*60) + (converted_time_m))

                Log.d("AndroidAlarmSchedular Dashboard", "converted_time_h: ${converted_time_h}")
                Log.d("AndroidAlarmSchedular Dashboard", "converted_time_m: ${converted_time_m}")
                Log.d("AndroidAlarmSchedular Dashboard", "data: ${netMin}")

                if (converted_time_h < hour) {

                    val calendar = Calendar.getInstance()
                    calendar.add(Calendar.DAY_OF_MONTH, 1)
                    calendar[Calendar.HOUR_OF_DAY] = converted_time_h
                    calendar[Calendar.MINUTE] = converted_time_m
                    calendar[Calendar.SECOND] = 0

                    alarmItem = AlarmItem(
                        time = calendar,
                        message = "duty time ended"
                    )
                    alarmItem?.let {
                        scheduler.schedule(it)
                    }

                } else {
                    val calendar = Calendar.getInstance()
                    calendar[Calendar.HOUR_OF_DAY] = converted_time_h
                    calendar[Calendar.MINUTE] = converted_time_m
                    calendar[Calendar.SECOND] = 0

                    alarmItem = AlarmItem(
                        time = calendar,
                        message = "duty time ended"
                    )
                    alarmItem?.let {
                        scheduler.schedule(it)
                    }
                }


            }

        }





        LocalBroadcastManager.getInstance(this).registerReceiver(
            CallNotifIndicatorBroadcast(
                object : CallNotifIndicatorBroadcast.Callback {
                    override fun onCallNotificationReceived(callerName: String) {
                        //show call notification
//                        binding.alertNotification.visibility =View.VISIBLE
//                        binding.alertTextMessage.text = "Call from Operator"
                        //show fullscreen
                        val fullScreenIntent = Intent(this@DashboardActivity, FullScreenCallNotificationActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        }
                        fullScreenIntent.putExtra("caller_name", callerName)
                    }

                    override fun onCallEnded() {
//                        binding.alertTextMessage.text = "Call is not available"
//                        binding.alertNotification.visibility =View.GONE

                    }
                }
            ),
            IntentFilter(Action_Call_Notification)
        )


        registerReceiver(
            LocationEnabledBroadcast(object : LocationEnabledBroadcast.LocationCallBack {
                override fun turnedOn() {
                    Log.d(Constant.OnLocationOTP, "location is turenedOn")
                }

                override fun turnedOff() {
                    Log.d(Constant.OnLocationOTP, "location is turenedOff")
                    turnOnGPS()

                }

            }),
            IntentFilter(LocationManager.MODE_CHANGED_ACTION)
        )



        if (MySocketHandler.employeeId == null || MySocketHandler.eventId == null || MySocketHandler.clientId == null) {
            MySocketHandler.setData(
                SocketConfiguration(
                    employeeId = tokenManager.getEmployeeID(),
                    eventId = tokenManager.getEventID(),
                    clientId = tokenManager.getSomeImportantClientID()
                )
            )
        }

        if (MySocketHandler.getSocket() == null) {
            MySocketHandler.setSocket(
                tokenManager.getEventID(),
                tokenManager.getEmployeeID(),
                tokenManager.getSomeImportantClientID()
            )
            MySocketHandler.establishConnection()
        }

        val socket = MySocketHandler.getSocket()

        socket?.on(Get_Attendance_Listener_Id) { args ->
            try {
                if (args[0] != null) {
                    val json = args[0].toString()
                    Log.d(DashboardActivityClass, "Attendance Listener: $json")
                    try {

                        val attendance = Gson().fromJson(json, Array<Attendance>::class.java)
                        Log.d(DashboardActivityClass, "Attendance ${attendance[0]}")

                        if (attendance[0].extended_duty) {
                            //update shift end timer
                            val extendTime = attendance[0].extended_time
                            val regex = "(\\d+)h(\\d+)m".toRegex()
                            Log.d(DashboardActivityClass, "Duty has been Extended")

                            val matchResult = regex.find(extendTime)
                            if (matchResult != null) {
                                val (hoursStr, minutesStr) = matchResult.destructured
                                val hours = hoursStr.toInt()
                                val minutes = minutesStr.toInt()

                                //show notification on dashboard
                                binding.alertNotification.visibility = View.VISIBLE
                                binding.alertTextMessage.text = "your duty has been extended to ${tokenManager.getShiftEndTime()}"

                                Log.d(DashboardActivityClass, "Duty has been Extended: Hours: $hours: $minutes")

                                println("Hours: $hours")
                                println("Minutes: $minutes")
                            } else {
                                println("Invalid input format")
                            }

                        }

                        tokenManager.saveStatusCode(attendance[0].status)

                        val attendanceUpdateIndent = Intent("attendance-listener")
                        attendanceUpdateIndent.putExtra("attendance-data", json)
                        LocalBroadcastManager.getInstance(this).sendBroadcast(attendanceUpdateIndent)
                        Log.d(DashboardActivityClass, "Attendance Listener Successfully Added: $attendance")
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

        }

        socket?.on(Get_Device_LoggedIn_Listener_Id) { args ->

            try {
                if (args[0] != null) {
                    val json = args[0].toString()
                    Log.d(DashboardActivityClass, "Device LoggedIn Listener $json")

                    try {
                        val employee = Gson().fromJson(json, Array<EmployeeNN>::class.java)
                        if (employee[0].device.uid != getDeviceId(this)) {
                            lifecycleScope.launch {
                                showToast("you've been logged out \n आपको लॉग आउट कर दिया गया है")
                                tokenManager.clearData()
                                logout()

                                if (isServiceRunning(LocationService::class.java)) {
                                    //stop Location Service
                                    Intent(this@DashboardActivity, LocationService::class.java).apply {
                                        action = LocationService.ACTION_STOP
                                        startForegroundService(this)
                                        Log.d("Activity LOCATION SERVICE", "location service stopped")
                                    }
                                } else {
                                    Log.d(DashboardActivityClass, "Service is Running")

                                }

                                if(isServiceRunning(SocketService::class.java)) {
                                    //stop Alert Service
                                    Intent(this@DashboardActivity, SocketService::class.java).apply {
                                        action = SocketService.ACTION_STOP
                                        startForegroundService(this)
                                        Log.d("Dashboard Socket SERVICE", "alert service stopped")
                                    }
                                }
                                startActivity(Intent(this@DashboardActivity, AuthActivity:: class.java))
                                finish()
                            }

                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        Log.d(DashboardActivityClass, "Error LoggedIn Got ${e.message}")
                    }



                }
            } catch (e: Exception) {
                //e.printStackTrace()
            }
        }

        LocalBroadcastManager.getInstance(this).registerReceiver(
            CaptchaReceivedBroadcast(object : CaptchaReceivedBroadcast.Callback {
                override fun onCaptchaReceived() {
                    captchaDialogShow()
                }
            }),
            IntentFilter(Action_Captcha_Verification)
        )


        LocalBroadcastManager.getInstance(this).registerReceiver(
            BreakEndedBroadcastReceiver(
                object : BreakEndedBroadcastReceiver.DutyEndedListener {
                    override fun dutyEnded() {

                        escalationTimer = object : CountDownTimer(30000L, 1000L) {


                            override fun onTick(millisUntilFinished: Long) {
                                isEscalationTimerRunning = true
                                val minutes = TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished)
                                val seconds = TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) - TimeUnit.MINUTES.toSeconds(minutes)
                                Log.d(DashboardActivityClass, "Escalation Time in min: ${minutes}:${seconds} ")
                                val escalationNotification = createTimerNotification("Escalation", "Escalation Timer: ${minutes}:${seconds} Left")
                                notificationManager.notify(Constant.ESCALATION_TIMER_NOTIFICATION_ID, escalationNotification)

                                if (tokenManager.getStatusCode() == 3) {
                                    escalationTimer.cancel()
                                }
                            }

                            override fun onFinish() {
                                isEscalationTimerRunning = false

                                binding.alertNotification.visibility = View.GONE

                                Log.d(Constant.TAG_LOCATION_SERVICE, "Escalation Timer is finished")
                                notificationManager.cancel(Constant.ESCALATION_TIMER_NOTIFICATION_ID)

                                if (socket?.connected() == true) {
                                    MySocketHandler.sendDutyEndedConfirmation(
                                        ShiftEndedConfirmation(
                                            employee_id = tokenManager.getEmployeeID(),
                                            event_id = tokenManager.getEventID(),
                                            post_id = tokenManager.getSomePostId(),
                                            guard_name = tokenManager.getProfileName(),
                                            shift = Shift(
                                                startTime = tokenManager.getShiftStartTime(),
                                                endTime = tokenManager.getShiftEndTime()
                                            ),
                                            status = tokenManager.getStatusCode()
                                        )
                                    )
                                } else {
                                    socket?.connect()
                                    MySocketHandler.sendDutyEndedConfirmation(
                                        ShiftEndedConfirmation(
                                            employee_id = tokenManager.getEmployeeID(),
                                            event_id = tokenManager.getEventID(),
                                            post_id = tokenManager.getSomePostId(),
                                            guard_name = tokenManager.getProfileName(),
                                            shift = Shift(
                                                startTime = tokenManager.getShiftStartTime(),
                                                endTime = tokenManager.getShiftEndTime()
                                            ),
                                            status = tokenManager.getStatusCode()
                                        )
                                    )
                                }


                                endShiftTimer = object : CountDownTimer(120000L, 5000L) {
                                    override fun onTick(millisUntilFinished: Long) {
                                        if (tokenManager.getStatusCode() == 3) {
                                            endShiftTimer.cancel()
                                        }


                                    }

                                    override fun onFinish() {
                                        if (tokenManager.getStatusCode() != 3) {
                                            lifecycleScope.launch {

                                                val attendancefetched = getAttendanceUC(tokenManager.getEmployeeID(), tokenManager.getEventID())

                                                when(attendancefetched) {
                                                    is NetworkResult.Success -> {
                                                        attendancefetched.data?.status?.let {
                                                            tokenManager.saveStatusCode(it)
                                                        }

                                                        val dialog = DutyEndedDialog()
                                                        try {
                                                            dialog.show(supportFragmentManager, DutyEndedDialog.TAG)
                                                        } catch (e: Exception) {
                                                            e.printStackTrace()
                                                        }

                                                        Log.d(DashboardActivityClass, "Attendance Response Got")
                                                    }

                                                    is NetworkResult.Failed -> {
                                                        Log.d(DashboardActivityClass, "Attendance Response Failed")
                                                    }

                                                    is NetworkResult.Loading -> {

                                                    }
                                                }

                                                val result = triggerEscalationUC(tokenManager.getEventID())

                                                when(result) {
                                                    is NetworkResult.Success -> {
                                                        Log.d(DashboardActivityClass, "Escalation Mail has been sent")
                                                    }

                                                    is NetworkResult.Failed -> {
                                                        Log.d(DashboardActivityClass, "Escalation Mail has not been sent")
                                                    }

                                                    is NetworkResult.Loading -> {

                                                    }
                                                }

                                            }
                                        }
                                    }

                                }

                                endShiftTimer.start()


                            }

                        }

                        if (tokenManager.getShiftExtensionHr() != 0 || tokenManager.getShiftExtensionMn() != 0) {
                            val oldShiftEndTime = tokenManager.getShiftEndTime().split(":")
                            val shiftEndTimeHr = oldShiftEndTime[0].toInt()
                            val shiftEndTimeMn = oldShiftEndTime[1].toInt()
                            val newShiftEndTimeHr = shiftEndTimeHr + tokenManager.getShiftExtensionHr()
                            val newShiftEndTimeMn = shiftEndTimeMn + tokenManager.getShiftExtensionMn()

                            binding.alertNotification.visibility = View.VISIBLE
                            binding.alertTextMessage.text = "your duty is extended $newShiftEndTimeHr:$newShiftEndTimeMn"
                            tokenManager.saveShiftEndTime("$newShiftEndTimeHr:$newShiftEndTimeMn")

                            Log.d("TAG_Dashboard", tokenManager.getShiftEndTime())
                        } else if (tokenManager.getShiftExtensionHr() == 0 && tokenManager.getShiftExtensionMn() == 0) {
                            binding.alertNotification.visibility = View.GONE
                            binding.alertTextMessage.text = ""
                            escalationTimer.start()
                        }





                    }

                    override fun breakEnded() {
                        Log.d(DashboardActivityClass, "break ended called")
                    }

                }
            ),
            IntentFilter("updateUIBreakEnd")

        )





        val window: Window = this.window
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
        }
        window.statusBarColor = ContextCompat.getColor(this, R.color.statusBar)


        val navController = this.findNavController(R.id.nav_host_fragment)
        val navView: BottomNavigationView = findViewById(R.id.bottom_nav_view)
        navView.setupWithNavController(navController)



    }

    fun hideBottomNavBar() {
        Log.d(DashboardActivityClass, "hideBottomNavBar Called")
        binding.bottomNavView.animate().translationY(binding.bottomNavView.height.toFloat())
        binding.bottomNavView.visibility = View.GONE

    }

    fun showBottomNavBar() {
        Log.d(DashboardActivityClass, "showbottomNavBar Called")
        binding.bottomNavView.visibility = View.VISIBLE
        binding.bottomNavView.animate().translationY(0f)

    }



    override fun onDestroy() {


        super.onDestroy()
        Log.d(DashboardActivityClass, "on destroy called")
        unregisterReceiver(networkChangeReceiver)

    }



    private fun captchaDialogShow() {
        lifecycleScope.launch {
            val dialogView = layoutInflater.inflate(R.layout.screen_lock_alert, null)
            val captchaTxt = dialogView.findViewById<TextView>(R.id.captcha)
            val button = dialogView.findViewById<Button>(R.id.btn)
            val captchaEdt = dialogView.findViewById<EditText>(R.id.captcha_edt)
            val refreshBtn=  dialogView.findViewById<ImageView>(R.id.refresBtn)
            var captcha = generateCaptcha()
            captchaTxt.text = captcha
            val dialogBuilder = AlertDialog.Builder(this@DashboardActivity)
                .setView(dialogView)
            val alertDialog = dialogBuilder.create()
            alertDialog.setCancelable(false)
            alertDialog.show()
            refreshBtn.setOnClickListener {
                captcha = generateCaptcha()
                captchaTxt.text = captcha
            }
            button.setOnClickListener {
                if (captchaEdt.text.toString() == captcha) {
                    Constant.hasGuardEnteredCaptcha = true
                    notificationManager.cancel(RECEIVE_CAPTCHA_NOTIFICATION_ID)
                    alertDialog.dismiss()
                    MySocketHandler.sendCaptchaResponse(
                        com.resoluteai.guardapp.domain.model.socket.CaptchaResponse(
                            employeeId = tokenManager.getEmployeeID(),
                            eventId = tokenManager.getEventID()
                        )
                    )


                } else {
                    captchaEdt.text.clear()
                    Toast.makeText(this@DashboardActivity, "Please enter right code", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }



    private fun generateCaptcha(): String {
        val chars = "ABCDEFGHJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz0123456789"
        val random = Random()
        val sb = StringBuilder()
        for (i in 0 until 6) {
            sb.append(chars[random.nextInt(chars.length)])
        }
        return sb.toString()
    }

    private fun turnOnGPS() {
//        val request = LocationRequest.create().apply {
//            interval = 1000
//            priority = LocationRequest.PRIORITY_HIGH_ACCURACY
//        }
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 300000).apply {
            setMinUpdateDistanceMeters(5f)
            setGranularity(Granularity.GRANULARITY_PERMISSION_LEVEL)
            setWaitForAccurateLocation(true)
        }.build()

        val builder = LocationSettingsRequest.Builder().addLocationRequest(request)
        val client: SettingsClient = LocationServices.getSettingsClient(this)
        val task: Task<LocationSettingsResponse> = client.checkLocationSettings(builder.build())
        task.addOnFailureListener {
            if (it is ResolvableApiException) {
                try {
                    it.startResolutionForResult(this, 12345)
                } catch (sendEx: IntentSender.SendIntentException) {
                }
            }
        }.addOnSuccessListener {
            //here GPS is On
        }
    }

    private fun checkGPSEnabled() {
        val manager = this.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (manager.isProviderEnabled(LocationManager.GPS_PROVIDER).not()) {
            turnOnGPS()
        }
    }


    override fun onStartButtonClick(dialog: StartBreakDialog, breakName: String) {
        dialog.dismiss()



        val breakTimerInMin = tokenManager.getBreakTimer()

        val hour = LocalDateTime.now().hour
        val min = LocalDateTime.now().minute
        val netCurrentMin = ((hour*60) + min) + breakTimerInMin

        val hours = netCurrentMin/60
        val minN = netCurrentMin % 60


        val calendar = Calendar.getInstance()
        calendar[Calendar.HOUR_OF_DAY] = hours
        calendar[Calendar.MINUTE] = minN
        calendar[Calendar.SECOND] = 0

        val scheduler = AndroidAlarmScheduler(this, isBreakEndAlarm = true)
        val alarmItemBreak = AlarmItem(
            time = calendar,
            message = "alarmItem has been created"
        )
        scheduler.schedule(alarmItemBreak)

        //Show BreakTimer Dialog
        val args = Bundle()
        args.putString("break_name", breakName)
        breakTimerDialog = BreakTimerDialog()
        breakTimerDialog.arguments = args
        isBreakOnInApp = true
        tokenManager.saveBreakNeedReplacement(false)

        breakTimerDialog.show(supportFragmentManager, BreakTimerDialog.TAG)
    }

    override fun onEndBreakButtonClick(dialog: EndBreakDialog) {
        tokenManager.saveBreakTimer(0)
        breakTimerDialog.dismiss()
        dialog.dismiss()
    }

    override fun onEndButtonClick(dialog: BreakTimerDialog) {
        breakTimerDialog = dialog
        val endBreakDialog = EndBreakDialog()
        endBreakDialog.show(supportFragmentManager, EndBreakDialog.TAG)
    }

    override fun onQRScannerClick(dialog: BreakTimerDialog) {
        breakTimerDialog = dialog
        val intent = Intent(this, QrScannerActivity::class.java)
        startActivity(intent)
    }

    fun createTimerNotification(timerName: String, contentText:String): Notification {
        return NotificationCompat.Builder(this, Constant.TIMER_CHANNEL_ID)
            .setContentTitle("$timerName Timer: Guard App")
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_launcher_background)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationManager.IMPORTANCE_HIGH)
            .build()
    }


    companion object {
        private val REQUIRED_PERMISSIONS = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.POST_NOTIFICATIONS
        )
    }

    override fun onNetworkChanged(isConnected: Boolean) {
        if (!isConnected) {
            showNoInternetDialog()
        } else {
            dismissNoInternetDialog()
        }
    }


    private fun showNoInternetDialog() {
        if (noInternetDialog == null) {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("No Internet Connection")
                .setMessage("Please check your internet connection and try again.")
                .setCancelable(false)

            noInternetDialog = builder.create()
            noInternetDialog?.show()
        }
    }

    private fun dismissNoInternetDialog() {
        noInternetDialog?.dismiss()
        noInternetDialog = null
    }


}


