package com.resoluteai.guardapp.presentation.dialog

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.data.remote.api_request.attendance.UpdateAttendanceRequest
import com.resoluteai.guardapp.domain.use_case.attendance.UpdateAttendanceUseCase
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.Constant.isBreakOnInApp
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.TokenManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.util.Calendar
import javax.inject.Inject

@AndroidEntryPoint
class StartBreakDialog: DialogFragment() {

    private lateinit var listener: StartBreakDialogListener

    interface StartBreakDialogListener {
        fun onStartButtonClick(dialog: StartBreakDialog, breakName: String)
    }

    @Inject
    lateinit var tokenManager: TokenManager
    @Inject
    lateinit var updateAttendanceUC: UpdateAttendanceUseCase


    override fun onAttach(context: Context) {
        super.onAttach(context)

        try {
            // Instantiate the NoticeDialogListener so we can send events to the host
            listener = context as StartBreakDialogListener
        } catch (e: ClassCastException) {
            // The activity doesn't implement the interface, throw exception
            throw ClassCastException((context.toString() +
                    " must implement NoticeDialogListener"))
        }

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val startBreakView = inflater.inflate(R.layout.dialog_start_a_break, container, false)
        dialog?.window?.setBackgroundDrawableResource(R.drawable.card_rounded_desgin)

        startBreakView.findViewById<Button>(R.id.cancelBtn).setOnClickListener {
            dismiss()
        }



        val argBreakTimer = arguments?.getInt("clicked_break_time_in_min")
        val argBreakName = arguments?.getString("break_name")
        val argBreakId = arguments?.getString("argBreakId")


        startBreakView.findViewById<Button>(R.id.startBtn).setOnClickListener {
            //start Break
            if (argBreakTimer != null && argBreakName != null && argBreakId != null) {
                updateAttendance(
                    tokenManager.getEmployeeID(),
                    tokenManager.getEventID(),
                    argBreakName,
                    argBreakId
                )

            }

        }

        isCancelable = true

        return startBreakView
    }

    companion object {
        const val TAG = "StartBreak"
    }

    private fun updateAttendance(empId: String, eventId: String, breakName: String, breakId: String) {
        viewLifecycleOwner.lifecycleScope.launch {
            val rightNow: Calendar = Calendar.getInstance()
            val currentHourIn24Format = rightNow.get(Calendar.HOUR_OF_DAY).toString()
            val currentMin = rightNow.get(Calendar.MINUTE).toString()
            val result = updateAttendanceUC(
                UpdateAttendanceRequest(
                    employee_id = empId,
                    event_id = eventId,
                    break_id = breakId,
                    status = 3,
                    log = "Break $breakName started at ${currentHourIn24Format}:${currentMin}"
                )
            )

            when(result) {

                is NetworkResult.Loading -> {

                }
                is NetworkResult.Success -> {

                    Log.d("Start Break Dialog", "save status code ${result.data?.status}")

                    val argBreakTimer = arguments?.getInt("clicked_break_time_in_min")
                    val argBreakName = arguments?.getString("break_name")
                    val argBreakId = arguments?.getString("argBreakId")
                    Log.d("Start Break Dialog", "Break: $argBreakTimer, $argBreakName, $argBreakId")

                    if (argBreakId != null) {
                        tokenManager.saveBreakId(argBreakId)
                    }
                    if (argBreakName != null) {
                        tokenManager.saveCurrentBreakName(argBreakName)
                    }
                    result.data?.let {

                        //Notify LocationService to Start Timer
                        val intent = Intent("Send_Break_Start_Event")
                        intent.putExtra("timer",argBreakTimer)
                        intent.putExtra("isBreakActive", true)
                        intent.putExtra("breakName", argBreakName)
                        LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(intent)



                        Log.d("StartBreakTIMER---dialog", "${tokenManager.getBreakNeedReplacement()}")

                        listener.onStartButtonClick(this@StartBreakDialog, breakName)

                    }

                }
                is NetworkResult.Failed -> {

                }
            }
        }

    }


}

