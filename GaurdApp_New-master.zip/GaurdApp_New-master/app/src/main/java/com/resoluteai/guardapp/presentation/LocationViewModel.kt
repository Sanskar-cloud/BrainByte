package com.resoluteai.guardapp.presentation

import android.annotation.SuppressLint
import android.app.Application
import android.location.Location
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.resoluteai.guardapp.utils.LocationClient
import com.resoluteai.guardapp.utils.SingleLiveData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

class LocationViewModel(application: Application) : AndroidViewModel(application) {

    private val fusedLocationClient: FusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(application)

    @SuppressLint("MissingPermission")
    fun getLastKnownLocation(): LiveData<Location?> {
        val lastLocationLiveData = SingleLiveData<Location?>() // Implement SingleLiveData as shown below
        fusedLocationClient.lastLocation
            .addOnSuccessListener { location: Location? ->
                lastLocationLiveData.postValue(location)
            }
            .addOnFailureListener { /* Handle failure here */ }
        return lastLocationLiveData
    }
}