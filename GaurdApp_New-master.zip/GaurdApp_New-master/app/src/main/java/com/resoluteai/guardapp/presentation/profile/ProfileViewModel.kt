package com.resoluteai.guardapp.presentation.profile

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.resoluteai.guardapp.data.remote.api_response.attendance.Attendance
import com.resoluteai.guardapp.domain.use_case.attendance.GetAttendanceUseCase
import com.resoluteai.guardapp.domain.use_case.attendance.ReclaimPostUseCase
import com.resoluteai.guardapp.domain.use_case.attendance.TemporaryTransferPostUseCase
import com.resoluteai.guardapp.domain.use_case.attendance.VerifyHandshakeQRUseCase
import com.resoluteai.guardapp.utils.NetworkResult
import com.resoluteai.guardapp.utils.TokenManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val temporaryTransferPostUC: TemporaryTransferPostUseCase,
    private val reclaimPostUC: ReclaimPostUseCase,
    private val verifyHandshakeQRUC: VerifyHandshakeQRUseCase,
    private val getAttendanceUC: GetAttendanceUseCase,
    private val tokenManager: TokenManager
): ViewModel() {

    private val _getAttendance = MutableLiveData<NetworkResult<Attendance>>()
    val getAttendance: LiveData<NetworkResult<Attendance>>
        get() = _getAttendance

    private val _tempTransferPost = MutableLiveData<NetworkResult<Boolean>>()
    val tempTransferPost: LiveData<NetworkResult<Boolean>>
        get() = _tempTransferPost

    private val _reclaimPost = MutableLiveData<NetworkResult<Boolean>>()
    val reclaimPost: LiveData<NetworkResult<Boolean>>
        get() = _reclaimPost

    private val _verifyHandshakeQR = MutableLiveData<NetworkResult<Boolean>>()
    val verifyHandshakeQR: LiveData<NetworkResult<Boolean>>
        get() = _verifyHandshakeQR


    fun tempTransferPost(
        request: com.resoluteai.guardapp.data.remote.api_request.break_request.BreakRequest
    ) {
        viewModelScope.launch {
           val result = temporaryTransferPostUC(
               employeeId = tokenManager.getEmployeeID(),
               eventId = tokenManager.getEventID(),
               requestBody = request
           )

            when (result) {

                is NetworkResult.Loading -> {
                    _tempTransferPost.postValue(NetworkResult.Loading())
                }

                is NetworkResult.Success -> {
                    _tempTransferPost.postValue(NetworkResult.Success(result.data!!))
                }

                is NetworkResult.Failed -> {
                    _tempTransferPost.postValue(NetworkResult.Failed(result.message))
                }
            }
        }
    }

    fun reclaimPost(
        request: com.resoluteai.guardapp.data.remote.api_request.break_request.BreakRequest
    ) {
        viewModelScope.launch {
            val result = reclaimPostUC(
                employeeId = tokenManager.getEmployeeID(),
                eventId = tokenManager.getEventID(),
                requestBody = request
            )

            when (result) {

                is NetworkResult.Loading -> {
                    _reclaimPost.postValue(NetworkResult.Loading())
                }

                is NetworkResult.Success -> {
                    _reclaimPost.postValue(NetworkResult.Success(result.data!!))
                }

                is NetworkResult.Failed -> {
                    _reclaimPost.postValue(NetworkResult.Failed(result.message))
                }
            }
        }
    }

    fun verifyHandshakeQR(request: com.resoluteai.guardapp.data.remote.api_request.attendance.HandshakeQRRequest) {
        viewModelScope.launch {
            val result = verifyHandshakeQRUC(
                employeeId = tokenManager.getEmployeeID(),
                eventId = tokenManager.getEventID(),
                requestBody = request
            )

            when (result) {

                is NetworkResult.Loading -> {
                    _verifyHandshakeQR.postValue(NetworkResult.Loading())
                }

                is NetworkResult.Success -> {
                    _verifyHandshakeQR.postValue(NetworkResult.Success(result.data!!))
                }

                is NetworkResult.Failed -> {
                    _verifyHandshakeQR.postValue(NetworkResult.Failed(result.message))
                }
            }
        }
    }


    fun getAttendance() {
        viewModelScope.launch {
            val result = getAttendanceUC(
                employeeId = tokenManager.getEmployeeID(),
                eventId = tokenManager.getEventID()
            )

            when (result) {

                is NetworkResult.Loading -> {
                    _getAttendance.postValue(NetworkResult.Loading())
                }

                is NetworkResult.Success -> {
                    _getAttendance.postValue(NetworkResult.Success(result.data!!))
                }

                is NetworkResult.Failed -> {
                    _getAttendance.postValue(NetworkResult.Failed(result.message))
                }
            }
        }
    }
}