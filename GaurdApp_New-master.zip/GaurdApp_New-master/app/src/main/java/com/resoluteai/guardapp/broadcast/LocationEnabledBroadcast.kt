package com.resoluteai.guardapp.broadcast

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Context.LOCATION_SERVICE
import android.content.Intent
import android.location.LocationManager
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi


class LocationEnabledBroadcast(private val locationCallBack: LocationCallBack) :
    BroadcastReceiver() {
    interface LocationCallBack {
        fun turnedOn()
        fun turnedOff()
    }

    @RequiresApi(Build.VERSION_CODES.P)
    override fun onReceive(context: Context, intent: Intent) {
        val locationManager = context.getSystemService(LOCATION_SERVICE) as LocationManager

        //not for android 7
        val isEnabled: Boolean =
            locationManager.isLocationEnabled
        if (isEnabled) {
            Log.d("BroadCast", "GPS TURNED ON")
            locationCallBack.turnedOn()
        } else {
            Log.d("BroadCast", "GPS TURNED OFF")
            locationCallBack.turnedOff()
        }
    }

}