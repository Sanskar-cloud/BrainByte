package com.resoluteai.guardapp.data.repository_impl

import android.util.Log
import com.google.gson.GsonBuilder
import com.resoluteai.guardapp.data.remote.AttendanceApi
import com.resoluteai.guardapp.data.remote.OTPApi
import com.resoluteai.guardapp.data.remote.api_request.SendGeofenceOTPRequest
import com.resoluteai.guardapp.data.remote.api_request.VerifyOtp
import com.resoluteai.guardapp.domain.repository.OTPRepository
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.NetworkResult
import javax.inject.Inject

class OTPRepositoryImpl @Inject constructor(
    private val otpApi: OTPApi,
    private val attendanceApi: AttendanceApi
): OTPRepository {
    override suspend fun sendOtpFromGeofence(requestBody: SendGeofenceOTPRequest): NetworkResult<String> {
        return try {
            val result = otpApi.sendOtpFromGeofence(
                requestBody
            )

            if (result.isSuccessful) {
                if (result.body()!!.status == true) {
                    NetworkResult.Success(result.body()!!.data!!.message)
                } else {
                    NetworkResult.Failed(result.body()!!.message)
                }

            } else {
                if (result.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        result.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            com.resoluteai.guardapp.data.remote.api_response.Detail::class.java,
                            com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, com.resoluteai.guardapp.data.remote.api_response.Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, com.resoluteai.guardapp.data.remote.api_response.Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }
            }
        } catch (e: Exception) {
            NetworkResult.Failed(e.message)
        }
    }

    override suspend fun updateStatusOnLocation(requestBody: SendGeofenceOTPRequest): NetworkResult<String> {
        return try {
            val result = attendanceApi.updateStatusOnLocation(
                requestBody
            )

            if (result.isSuccessful) {
                if (result.body()!!.status == true) {
                    NetworkResult.Success(result.body()!!.data!!.message)
                } else {
                    NetworkResult.Failed(result.body()!!.message)
                }
            } else {
                if (result.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        result.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            com.resoluteai.guardapp.data.remote.api_response.Detail::class.java,
                            com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, com.resoluteai.guardapp.data.remote.api_response.Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, com.resoluteai.guardapp.data.remote.api_response.Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }
            }
        } catch (e: Exception) {
            NetworkResult.Failed(e.message)
        }
    }

    override suspend fun verifyOtpFromGeofence(requestBody: VerifyOtp): NetworkResult<String> {
        return try {

            val result = otpApi.verifyOtpFromGeofence(
                requestBody
            )

            if (result.isSuccessful) {
                NetworkResult.Success(result.body()!!.data!!)
            } else {
                if (result.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        result.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            com.resoluteai.guardapp.data.remote.api_response.Detail::class.java,
                            com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, com.resoluteai.guardapp.data.remote.api_response.Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, com.resoluteai.guardapp.data.remote.api_response.Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }
            }
        } catch (e: Exception) {
            NetworkResult.Failed(e.message)
        }
    }
}