package com.resoluteai.guardapp.data.remote.api_request

data class  VerifyOtp(
    val client_id: String,
    val employee_id: String,
    val otp: String
)