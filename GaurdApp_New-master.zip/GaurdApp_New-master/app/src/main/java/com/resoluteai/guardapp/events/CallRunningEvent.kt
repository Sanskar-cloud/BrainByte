package com.resoluteai.guardapp.events

data class CallRunningEvent(
    val isCallRunning: Boolean
)
