package com.resoluteai.guardapp.broadcast

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK
import android.util.Log
import com.resoluteai.guardapp.presentation.activity.CallActivity
import com.resoluteai.guardapp.service.RingtoneHelper
import com.resoluteai.guardapp.utils.Constant.ACCEPT_CALL_NOTIFICATION_BROADCAST
import com.resoluteai.guardapp.utils.Constant.CALL_NOTIFICATION_ID
import com.resoluteai.guardapp.utils.Constant.IS_CALL_CAME_FROM_GUARD
import com.resoluteai.guardapp.utils.Constant.IS_GUARD_IN_THE_CALL
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class AcceptCallNotification : BroadcastReceiver() {

    @Inject
    lateinit var ringtoneHelper: RingtoneHelper
    override fun onReceive(context: Context, intent: Intent) {
        Log.d(ACCEPT_CALL_NOTIFICATION_BROADCAST, "BROADCAST CALLED")
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (!IS_GUARD_IN_THE_CALL) {

            val intent = Intent(context, CallActivity::class.java).apply {
                addFlags(FLAG_ACTIVITY_NEW_TASK or FLAG_ACTIVITY_CLEAR_TASK)
            }
            context.startActivity(intent)

            notificationManager.cancel(CALL_NOTIFICATION_ID)
            ringtoneHelper.stopPlayback()
            IS_CALL_CAME_FROM_GUARD = false
            Log.d(ACCEPT_CALL_NOTIFICATION_BROADCAST, "call: $IS_CALL_CAME_FROM_GUARD")
            Log.d(ACCEPT_CALL_NOTIFICATION_BROADCAST, "stopped player")

        }


        Log.d(ACCEPT_CALL_NOTIFICATION_BROADCAST, "BROADCAST END")
    }
}