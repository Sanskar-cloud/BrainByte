package com.resoluteai.guardapp.broadcast

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class CaptchaReceivedBroadcast(private val callback: Callback): BroadcastReceiver() {

    interface Callback {
        fun onCaptchaReceived()
    }


    override fun onReceive(context: Context?, intent: Intent?) {
        val isCaptchaReceived = intent?.getBooleanExtra("captcha_received", false)

        if (isCaptchaReceived == true) {
            callback.onCaptchaReceived()
        }
    }

}