package com.resoluteai.guardapp.data.remote.api_response

data class CheckPostStatusResponse(
    val status: Boolean,
    val data: Boolean,
    val message: String
)
