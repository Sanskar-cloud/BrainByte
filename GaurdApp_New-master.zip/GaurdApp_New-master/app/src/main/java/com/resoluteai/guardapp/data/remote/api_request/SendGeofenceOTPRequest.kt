package com.resoluteai.guardapp.data.remote.api_request

data class SendGeofenceOTPRequest(
    val employee_id: String,
    val phone_no: String? = null,
    val event_id:String,
    val body:String? = null,
    val email: String? = null,
    val send_email: String? = null
)