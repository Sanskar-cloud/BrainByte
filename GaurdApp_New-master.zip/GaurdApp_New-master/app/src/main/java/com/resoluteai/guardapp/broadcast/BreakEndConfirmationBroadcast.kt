package com.resoluteai.guardapp.broadcast

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BreakEndConfirmationBroadcast(private val endBreakCallback: EndBreakCallback): BroadcastReceiver() {

    interface EndBreakCallback {
        fun onBreakEndConfirmationReceived()
    }
    override fun onReceive(context: Context?, intent: Intent?) {

        val confirmation = intent?.getBooleanExtra("confirmation", false)
        if (confirmation == true) {
            endBreakCallback.onBreakEndConfirmationReceived()
        }
    }
}