package com.resoluteai.guardapp.data.remote.api_response.event


import com.google.gson.annotations.SerializedName

data class Shift(
    @SerializedName("end_time")
    val endTime: String,
    @SerializedName("start_time")
    val startTime: String
)