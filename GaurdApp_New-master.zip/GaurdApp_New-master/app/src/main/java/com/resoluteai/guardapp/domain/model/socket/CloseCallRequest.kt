package com.resoluteai.guardapp.domain.model.socket

import com.resoluteai.guardapp.domain.model.call.CallMetadata

data class CloseCallRequest(
    val callingToName: String,
    val employeeId: String,
    val receiverId: String,
    val isCalling: String,
    val metadata: CallMetadata,
    val tabId: Int,
    val type: String
)
