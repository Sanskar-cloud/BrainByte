package com.resoluteai.guardapp.broadcast

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.google.android.gms.location.LocationRequest
import com.google.gson.Gson
import com.resoluteai.guardapp.utils.Constant

class LocationAvailabilityBroadcast(private val callback: Callback): BroadcastReceiver() {

    interface Callback {
        fun onLocationOffCalled(request: LocationRequest)
    }
    override fun onReceive(context: Context?, intent: Intent?) {
        val isLocationAvailable = intent?.getBooleanExtra("is_location_available", false)
        Log.d(Constant.DefaultLocationClientClass, "location avail:   $isLocationAvailable")

        if (isLocationAvailable == false) {
            val locationRequest = intent.getStringExtra("location_request")
            if (locationRequest != null) {
                val req = Gson().fromJson(locationRequest, LocationRequest::class.java)
                callback.onLocationOffCalled(req)
            }
        }

    }
}