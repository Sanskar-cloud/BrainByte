package com.resoluteai.guardapp.domain.model.socket

import com.resoluteai.guardapp.data.remote.api_request.alert.CreateGeneratedAlertRequest

data class PostAlert(
    val alert_id: String,
    val post_id:String,
    val employee_id: String,
    val event_id:String,
    val generatedAlert: CreateGeneratedAlertRequest
)