package com.resoluteai.guardapp.presentation.dialog

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.DialogFragment
import com.resoluteai.guardapp.R

class NotifyOnlyProfileDialog: DialogFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val notifyLoginOTPView = inflater.inflate(R.layout.dialog_notify_only_profile, container, false)
        dialog?.window?.setBackgroundDrawableResource(R.drawable.card_rounded_desgin)

        val okBtn = notifyLoginOTPView.findViewById<Button>(R.id.ok_btn)

        okBtn.setOnClickListener {
            dismiss()
        }

        isCancelable = false

        return notifyLoginOTPView
    }

    companion object {
        const val TAG = "NotifyOnlyProfile"
    }
}