package com.resoluteai.guardapp.data.repository_impl

import android.util.Log
import com.google.gson.GsonBuilder
import com.resoluteai.guardapp.data.remote.EmployeeApi
import com.resoluteai.guardapp.data.remote.api_response.Detail
import com.resoluteai.guardapp.data.remote.api_response.DetailDeserializer
import com.resoluteai.guardapp.data.remote.api_response.Error
import com.resoluteai.guardapp.data.remote.api_response.employee.Employee
import com.resoluteai.guardapp.domain.repository.EmployeeRepository
import com.resoluteai.guardapp.utils.Constant
import com.resoluteai.guardapp.utils.NetworkResult
import javax.inject.Inject

class EmployeeRepositoryImpl @Inject constructor(
    private val employeeApi: EmployeeApi
): EmployeeRepository {

    override suspend fun getEmployeeById(employeeId: String, merge: Boolean): NetworkResult<Employee> {
        return try {

            val result = employeeApi.getEmployeeById(employeeId, merge)

            if (result.isSuccessful) {
                if (result.body()!!.status == true) {
                    NetworkResult.Success(result.body()!!.data!!)
                } else {
                    NetworkResult.Failed(result.body()!!.message)
                }

            } else {

                if (result.code() == 500) {
                    // Handle 500 Internal Server Error

                    val errorBodyString =
                        result.errorBody()!!.string()
                    Log.d(Constant.EMPLOYEE_REPO_TAG, errorBodyString)
                    val gson = GsonBuilder()
                        .registerTypeAdapter(
                            Detail::class.java,
                            DetailDeserializer()
                        )
                        .create()
                    val detail = gson.fromJson(errorBodyString, Error::class.java)
                    Log.d("employee repo: detail", "$detail")
                    if (detail != null) {
                        val error =gson.fromJson(detail.detail, Detail::class.java)
                        Log.d("employee repo: error ", error.toString())
                        NetworkResult.Failed(error.error)
                    } else {
                        NetworkResult.Failed("something went wrong")
                    }
                } else {
                    NetworkResult.Failed("something went wrong")
                }

            }

        } catch (e: Exception) {
            NetworkResult.Failed(e.message)
        }
    }
}