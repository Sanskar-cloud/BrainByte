package com.resoluteai.guardapp.presentation.activity

import android.Manifest
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import com.resoluteai.guardapp.R
import com.resoluteai.guardapp.broadcast.NetworkChangeListener
import com.resoluteai.guardapp.broadcast.NetworkChangeReceiver
import com.resoluteai.guardapp.utils.hasRequiredPermissions
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class AuthActivity : AppCompatActivity(), NetworkChangeListener {

    private lateinit var networkChangeReceiver: NetworkChangeReceiver
    private var noInternetDialog: AlertDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        installSplashScreen()
        if (!hasRequiredPermissions(ALL_PERMISSIONS)) {
            ActivityCompat.requestPermissions(
                this, ALL_PERMISSIONS, 0
            )
        }

        setContentView(R.layout.activity_auth)

        networkChangeReceiver = NetworkChangeReceiver(this)
        registerReceiver(networkChangeReceiver, IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"))


        val window: Window = this.window
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
        }
        window.statusBarColor = ContextCompat.getColor(this, R.color.white)
    }



    companion object {
        private val ALL_PERMISSIONS = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.POST_NOTIFICATIONS
        )
    }

    override fun onNetworkChanged(isConnected: Boolean) {
        if (!isConnected) {
            showNoInternetDialog()
        } else {
            dismissNoInternetDialog()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(networkChangeReceiver)
    }

    private fun showNoInternetDialog() {
        if (noInternetDialog == null) {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("No Internet Connection")
                .setMessage("Please check your internet connection and try again.")
                .setCancelable(false)

            noInternetDialog = builder.create()
            noInternetDialog?.show()
        }
    }

    private fun dismissNoInternetDialog() {
        noInternetDialog?.dismiss()
        noInternetDialog = null
    }
}