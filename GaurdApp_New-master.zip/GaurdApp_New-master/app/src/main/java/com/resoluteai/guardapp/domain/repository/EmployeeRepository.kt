package com.resoluteai.guardapp.domain.repository

import com.resoluteai.guardapp.data.remote.api_response.employee.Employee
import com.resoluteai.guardapp.utils.NetworkResult

interface EmployeeRepository {

    suspend fun getEmployeeById(employeeId: String, merge: Boolean): NetworkResult<Employee>
}