package com.resoluteai.guardapp.domain.model.socket

data class AlertStatus(
    val employee_id: String,
    val event_id: String,
    val status: Int
)
