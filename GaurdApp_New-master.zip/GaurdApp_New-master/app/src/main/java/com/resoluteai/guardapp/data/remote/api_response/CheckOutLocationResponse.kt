package com.resoluteai.guardapp.data.remote.api_response

data class CheckOutLocationResponse(
    val status: Boolean,
    val message: String
)
