package com.resoluteai.guardapp.data.remote.api_response.employee


import com.google.gson.annotations.SerializedName
import com.resoluteai.guardapp.domain.model.auth.DeviceInfo

data class EmployeeNN(
    @SerializedName("address")
    val address: String,
    @SerializedName("assignment_otp_id")
    val assignmentOtpId: String?,
    @SerializedName("category_id")
    val categoryId: Any?,
    @SerializedName("client_id")
    val clientId: String,
    @SerializedName("country_code")
    val countryCode: String,
    @SerializedName("created_at")
    val createdAt: String,
    @SerializedName("created_by")
    val createdBy: String?,
    @SerializedName("device")
    val device: DeviceInfo,
    @SerializedName("email")
    val email: String,
    @SerializedName("event_id")
    val eventId: String,
    @SerializedName("forgot_password")
    val forgotPassword: Boolean,
    @SerializedName("forgot_password_otp_id")
    val forgotPasswordOtpId: String?,
    @SerializedName("id")
    val id: String,
    @SerializedName("is_assigned")
    val isAssigned: Boolean,
    @SerializedName("is_deleted")
    val isDeleted: Boolean,
    @SerializedName("name")
    val name: String,
    @SerializedName("password")
    val password: String,
    @SerializedName("phone_number")
    val phoneNumber: String,
    @SerializedName("pincode")
    val pincode: String,
    @SerializedName("post_id")
    val postId: String,
    @SerializedName("profile_url")
    val profileUrl: String,
    @SerializedName("role_id")
    val roleId: String,
    @SerializedName("status")
    val status: Boolean,
    @SerializedName("uidai")
    val uidai: String,
    @SerializedName("updated_at")
    val updatedAt: String,
    @SerializedName("updated_by")
    val updatedBy: String,
    @SerializedName("work_location_id")
    val workLocationId: String
)