let localVideo = document.getElementById("local-video")
let remoteVideo = document.getElementById("remote-video")
let videoContainer = document.querySelector(".video-container")


localVideo.style.opacity = 0
remoteVideo.style.opacity = 0

localVideo.onplaying = () => { localVideo.style.opacity = 1 }
remoteVideo.onplaying = () => { remoteVideo.style.opacity = 1 }


let remoteCall = null

let peer
let localStream
let connection
console.log("call.js loaded")
function init(userId) {

    console.log("init log", userId)
    peer = new Peer(userId, {
             host: "signaling-be-ms-vmwe4oziqq-el.a.run.app",
             secure: true,
             port: 443

    })
//     peer = new Peer(userId)

    peer.on('error', (error) => {
            console.log("peer init error", error)
    })

    peer.on('open', () => {
    console.log("peer on open Called", peer.id)
    Android.onPeerConnected()
    })

      navigator.getUserMedia({
                               audio: true,
                               video: { facingMode: "user" }
                           }, (stream) => {
                               console.log("stream", JSON.stringify(localVideo))
                               localVideo.srcObject = stream
                               localStream = stream

    //                           localVideo.className = "primary-video"
                               console.log("navigator init", JSON.stringify(Object.getOwnPropertyNames(stream)));
                               localVideo.play()
                               })




    peer.on("connection", (remoteConnection) => {

            connection = remoteConnection;
            console.log("connection recieved: ", JSON.stringify(Object.getOwnPropertyNames(connection)));

            const initiateCall  = () => {




//            console.log("localstream: ", typeof(localStream));
//            while (!localStream || localStream == "undefined") {
//
////                for (let i=0;i < 10;  i++){
////
////                    console.log("for loop running: ", i);
////
////                   call = peer.call(connection.peer, localStream, {metadata: {"name": "keval", incommingcall: true}})
////                   if (call) break
////                 }
//
//
//            }



             navigator.getUserMedia({
                                                   audio: true,
                                                   video: { facingMode: "user" }
                                               }, (stream) => {
                                                   localVideo.srcObject = stream
                                                   localStream = stream
                        //                           localVideo.className = "primary-video"
                                                   let call = peer.call(connection.peer, localStream, {metadata: {"name": "shashank", incommingcall: true}})
                                                   console.log("type of localstream: ", typeof(localStream));

                                                   console.log("navigator init", JSON.stringify(Object.getOwnPropertyNames(stream)));
                                                   localVideo.play()

                                                    remoteCall = call

                                                               console.log("Peer Call: ", JSON.stringify(Object.getOwnPropertyNames(call)))
                                                               console.log("Connection of Peer: ", JSON.stringify(Object.getOwnPropertyNames(connection.peer)))
                                                               call.on('stream', (remoteStream) => {
                                                               console.log("local video stream length: ", localStream.getVideoTracks().length)
                                                               console.log("local audio stream length: ", localStream.getAudioTracks().length)
                                                               remoteVideo.srcObject = remoteStream
                                                               localVideo.className = "secondary-video"
                                                               videoContainer.style.display = 'block'
                                                               remoteVideo.className = "primary-video"
                                                               remoteVideo.play()
                                                               //localVideo.play()
                                                   })


            })

            }
            initiateCall()
        });


}



function listen() {
    peer.on('call', (call) => {

    console.log("call", call)

    remoteCall = call

        navigator.getUserMedia({
            audio: true,
            video: { facingMode: "environment" }
        }, (stream) => {
            localVideo.srcObject = stream
            localStream = stream

            call.answer(stream)
            call.on('stream', (remoteStream) => {
            console.log("local video stream length: ", localStream.getVideoTracks().length)
            console.log("local audio stream length: ", localStream.getAudioTracks().length)
                remoteVideo.srcObject = remoteStream
                localVideo.className = "secondary-video"
                remoteVideo.play()
                localVideo.play()
            })

        })

    })
}

function toggleTorch(isFlashlightOn) {
  const track = localStream.getVideoTracks()[0];
  console.log("Toggle Torch Entered", isFlashlightOn)
  if (isFlashlightOn == "true") {
  console.log("Toggle Torch Entered true", isFlashlightOn)
    track.applyConstraints({
      advanced: [
        {
          torch: true,
        },
      ],
    });
  } else {
  console.log("Toggle Torch Entered false", isFlashlightOn)
    track.applyConstraints({
        advanced: [
          {
            torch: false,
          },
        ],
      });
  }
}


  function switchCamera() {

           console.log("switch Camera Called")
          // if video source is user facing then switch to environment facing
          if (
            localVideo.srcObject &&
            localVideo.srcObject.getVideoTracks()[0].getSettings()
              .facingMode === "user"
          ) {



          console.log("switch Camera Called localVIDEO")
            navigator.mediaDevices
              .getUserMedia({ video: { facingMode: "environment" } })
              .then(function (stream) {
                console.log("🔥 environment streaming");
                console.log("🔥 environment streaming", remoteCall)
                localVideo.srcObject = stream
                localVideo.play()
                var videoTrack = stream.getVideoTracks()[0]
                remoteCall.peerConnection.getSenders()[1].replaceTrack(videoTrack)

              });
          } else {
            // if video source is environment facing then switch to user facing
            navigator.mediaDevices
              .getUserMedia({
              audio: true,
              video: { facingMode: "user" }
              })
              .then(function (stream) {
                console.log("🔥 user streaming", stream)
                console.log("🔥 user streaming", localVideo)
                console.log("🔥 user streaming remote call", remoteCall)
                localVideo.srcObject = stream
                localVideo.play()
                var videoTrack = stream.getVideoTracks()[0]
                remoteCall.peerConnection.getSenders()[1].replaceTrack(videoTrack)

              });
          }
        }


function disconnectCall() {
    peer.disconnect()
    console.log("peer disconnect call called")
    AndroidLiveStream.onPeerDisconnected()
}

function hideLocalVideo() {
 localVideo.style.opacity = 0
 console.log("hidevideocall called")
}

function reloadLocalVideo() {
 localVideo.style.opacity = 1
 console.log("showvideocall called")
}






