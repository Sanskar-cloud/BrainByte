package com.resoluteai.guardapp

import org.junit.Assert
import org.junit.Test
import java.util.Calendar

class ShiftTimeDutyValidator {

    @Test
    fun check_shift_duty() {

        val rightNow: Calendar = Calendar.getInstance()
        val currentHourIn24Format = rightNow.get(Calendar.HOUR_OF_DAY)
        val currentMin = rightNow.get(Calendar.MINUTE)
        val curr_time = (currentHourIn24Format * 3600) + (currentMin * 60)

        //val curr_time = 1*3600 + 2*60

        val shiftStartHr = 16 * 3600
        val shiftStartMn = 0 * 60
        val shiftEndHr = 0 * 3600
        val shiftEndMn = 0 * 60
        val bufferTime = 20*60

        val start_time = shiftStartHr + shiftStartMn - bufferTime
        val end_time = shiftEndHr + shiftEndMn + bufferTime

        Assert.assertEquals(true, checkShiftIsValid(start_time, end_time, curr_time))

    }

    fun checkShiftIsValid(start_time: Int, end_time: Int, curr_time: Int): Boolean {
        return if (start_time > end_time) {
            curr_time >= start_time || curr_time <= end_time
        } else {
            curr_time in start_time..end_time
        }
    }
}