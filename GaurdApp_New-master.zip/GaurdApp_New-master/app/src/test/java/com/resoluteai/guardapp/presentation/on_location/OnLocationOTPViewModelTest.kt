package com.resoluteai.guardapp.presentation.on_location

import org.junit.After
import org.junit.Before

class OnLocationOTPViewModelTest {

    @Before
    fun setUp() {
    }

    @After
    fun tearDown() {
    }
}