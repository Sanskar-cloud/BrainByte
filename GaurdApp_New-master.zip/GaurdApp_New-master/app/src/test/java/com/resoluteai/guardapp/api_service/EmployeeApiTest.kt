package com.resoluteai.guardapp.api_service

import com.resoluteai.guardapp.data.remote.EmployeeApi
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Assert
import org.junit.Before
import org.junit.Test
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class EmployeeApiTest {

    private lateinit var mockWebServer: MockWebServer
    private lateinit var employeeApi: EmployeeApi

    @Before
    fun setUp() {
        mockWebServer = MockWebServer()
        mockWebServer.start()
        employeeApi = Retrofit.Builder()
            .baseUrl(mockWebServer.url("/"))
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(EmployeeApi::class.java)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun TestApi() = runTest {
        val mockResponse = MockResponse()
        mockResponse.setBody("[]")
        mockWebServer.enqueue(mockResponse)

        val response = employeeApi.getEmployeeByIdTest("123", true)
        mockWebServer.takeRequest()

        Assert.assertEquals(true, response.body()!!.isEmpty())
    }
    @After
    fun tearDown() {
        mockWebServer.shutdown()
    }
}